<?php
session_start();
if (isset($_SESSION["usuario_id"]) && !isset($_SESSION["usuario_rol"])) {
    session_destroy();
    header("Location: iniciarsesion.php");
    exit;
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

require_once "config/conexion.php";

$logueado = isset($_SESSION["usuario_id"]);
$rol = $_SESSION["usuario_rol"] ?? null;
?>


<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>

        <!-- Boton hamburguesa -->
        <input type="checkbox" id="menu" />
        <div class="menu-btn">
          <label for="menu" aria-label="Abrir menú">
            <!-- Menu animado -->
             <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
              <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                <path class="line top" d="M3 7h18"></path>
                <path class="line mid" d="M3 12h18"></path>
                <path class="line bot" d="M3 17h18"></path>
              </g>
            </svg>
          </label>
        </div>


        <!-- Navbar -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="index.php">Test</a></li>
            <li><a href="acercade.php">Acerca de</a></li>

            <?php if ($logueado): ?>
              <li><a href="resultados.php">Resultados</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <ul class="logout-menu">
          <?php if ($logueado && $rol === "administrador"): ?>
              <a href="admin/admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <?php elseif ($logueado && $rol === "aplicador"):?>
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
          <?php endif; ?>
          
          <?php if ($logueado): ?>
            <li><a href="config/logout.php" class="logout">Cerrar sesión</a></li>
          <?php else: ?>
            <li><a href="iniciarsesion.php" class="logout">Iniciar sesión</a></li>
          <?php endif; ?>
          
        </ul>

      </nav>
      </div>
    </div>
  </header>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>