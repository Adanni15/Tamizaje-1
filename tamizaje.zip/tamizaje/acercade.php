<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>

        <!-- Boton hamburguesa -->
        <input type="checkbox" id="menu" />
        <div class="menu-btn">
          <label for="menu" aria-label="Abrir menú">
            <!-- Menu animado -->
             <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
              <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                <path class="line top" d="M3 7h18"></path>
                <path class="line mid" d="M3 12h18"></path>
                <path class="line bot" d="M3 17h18"></path>
              </g>
            </svg>
          </label>
        </div>


        <!-- Navbar -->
         <nav class="navbar">
          <div class="main-menu">
            <ul>
              <li><a href="index.php">Test</a></li>
              <li><a href="acercade.php" class="logout">Acerca de</a></li>
              <li><a href="resultados.php">Resultados</a></li>
            </ul>
          </div>
          <ul class="logout-menu">
            <li><a href="admin_cuenta.php" class="admin-btn">Administrar Cuenta</a></li>
            <li><a href="iniciarsesion.php" class="logout">Iniciar Sesión</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </header>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>