<?php
require_once "config/auth.php";
require_once "config/conexion.php";

$logueado = true;
$rol = $_SESSION["usuario_rol"];

// ==========================
// CONSULTA DE INSTRUMENTOS ACTIVOS
// ==========================
$instrumentos = $conexion->query("
  SELECT id, nombre
  FROM instrumentos
  WHERE activo = 1
  ORDER BY nombre
");

$instrumentoSeleccionado = $_GET["instrumento"] ?? null;
$nombreInstrumento = null;

if ($instrumentoSeleccionado) {
  $stmt = $conexion->prepare("
    SELECT nombre
    FROM instrumentos
    WHERE id = ?
    LIMIT 1
  ");
  $stmt->bind_param("i", $instrumentoSeleccionado);
  $stmt->execute();
  $res = $stmt->get_result();

  if ($fila = $res->fetch_assoc()) {
    $nombreInstrumento = $fila["nombre"];
  }
}

// ==========================
// CONSULTA DE ESCUELAS ACTIVAS
// ==========================
$escuelas = $conexion->query("
  SELECT id, nombre
  FROM escuelas
  WHERE activo = 1
  ORDER BY nombre
");

$escuelaSeleccionada = isset($_GET["escuela"]) && is_numeric($_GET["escuela"])
  ? (int) $_GET["escuela"]
  : null;

// ==========================
// CONSULTA DE ENCUESTADOS
// ==========================
$sql = "
  SELECT
    ap.id,
    ap.nombre,
    ap.edad,
    ap.sexo,
    ap.turno,
    ap.grado,
    ap.grupo,
    ap.especialidad,
    ap.fecha_aplicacion
  FROM aplicaciones_test ap
  WHERE 1=1
";

if ($instrumentoSeleccionado) {
  $sql .= " AND ap.instrumento_id = " . intval($instrumentoSeleccionado);
}

if ($escuelaSeleccionada) {
  $sql .= " AND ap.escuela_id = " . intval($escuelaSeleccionada);
}

$sql .= " ORDER BY ap.fecha_aplicacion DESC";

// ==========================
// DATOS POR SEXO
// ==========================
$datosSexo = [];

if ($instrumentoSeleccionado) {
  $sqlSexo = "
    SELECT ap.sexo, COUNT(*) total
    FROM aplicaciones_test ap
    WHERE ap.instrumento_id = " . intval($instrumentoSeleccionado);

  if ($escuelaSeleccionada) {
    $sqlSexo .= " AND ap.escuela_id = " . intval($escuelaSeleccionada);
  }

  $sqlSexo .= " GROUP BY ap.sexo";

  $res = $conexion->query($sqlSexo);
  while ($row = $res->fetch_assoc()) {
    $datosSexo[] = $row;
  }
}

// ==========================
// DATOS RADAR (PROMEDIO)
// ==========================
$datosRadar = [];

if ($instrumentoSeleccionado) {
  $stmt = $conexion->prepare("
    SELECT
      a.nombre AS area,
      ROUND(AVG(r.porcentaje), 2) AS riesgo_promedio
    FROM resultados r
    INNER JOIN areas a ON a.id = r.area_id
    INNER JOIN aplicaciones_test ap ON ap.id = r.aplicacion_id
    WHERE ap.instrumento_id = ?
    " . ($escuelaSeleccionada ? "AND ap.escuela_id = ?" : "") . "
    GROUP BY a.id, a.nombre
  ");

  if ($escuelaSeleccionada) {
    $stmt->bind_param("ii", $instrumentoSeleccionado, $escuelaSeleccionada);
  } else {
    $stmt->bind_param("i", $instrumentoSeleccionado);
  }

  $stmt->execute();
  $res = $stmt->get_result();

  while ($row = $res->fetch_assoc()) {
    $datosRadar[] = $row;
  }
}

// ==========================
// DATOS RADAR DETALLE
// ==========================
$datosRadarDetalle = [];

if ($instrumentoSeleccionado) {
  $sqlDetalle = "
    SELECT
      r.aplicacion_id,
      a.nombre AS area,
      r.porcentaje
    FROM resultados r
    INNER JOIN areas a ON a.id = r.area_id
    INNER JOIN aplicaciones_test ap ON ap.id = r.aplicacion_id
    WHERE ap.instrumento_id = " . intval($instrumentoSeleccionado);

  if ($escuelaSeleccionada) {
    $sqlDetalle .= " AND ap.escuela_id = " . intval($escuelaSeleccionada);
  }

  $res = $conexion->query($sqlDetalle);
  while ($row = $res->fetch_assoc()) {
    $datosRadarDetalle[] = $row;
  }
}

// ==========================
// RESULTADO FINAL
// ==========================
$resultado = $conexion->query($sql);
?>



<!doctype html>
<html lang="es">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <link rel="stylesheet" href="css/style_resultados.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>

        <!-- Boton hamburguesa -->
        <input type="checkbox" id="menu" />
        <div class="menu-btn">
          <label for="menu" aria-label="Abrir menú">
            <!-- Menu animado -->
             <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
              <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                <path class="line top" d="M3 7h18"></path>
                <path class="line mid" d="M3 12h18"></path>
                <path class="line bot" d="M3 17h18"></path>
              </g>
            </svg>
          </label>
        </div>


        <!-- Navbar -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="index.php">Test</a></li>
            <li><a href="acercade.php">Acerca de</a></li>

            <?php if ($logueado): ?>
              <li><a href="resultados.php">Resultados</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <ul class="logout-menu">
          <?php if ($logueado && $rol === "administrador"): ?>
              <a href="admin/admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <?php else: ?>
              <a href="admin/mi_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <?php endif; ?>
          
          <?php if ($logueado): ?>
            <li><a href="config/logout.php" class="logout">Cerrar sesión</a></li>
          <?php else: ?>
            <li><a href="iniciarsesion.php" class="logout">Iniciar sesión</a></li>
          <?php endif; ?>
        </ul>

      </nav>
      </div>
    </div>
  </header>
  <main class="container my-5">
    <div class="card shadow-sm mb-4">
      <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">

          <div class="col-md-6">
            <label class="form-label label-institucional">Instrumento</label>
            <select name="instrumento" class="form-select select-institucional" required>
              <option value="">Selecciona un instrumento</option>
              <?php while ($inst = $instrumentos->fetch_assoc()): ?>
                <option value="<?= $inst["id"] ?>"
                  <?= ($instrumentoSeleccionado == $inst["id"]) ? "selected" : "" ?>>
                  <?= htmlspecialchars($inst["nombre"]) ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>
            <!-- ESCUELA -->
            <div class="col-md-4">
              <label class="form-label label-institucional">Escuela</label>
              <select name="escuela" class="form-select select-institucional">
                <option value="">Todas las escuelas</option>
                <?php while ($esc = $escuelas->fetch_assoc()): ?>
                  <option value="<?= $esc["id"] ?>"
                    <?= ($escuelaSeleccionada == $esc["id"]) ? "selected" : "" ?>>
                    <?= htmlspecialchars($esc["nombre"]) ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>
              
          <div class="col-md-3">
            <button class="btn btn-primary w-100">
              Ver resultados
            </button>
          </div>
              
        </form>
      </div>
    </div>

  <h2 class="titulo-selector text-center card-test-e">
    <?= $nombreInstrumento
        ? "Resultados del instrumento: " . htmlspecialchars($nombreInstrumento)
        : "Resultados del test" ?>
  </h2>

  <?php if ($instrumentoSeleccionado): ?>
  <!-- FILTROS -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form id="filtrosForm" class="row g-3">

        <div class="col-md-4">
          <input type="text" id="buscarNombre" class="form-control" placeholder="Buscar por nombre">
        </div>

        <div class="col-md-2">
          <select id="filtroSexo" class="form-select">
            <option value="">Sexo</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="edadMin" class="form-select">
            <option value="">Edad mín</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="edadMax" class="form-select">
            <option value="">Edad máx</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroTurno" class="form-select">
            <option value="">Turno</option>
          </select>
        </div>
        <div class="col-md-2">
          <select id="filtroGrado" class="form-select">
            <option value="">Grado</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroEspecialidad" class="form-select">
            <option value="">Especialidad</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroGrupo" class="form-select">
            <option value="">Grupo</option>
          </select>
        </div>

        <div class="col-12 text-end">
          <button type="button" class="btn btn-primary px-4" id="aplicarFiltros">
            Aplicar filtros
          </button>
          <button type="button" class="btn btn-secondary" id="limpiarFiltros">
            Limpiar
          </button>
        </div>

      </form>
    </div>
  </div>

  <!-- TABLA DE RESULTADOS -->
   <div class="card shadow-sm mb-5">
    <div class="card-body">
      <h5 class="card-title mb-3">Encuestados</h5>

        <div class="table-responsive tabla-scroll">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Sexo</th>
                <th>Turno</th>
                <th>Grado</th>
                <th>Grupo</th>
                <th>Especialidad</th>
                <th>Fecha y hora de realización</th>
              </tr>
            </thead>
            <tbody id="tablaResultados">
              <?php if ($resultado && $resultado->num_rows > 0): ?>
                <?php while ($row = $resultado->fetch_assoc()): ?>
                  <tr>
                    <td><?= $row["id"] ?></td>
                    <td>
                      <a href="resultado_alumno.php?id=<?= $row['id'] ?>" class="text-decoration-none fw-semibold">
                        <?= htmlspecialchars($row["nombre"]) ?>
                      </a>
                    </td>
                    <td><?= $row["edad"] ?></td>
                    <td><?= htmlspecialchars($row["sexo"]) ?></td>
                    <td><?= htmlspecialchars($row["turno"]) ?></td>
                    <td><?= htmlspecialchars($row["grado"]) ?></td>
                    <td><?= htmlspecialchars($row["grupo"]) ?></td>
                    <td><?= htmlspecialchars($row["especialidad"]) ?></td>
                    <td><?= date("d/m/Y H:i", strtotime($row["fecha_aplicacion"])) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="9" class="text-center text-muted">
                    No hay resultados registrados
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- SEPARADOR RESULTADOS GENERALES -->
     <div class="separador-resultados my-5 ">
      <span>Resultados generales</span>
    </div>

<!--GRAFICAS-->
<!-- GRAFICA RADAR (PRINCIPAL) -->
<div class="row mb-4">
  <div class="col-12">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title text-center mb-3">
          Riesgo general por área
        </h5>

        <canvas id="graficaRadar" style="max-height:350px;"></canvas>

        <div class="d-flex justify-content-center gap-4 mt-3 flex-wrap">
          <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-circle"
              style="width:14px;height:14px;background:#28a745;"></span>
            <span class="fw-semibold">Bajo</span>
            <small class="text-muted">(0 – 33%)</small>
          </div>

          <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-circle"
              style="width:14px;height:14px;background:#ffc107;"></span>
            <span class="fw-semibold">Medio</span>
            <small class="text-muted">(34 – 66%)</small>
          </div>

          <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-circle"
              style="width:14px;height:14px;background:#dc3545;"></span>
            <span class="fw-semibold">Alto</span>
            <small class="text-muted">(67 – 100%)</small>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- KPI PROMEDIO -->
  <div class="col-md-4">
    <div class="card shadow-sm text-center h-100">
      <div class="card-body d-flex flex-column justify-content-center">
        <h6 class="text-muted">Nivel de riesgo promedio</h6>
        <div class="display-4 fw-bold" id="kpiPromedio">0%</div>
        <small class="text-muted">Indicador general del instrumento</small>
      </div>
    </div>
  </div>

  <!-- TOTAL ENCUESTADOS -->
  <div class="col-md-4">
    <div class="card shadow-sm text-center h-100">
      <div class="card-body">
        <h6 class="text-muted">Total de encuestados</h6>
        <canvas id="graficaTotal" style="max-height:180px;"></canvas>
        <div class="fw-bold fs-4 mt-2" id="totalVisible">0</div>
      </div>
    </div>
  </div>

  <!-- DONUT RIESGO -->
  <div class="col-md-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h6 class="text-center">Distribución por sexo</h6>
        <canvas id="graficaSexo"></canvas>
        
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <div class="col-md-6">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h6 class="text-center">Distribución global de riesgo</h6>
        <canvas id="graficaRiesgoGlobal"></canvas>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h6 class="text-center">Distribución de riesgo</h6>
        <canvas id="graficahistogramariesgo"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="row mb-5">
  <div class="col-12">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="text-center mb-3">
          Tendencia temporal del riesgo promedio
        </h5>
        <canvas id="graficaTendenciaRiesgo" style="max-height:320px;"></canvas>
      </div>
    </div>
  </div>
</div>



<?php else: ?>
  <div class="mensaje text-center card-test-e">
    Selecciona un instrumento y escuela para ver sus resultados
  </div>
<?php endif; ?>



</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const filas = document.querySelectorAll("#tablaResultados tr");

  const buscarNombre = document.getElementById("buscarNombre");
  const filtroSexo = document.getElementById("filtroSexo");
  const filtroTurno = document.getElementById("filtroTurno");
  const filtroGrado = document.getElementById("filtroGrado");
  const filtroEspecialidad = document.getElementById("filtroEspecialidad");
  const filtroGrupo = document.getElementById("filtroGrupo");
  const edadMin = document.getElementById("edadMin");
  const edadMax = document.getElementById("edadMax");

  const aplicarBtn = document.getElementById("aplicarFiltros");
  const limpiarBtn = document.getElementById("limpiarFiltros");

  function aplicarFiltros() {
    filas.forEach(fila => {
      const c = fila.children;
      if (!c.length) return;

      const nombre = c[1].textContent.toLowerCase();
      const edad = parseInt(c[2].textContent);
      const sexo = c[3].textContent.trim();
      const turno = c[4].textContent.trim();
      const grado = c[5].textContent.trim();
      const grupo = c[6].textContent.trim();
      const especialidad = c[7].textContent.trim();

      let visible = true;

      // Nombre
      if (buscarNombre.value && !nombre.includes(buscarNombre.value.toLowerCase())) {
        visible = false;
      }

      // Sexo
      if (filtroSexo.value && filtroSexo.value !== sexo) {
        visible = false;
      }

      // Turno
      if (filtroTurno.value && filtroTurno.value !== turno) {
        visible = false;
      }
      
      // Grado
      if (filtroGrado.value && filtroGrado.value !== grado) {
      visible = false;
      }

      // Grupo
      if (filtroGrupo.value && filtroGrupo.value !== grupo) {
        visible = false;
      }

      // Especialidad
      if (filtroEspecialidad.value && filtroEspecialidad.value !== especialidad) {
        visible = false;
      }

      // Edad mínima
      if (edadMin.value && edad < parseInt(edadMin.value)) {
        visible = false;
      }

      // Edad máxima
      if (edadMax.value && edad > parseInt(edadMax.value)) {
        visible = false;
      }

      fila.style.display = visible ? "" : "none";
    });
    calcularRadarFiltrado();
    calcularSexoFiltrado();
    calcularTotalFiltrado();
    dibujarRiesgoGlobal();
    calcularPromedioGeneral();
    calcularDistribucionRiesgo();
    const datosTendencia = obtenerDatosParaTendencia();
    dibujarGraficaTendencia(datosTendencia);


  }

  aplicarBtn.addEventListener("click", aplicarFiltros);

  limpiarBtn.addEventListener("click", () => {
    buscarNombre.value = "";
    filtroSexo.value = "";
    filtroTurno.value = "";
    filtroGrado.value = "";
    filtroEspecialidad.value = "";
    filtroGrupo.value = "";
    edadMin.value = "";
    edadMax.value = "";
    edadMax.disabled = true;

    filas.forEach(fila => fila.style.display = "");
  });

  // Filtrar en tiempo real al escribir nombre
  buscarNombre.addEventListener("keyup", aplicarFiltros);
  calcularRadarFiltrado();
  calcularSexoFiltrado();
  calcularTotalFiltrado();
  dibujarRiesgoGlobal();
  calcularPromedioGeneral();
  calcularDistribucionRiesgo();
  const datosTendencia = obtenerDatosParaTendencia();
  dibujarGraficaTendencia(datosTendencia);


});
</script>


<script>
document.addEventListener("DOMContentLoaded", () => {
  const tabla = document.querySelectorAll("#tablaResultados tr");

  const filtroSexo = document.getElementById("filtroSexo");
  const filtroTurno = document.getElementById("filtroTurno");
  const filtroEspecialidad = document.getElementById("filtroEspecialidad");
  const filtroGrupo = document.getElementById("filtroGrupo");
  const edadMin = document.getElementById("edadMin");
  const edadMax = document.getElementById("edadMax");

  const sexos = new Set();
  const turnos = new Set();
  const grados = new Set();
  const especialidades = new Set();
  const grupos = new Set();
  const edades = new Set();

  tabla.forEach(row => {
    const celdas = row.children;
    if (!celdas.length) return;

    edades.add(parseInt(celdas[2].textContent));
    sexos.add(celdas[3].textContent.trim());
    turnos.add(celdas[4].textContent.trim());
    grados.add(celdas[5].textContent.trim());
    grupos.add(celdas[6].textContent.trim());
    especialidades.add(celdas[7].textContent.trim());
  });

  // Función para llenar selects
  function llenarSelect(select, valores, textoDefault) {
    select.innerHTML = `<option value="">${textoDefault}</option>`;
    [...valores].sort().forEach(valor => {
      const option = document.createElement("option");
      option.value = valor;
      option.textContent = valor;
      select.appendChild(option);
    });
  }

  llenarSelect(filtroSexo, sexos, "Sexo");
  llenarSelect(filtroTurno, turnos, "Turno");
  llenarSelect(filtroGrado, grados, "Grado");
  llenarSelect(filtroEspecialidad, especialidades, "Especialidad");
  llenarSelect(filtroGrupo, grupos, "Grupo");

  // Edad mínima
  llenarSelect(edadMin, edades, "Edad mín");
  edadMax.innerHTML = `<option value="">Edad máx</option>`;
  edadMax.disabled = true;

  // Control edad mínima → máxima
  edadMin.addEventListener("change", () => {
    const min = parseInt(edadMin.value);
    edadMax.innerHTML = `<option value="">Edad máx</option>`;

    if (isNaN(min)) {
      edadMax.disabled = true;
      return;
    }

    [...edades]
      .filter(e => e >= min)
      .sort((a, b) => a - b)
      .forEach(e => {
        const option = document.createElement("option");
        option.value = e;
        option.textContent = e;
        edadMax.appendChild(option);
      });

    edadMax.disabled = false;
  });
});
</script>

<script>
const datosSexo = <?= json_encode($datosSexo) ?>;
let totalChart = null;
let totalGeneral = 0;

document.querySelectorAll("#tablaResultados tr").forEach(fila => {
  if (fila.children.length >= 9) {
    totalGeneral++;
  }
});

</script>

<script>
let sexoChart = null;

function dibujarGraficaSexo(labels, valores) {
  const ctx = document.getElementById("graficaSexo");

  if (sexoChart) {
    sexoChart.destroy();
  }

  sexoChart = new Chart(ctx, {
    type: "pie",
    data: {
      labels: labels,
      datasets: [{
        data: valores,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "bottom"
        }
      }
    }
  });
}

</script>
<script>
const datosRadarDetalle = <?= json_encode($datosRadarDetalle) ?>;
</script>


<script>
const datosRadar = <?= json_encode($datosRadar) ?>;

function dibujarRadar(labels, valores, colores) {
  const ctx = document.getElementById("graficaRadar");

  if (radarChart) {
    radarChart.destroy();
  }

  radarChart = new Chart(ctx, {
    type: "radar",
    data: {
      labels: labels,
      datasets: [{
        label: "Riesgo promedio (%)",
        data: valores,
        backgroundColor: "rgba(0,0,0,0.05)",
        borderColor: "#691C32",
        pointBackgroundColor: colores,
        pointBorderColor: colores,
        pointRadius: 5
      }]
    },
    options: {
      responsive: true,
      scales: {
        r: {
          min: 0,
          max: 100,
          ticks: { stepSize: 20 }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: function(ctx) {
              const v = ctx.raw;
              let nivel = "Bajo";
              if (v >= 67) nivel = "Alto";
              else if (v >= 34) nivel = "Medio";
              return `${nivel}: ${v}%`;
            }
          }
        },
        legend: {
          position: "bottom"
        }
      }

    }
  });
}
</script>


<script>
let radarChart = null;

function calcularRadarFiltrado() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const visibles = new Set();

  filas.forEach(fila => {
    if (fila.style.display !== "none") {
      visibles.add(fila.children[0].textContent.trim()); // ID aplicación
    }
  });

  const acumulado = {};

  datosRadarDetalle.forEach(d => {
    if (!visibles.has(d.aplicacion_id)) return;

    if (!acumulado[d.area]) {
      acumulado[d.area] = [];
    }
    acumulado[d.area].push(parseFloat(d.porcentaje));
  });

  const labels = [];
  const valores = [];
  const colores = [];

  for (const area in acumulado) {
    const avg = acumulado[area].reduce((a,b)=>a+b,0) / acumulado[area].length;

    labels.push(area);
    valores.push(avg.toFixed(2));

    if (avg < 34) colores.push("rgba(40,167,69,0.6)");       // verde
    else if (avg < 67) colores.push("rgba(255,193,7,0.6)"); // amarillo
    else colores.push("rgba(220,53,69,0.6)");               // rojo
  }

  dibujarRadar(labels, valores, colores);
}

function calcularSexoFiltrado() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const conteo = {};

  filas.forEach(fila => {
    if (fila.children.length < 9) return;
    if (fila.style.display === "none") return;

    const sexo = fila.children[3].textContent.trim();
    if (!sexo) return;

    conteo[sexo] = (conteo[sexo] || 0) + 1;
  });

  const labels = Object.keys(conteo);
  const valores = Object.values(conteo);

  if (labels.length === 0) {
    if (sexoChart) sexoChart.destroy();
    return;
  }

  dibujarGraficaSexo(labels, valores);
}
</script>

<script>
  function calcularTotalFiltrado() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  let visibles = 0;

  filas.forEach(fila => {
    if (fila.children.length < 9) return; // ignora "no hay datos"
    if (fila.style.display === "none") return;
    visibles++;
  });

  document.getElementById("totalVisible").textContent = visibles;

  dibujarGraficaTotal(visibles);
}

function dibujarGraficaTotal(total) {
  const ctx = document.getElementById("graficaTotal");

  if (totalChart) {
    totalChart.destroy();
  }

  totalChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Encuestados"],
      datasets: [{
        label: "Total",
        data: [total],
        backgroundColor: "rgba(13,110,253,0.8)",
        borderRadius: 8,
        maxBarThickness: 60
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0
          }
        }
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            label: ctx => `Total: ${ctx.raw}`
          }
        }
      }
    }
  });
}
</script>
<script>
  let riesgoGlobalChart = null;

  function calcularRiesgoGlobal() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const visibles = new Set();

  filas.forEach(f => {
    if (f.style.display !== "none") {
      visibles.add(f.children[0].textContent.trim());
    }
  });

  const porAplicacion = {};

  datosRadarDetalle.forEach(d => {
    if (!visibles.has(d.aplicacion_id)) return;

    if (!porAplicacion[d.aplicacion_id]) {
      porAplicacion[d.aplicacion_id] = [];
    }
    porAplicacion[d.aplicacion_id].push(parseFloat(d.porcentaje));
  });

  let bajo = 0, medio = 0, alto = 0;

  Object.values(porAplicacion).forEach(arr => {
    const avg = arr.reduce((a,b)=>a+b,0) / arr.length;

    if (avg < 34) bajo++;
    else if (avg < 67) medio++;
    else alto++;
  });

  return { bajo, medio, alto };
}

function dibujarRiesgoGlobal() {
  const ctx = document.getElementById("graficaRiesgoGlobal");

  if (riesgoGlobalChart) {
    riesgoGlobalChart.destroy();
  }

  const { bajo, medio, alto } = calcularRiesgoGlobal();

  riesgoGlobalChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Bajo", "Medio", "Alto"],
      datasets: [{
        data: [bajo, medio, alto],
        backgroundColor: ["#28a745", "#ffc107", "#dc3545"]
      }]
    },
    options: {
      plugins: {
        legend: { position: "bottom" }
      }
    }
  });
}
</script>
<script>
  function calcularPromedioGeneral() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const visibles = new Set();

  // Obtener aplicaciones visibles
  filas.forEach(fila => {
    if (fila.children.length < 9) return;
    if (fila.style.display === "none") return;

    visibles.add(fila.children[0].textContent.trim());
  });

  // Agrupar porcentajes por aplicación
  const porAplicacion = {};

  datosRadarDetalle.forEach(d => {
    if (!visibles.has(String(d.aplicacion_id))) return;

    if (!porAplicacion[d.aplicacion_id]) {
      porAplicacion[d.aplicacion_id] = [];
    }
    porAplicacion[d.aplicacion_id].push(parseFloat(d.porcentaje));
  });

  // Calcular promedio por aplicación
  const promedios = [];

  Object.values(porAplicacion).forEach(arr => {
    const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
    promedios.push(avg);
  });

  if (promedios.length === 0) {
    document.getElementById("kpiPromedio").textContent = "0%";
    return;
  }

  // Promedio general
  const promedioGeneral =
    promedios.reduce((a, b) => a + b, 0) / promedios.length;

  document.getElementById("kpiPromedio").textContent =
    promedioGeneral.toFixed(1) + "%";
}
</script>

<script>
let histogramaChart = null;

function calcularDistribucionRiesgo() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const visibles = new Set();

  // Aplicaciones visibles
  filas.forEach(f => {
    if (f.children.length < 9) return;
    if (f.style.display === "none") return;

    visibles.add(f.children[0].textContent.trim());
  });

  // Promedios por aplicación
  const porAplicacion = {};

  datosRadarDetalle.forEach(d => {
    if (!visibles.has(String(d.aplicacion_id))) return;

    if (!porAplicacion[d.aplicacion_id]) {
      porAplicacion[d.aplicacion_id] = [];
    }
    porAplicacion[d.aplicacion_id].push(parseFloat(d.porcentaje));
  });

  // Rangos
  const rangos = {
    "0–20": 0,
    "21–40": 0,
    "41–60": 0,
    "61–80": 0,
    "81–100": 0
  };

  Object.values(porAplicacion).forEach(arr => {
    const avg = arr.reduce((a,b)=>a+b,0) / arr.length;

    if (avg <= 20) rangos["0–20"]++;
    else if (avg <= 40) rangos["21–40"]++;
    else if (avg <= 60) rangos["41–60"]++;
    else if (avg <= 80) rangos["61–80"]++;
    else rangos["81–100"]++;
  });

  dibujarHistogramaRiesgo(rangos);
}
</script>
<script>
function dibujarHistogramaRiesgo(rangos) {
  const ctx = document.getElementById("graficahistogramariesgo");

  if (histogramaChart) {
    histogramaChart.destroy();
  }

  histogramaChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: Object.keys(rangos),
      datasets: [{
        label: "Número de aplicaciones",
        data: Object.values(rangos),
        backgroundColor: [
          "#28a745",
          "#6fbf73",
          "#ffc107",
          "#fd7e14",
          "#dc3545"
        ],
        borderRadius: 6,
        maxBarThickness: 60
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: { precision: 0 }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `${ctx.raw} aplicaciones`
          }
        }
      }
    }
  });
}
</script>
<script>
function obtenerDatosParaTendencia() {
  const filas = document.querySelectorAll("#tablaResultados tr");
  const visibles = new Map(); 
  // aplicacion_id => fecha_aplicacion

  filas.forEach(fila => {
    if (fila.children.length < 9) return;
    if (fila.style.display === "none") return;

    const id = fila.children[0].textContent.trim();
    const fechaTexto = fila.children[8].textContent.trim(); 
    // formato: dd/mm/YYYY HH:mm

    // Convertir a YYYY-MM-DD
    const [fecha, hora] = fechaTexto.split(" ");
    const [d, m, y] = fecha.split("/");
    const fechaISO = `${y}-${m}-${d}`;

    visibles.set(id, fechaISO);
  });

  // Agrupar porcentajes por aplicación
  const porAplicacion = {};

  datosRadarDetalle.forEach(d => {
    const id = String(d.aplicacion_id);
    if (!visibles.has(id)) return;

    if (!porAplicacion[id]) {
      porAplicacion[id] = {
        fecha: visibles.get(id),
        valores: []
      };
    }

    porAplicacion[id].valores.push(parseFloat(d.porcentaje));
  });

  // Convertir a arreglo plano
  const resultado = [];

  Object.values(porAplicacion).forEach(obj => {
    const avg =
      obj.valores.reduce((a, b) => a + b, 0) / obj.valores.length;

    resultado.push({
      fecha: obj.fecha,
      promedio: avg
    });
  });

  return resultado;
}
</script>

<script>
function calcularTendenciaTemporal(datos) {
  const agrupado = {};

  datos.forEach(d => {
    if (!agrupado[d.fecha]) {
      agrupado[d.fecha] = [];
    }
    agrupado[d.fecha].push(d.promedio);
  });

  const fechas = Object.keys(agrupado).sort();
  const promedios = fechas.map(f =>
    agrupado[f].reduce((a,b)=>a+b,0) / agrupado[f].length
  );

  return { fechas, promedios };
}

let graficaTendencia;

function dibujarGraficaTendencia(datosFiltrados) {
  const { fechas, promedios } = calcularTendenciaTemporal(datosFiltrados);

  if (graficaTendencia) {
    graficaTendencia.destroy();
  }

  const ctx = document
    .getElementById("graficaTendenciaRiesgo")
    .getContext("2d");

  graficaTendencia = new Chart(ctx, {
    type: "line",
    data: {
      labels: fechas,
      datasets: [{
        label: "Riesgo promedio",
        borderColor: "#691C32",
        backgroundcolor: "691C32",
        data: promedios,
        tension: 0.3,
        fill: false
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          min: 0,
          max: 100,
          title: {
            display: true,
            text: "Riesgo promedio"
          }
        },
        x: {
          title: {
            display: true,
            text: "Fecha de aplicación"
          }
        }
      }
    }
  });
}

</script>




<script>
(function () {
  // Si el navegador vuelve desde cache (botón atrás)
  window.addEventListener("pageshow", function (event) {
    if (event.persisted) {
      // fuerza recarga real
      window.location.reload();
    }
  });
})();
</script>

</body>
</html>