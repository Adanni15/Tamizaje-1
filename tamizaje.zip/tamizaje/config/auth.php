<?php
/* ==================================================
   🔧 CONFIGURACIÓN BASE
   ================================================== */

// ⚠️ AJUSTA si tu carpeta se llama distinto
define("BASE_URL", "/tamizaje");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ==================================================
   🔐 EVITAR CACHE DE PÁGINAS PRIVADAS
   ================================================== */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

require_once __DIR__ . "/conexion.php";

/* ==================================================
   ⏱️ TIEMPO MÁXIMO DE INACTIVIDAD
   ================================================== */
$TIEMPO_INACTIVIDAD = 15 * 60; // 15 minutos

if (isset($_SESSION["ultimo_acceso"])) {
    if (time() - $_SESSION["ultimo_acceso"] > $TIEMPO_INACTIVIDAD) {
        session_unset();
        session_destroy();
        header("Location: " . BASE_URL . "/iniciarsesion.php?expirada=1");
        exit;
    }
}

/* Actualizar último acceso */
$_SESSION["ultimo_acceso"] = time();

/* ==================================================
   1️⃣ VERIFICAR SESIÓN BÁSICA
   ================================================== */
if (!isset($_SESSION["usuario_id"], $_SESSION["session_version"])) {
    session_destroy();
    header("Location: " . BASE_URL . "/iniciarsesion.php");
    exit;
}

/* ==================================================
   2️⃣ VERIFICAR SESIÓN CONTRA BD
   ================================================== */
$stmt = $conexion->prepare("
    SELECT session_version, activo
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");
$stmt->bind_param("i", $_SESSION["usuario_id"]);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    session_destroy();
    header("Location: " . BASE_URL . "/iniciarsesion.php");
    exit;
}

$usuario = $result->fetch_assoc();

/* ==================================================
   3️⃣ USUARIO DESACTIVADO
   ================================================== */
if ((int)$usuario["activo"] === 0) {
    session_destroy();
    header("Location: " . BASE_URL . "/iniciarsesion.php");
    exit;
}

/* ==================================================
   4️⃣ INVALIDAR SESIONES ANTIGUAS
   ================================================== */
if ((int)$usuario["session_version"] !== (int)$_SESSION["session_version"]) {
    session_destroy();
    header("Location: " . BASE_URL . "/iniciarsesion.php");
    exit;
}

/* ==================================================
   5️⃣ REGENERAR ID DE SESIÓN (ANTI-HIJACKING)
   ================================================== */
if (!isset($_SESSION["session_regenerated"])) {
    session_regenerate_id(true);
    $_SESSION["session_regenerated"] = true;
}
