<?php
session_start();
require_once __DIR__ . "/conexion.php";

/* Validar POST */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: ../iniciarsesion.php");
  exit;
}

$correo   = trim($_POST["correo"] ?? "");
$password = $_POST["password"] ?? "";

if ($correo === "" || $password === "") {
  $_SESSION["login_error"] = "Todos los campos son obligatorios";
  header("Location: ../iniciarsesion.php");
  exit;
}

/* Consulta */
$sql = "
  SELECT 
    u.id,
    u.nombre_completo,
    u.sexo,
    u.password,
    u.activo,
    u.session_version,
    r.nombre AS rol
  FROM usuarios u
  INNER JOIN roles r ON r.id = u.rol_id
  WHERE u.correo = ?
  LIMIT 1
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
  $_SESSION["login_error"] = "Usuario no encontrado";
  header("Location: ../iniciarsesion.php");
  exit;
}

$usuario = $result->fetch_assoc();

/* Verificar contraseña */
if (!password_verify($password, $usuario["password"])) {
  $_SESSION["login_error"] = "Contraseña incorrecta";
  header("Location: ../iniciarsesion.php");
  exit;
}

/* Bloquear usuarios desactivados */
if ((int)$usuario["activo"] === 0) {
  $_SESSION["login_error"] = "Tu cuenta está desactivada. Contacta al administrador.";
  header("Location: ../iniciarsesion.php");
  exit;
}

/* Normalizar rol */
$rol = strtolower(trim($usuario["rol"]));

/* Crear sesión */
$_SESSION["usuario_id"]        = (int)$usuario["id"];
$_SESSION["usuario_nombre"]    = $usuario["nombre_completo"];
$_SESSION["usuario_rol"]       = $rol;
$_SESSION["usuario_sexo"]      = $usuario["sexo"];
$_SESSION["session_version"]   = (int)$usuario["session_version"];
$_SESSION["mostrar_bienvenida"] = true;

/* Redirección segura */
switch ($rol) {

  case "administrador":
    header("Location: ../admin/admin_cuenta.php");
    break;

  case "aplicador":
    header("Location: ../resultados.php");
    break;

  default:
    $_SESSION["login_error"] = "Rol inválido";
    session_destroy();
    header("Location: ../iniciarsesion.php");
}

exit;
