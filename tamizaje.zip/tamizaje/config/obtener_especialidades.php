<?php
require_once "conexion.php";

if (!isset($_GET["escuela_id"]) || !is_numeric($_GET["escuela_id"])) {
  echo json_encode([]);
  exit;
}

$escuelaId = (int)$_GET["escuela_id"];

$stmt = $conexion->prepare("
  SELECT e.nombre
  FROM especialidades e
  INNER JOIN escuela_especialidad ee
    ON ee.especialidad_id = e.id
  WHERE ee.escuela_id = ?
    AND ee.activo = 1
    AND e.activa = 1
  ORDER BY e.nombre
");

$stmt->bind_param("i", $escuelaId);
$stmt->execute();
$result = $stmt->get_result();

$especialidades = [];

while ($row = $result->fetch_assoc()) {
  $especialidades[] = $row;
}

echo json_encode($especialidades);
