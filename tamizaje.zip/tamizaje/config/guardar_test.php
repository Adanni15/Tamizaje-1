<?php
session_start();
require_once "../config/conexion.php";

error_reporting(E_ALL);
ini_set("display_errors", 1);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

/* ==========================
   VALIDACIÓN
========================== */
if (
    empty($data["instrumento_id"]) ||
    empty($data["respuestas"]) ||
    !is_array($data["respuestas"]) ||
    empty($data["datos"]["escuela_id"])
) {
    http_response_code(400);
    echo json_encode(["ok" => false, "error" => "Datos incompletos"]);
    exit;
}
/* ==========================
   VALIDAR ESPECIALIDAD (AQUÍ)
========================== */
$usarEspecialidades = 1; // o lo que ya tengas definido

if ($usarEspecialidades === 1) {
    if (empty($data["datos"]["especialidad"])) {
        echo json_encode([
            "ok" => false,
            "error" => "Debe seleccionar una especialidad válida"
        ]);
        exit;
    }
}

/* ==========================
   IDS (SIN LOGIN)
========================== */
$instrumento_id = (int)$data["instrumento_id"];
$estudiante_id  = 1;
$aplicado_por   = $_SESSION["usuario_id"] ?? 1;

$conexion->begin_transaction();

try {

    /* ==========================
       1️⃣ APLICACIÓN
    ========================== */
    $stmt = $conexion->prepare("
        INSERT INTO aplicaciones
        (estudiante_id, instrumento_id, aplicado_por)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iii", $estudiante_id, $instrumento_id, $aplicado_por);
    $stmt->execute();
    $aplicacion_id = $stmt->insert_id;
    $stmt->close();

    /* ==========================
       2️⃣ DATOS SOCIODEMOGRÁFICOS
    ========================== */
    if (!empty($data["datos"])) {

        $d = $data["datos"];

        $d["escuela_id"] = (int)$d["escuela_id"];

        if ($d["escuela_id"] <= 0) {
            throw new Exception("Escuela inválida");
        }


        // 🔠 NOMBRE EN MAYÚSCULAS
        $d["nombre"] = strtoupper(trim($d["nombre"]));

        // 🔢 EDAD ENTRE 12 Y 18
        $d["edad"] = (int)$d["edad"];
        if ($d["edad"] < 12 || $d["edad"] > 18) {
            throw new Exception("Edad fuera de rango permitido");
        }

        // 🔠 GRUPO: 1 CARÁCTER EN MAYÚSCULAS
        $d["grupo"] = strtoupper(trim($d["grupo"]));
        if (strlen($d["grupo"]) !== 1) {
            throw new Exception("Grupo inválido");
        }

        $stmt = $conexion->prepare("
            INSERT INTO aplicaciones_test
            (escuela_id, instrumento_id, nombre, edad, sexo, turno, grado, grupo, especialidad, aplicacion_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "iisisssssi",
            $d["escuela_id"],
            $instrumento_id,
            $d["nombre"],
            $d["edad"],
            $d["sexo"],
            $d["turno"],
            $d["grado"],
            $d["grupo"],
            $d["especialidad"],
            $aplicacion_id
        );



        $stmt->execute();
        $stmt->close();
    }

    /* ==========================
       3️⃣ ESCALA REAL DEL INSTRUMENTO
    ========================== */
    $stmtEscala = $conexion->prepare("
        SELECT tipo_escala, escala_min, escala_max
        FROM instrumentos
        WHERE id = ?
    ");
    $stmtEscala->bind_param("i", $instrumento_id);
    $stmtEscala->execute();
    $escala = $stmtEscala->get_result()->fetch_assoc();
    $stmtEscala->close();

    if (!$escala) {
        throw new Exception("Instrumento no encontrado");
    }

    $valor_maximo = ($escala["tipo_escala"] === "escala")
        ? (int)$escala["escala_max"]
        : 1;

    /* ==========================
       4️⃣ RESPUESTAS (CON INVERSIÓN)
    ========================== */
    $stmtPregunta = $conexion->prepare("
        SELECT area_id, es_invertida
        FROM preguntas
        WHERE id = ?
    ");

    $stmtRespuesta = $conexion->prepare("
        INSERT INTO respuestas
        (aplicacion_id, area_id, valor, pregunta_id)
        VALUES (?, ?, ?, ?)
    ");

    foreach ($data["respuestas"] as $r) {

        $pregunta_id = (int)$r["pregunta_id"];
        $valor       = (int)$r["valor"];

        $stmtPregunta->bind_param("i", $pregunta_id);
        $stmtPregunta->execute();
        $pregunta = $stmtPregunta->get_result()->fetch_assoc();

        if (!$pregunta) {
            throw new Exception("Pregunta inválida: $pregunta_id");
        }

        $area_id      = (int)$pregunta["area_id"];
        $es_invertida = (int)$pregunta["es_invertida"];

        if ($es_invertida === 1) {
            if ($escala["tipo_escala"] === "escala") {
                $valor = $escala["escala_max"] + $escala["escala_min"] - $valor;
            } else {
                $valor = 1 - $valor;
            }
        }

        $stmtRespuesta->bind_param(
            "iiii",
            $aplicacion_id,
            $area_id,
            $valor,
            $pregunta_id
        );
        $stmtRespuesta->execute();
    }

    $stmtPregunta->close();
    $stmtRespuesta->close();

    /* ==========================
       5️⃣ RESULTADOS
    ========================== */
    $stmt = $conexion->prepare("
        SELECT area_id,
               SUM(valor) AS puntaje,
               COUNT(*) AS total_preguntas
        FROM respuestas
        WHERE aplicacion_id = ?
        GROUP BY area_id
    ");

    $stmt->bind_param("i", $aplicacion_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $stmtIns = $conexion->prepare("
        INSERT INTO resultados
        (aplicacion_id, area_id, puntaje, puntaje_maximo, porcentaje, nivel_riesgo)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    while ($row = $res->fetch_assoc()) {

        $puntaje = (int)$row["puntaje"];
        $puntaje_maximo = $row["total_preguntas"] * $valor_maximo;

        $porcentaje = ($puntaje_maximo > 0)
            ? round(($puntaje / $puntaje_maximo) * 100, 2)
            : 0;

        $nivel = ($porcentaje >= 67) ? "Alto" : (($porcentaje >= 34) ? "Medio" : "Bajo");

        $stmtIns->bind_param(
            "iiiids",
            $aplicacion_id,
            $row["area_id"],
            $puntaje,
            $puntaje_maximo,
            $porcentaje,
            $nivel
        );
        $stmtIns->execute();
    }

    $stmtIns->close();
    $stmt->close();

    $conexion->commit();

    echo json_encode([
        "ok" => true,
        "aplicacion_id" => $aplicacion_id
    ]);

} catch (Throwable $e) {

    $conexion->rollback();
    http_response_code(500);

    echo json_encode([
        "ok" => false,
        "error" => $e->getMessage()
    ]);
}
