<?php
require_once "conexion.php";
session_start();

header("Content-Type: application/json");

// ==========================
// 1. VALIDAR SESIÓN
// ==========================
if (!isset($_SESSION["usuario_id"])) {
  http_response_code(401);
  echo json_encode(["ok" => false, "error" => "Sesión no válida"]);
  exit;
}

// ==========================
// 2. LEER JSON
// ==========================
$data = json_decode(file_get_contents("php://input"), true);

if (
  !$data ||
  !isset($data["instrumento_id"], $data["datos"], $data["respuestas"]) ||
  !is_array($data["respuestas"])
) {
  http_response_code(400);
  echo json_encode(["ok" => false, "error" => "Datos incompletos"]);
  exit;
}

$instrumento_id = (int)$data["instrumento_id"];
$datos = $data["datos"];
$respuestas = $data["respuestas"];

$usuario_id = (int)$_SESSION["usuario_id"];
$estudiante_id = 1; // temporal

$conexion->begin_transaction();

try {

  // ==========================
  // 3. INSERT aplicaciones
  // ==========================
  $stmt = $conexion->prepare("
    INSERT INTO aplicaciones
      (estudiante_id, instrumento_id, aplicado_por)
    VALUES (?, ?, ?)
  ");
  $stmt->bind_param("iii", $estudiante_id, $instrumento_id, $usuario_id);
  $stmt->execute();

  $aplicacion_id = $stmt->insert_id;

  if (!$aplicacion_id) {
    throw new Exception("No se pudo crear la aplicación");
  }

  // ==========================
  // 4. INSERT aplicaciones_test
  // ==========================
  $especialidad = $datos["especialidad"] ?? null;
  if ($especialidad === "" || $especialidad === "null") {
    $especialidad = null;
  }

  $stmt = $conexion->prepare("
    INSERT INTO aplicaciones_test
      (
        aplicacion_id,
        instrumento_id,
        nombre,
        edad,
        sexo,
        turno,
        grado,
        grupo,
        especialidad
      )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ");

  $stmt->bind_param(
    "iisisssss",
    $aplicacion_id,
    $instrumento_id,
    $datos["nombre"],
    $datos["edad"],
    $datos["sexo"],
    $datos["turno"],
    $datos["grado"],
    $datos["grupo"],
    $especialidad
  );

  $stmt->execute();

  // ==========================
  // 5. INSERT respuestas
  // ==========================
  $stmt = $conexion->prepare("
    INSERT INTO respuestas
      (aplicacion_id, area_id, pregunta_id, valor)
    VALUES (?, ?, ?, ?)
  ");

  foreach ($respuestas as $r) {
    $stmt->bind_param(
      "iiii",
      $aplicacion_id,
      $r["area_id"],
      $r["pregunta_id"],
      $r["valor"]
    );
    $stmt->execute();
  }

  // ==========================
  // 6. CALCULAR RESULTADOS
  // ==========================
  $stmt = $conexion->prepare("
    SELECT
      r.area_id,
      SUM(
        CASE
          WHEN p.es_invertida = 1 THEN
            (COALESCE(p.escala_max, 1) + COALESCE(p.escala_min, 0)) - r.valor
          ELSE
            r.valor
        END
      ) AS puntaje,
      ia.punto_corte
    FROM respuestas r
    INNER JOIN preguntas p
      ON p.id = r.pregunta_id
    INNER JOIN instrumento_areas ia
      ON ia.area_id = r.area_id
     AND ia.instrumento_id = ?
    WHERE r.aplicacion_id = ?
    GROUP BY r.area_id, ia.punto_corte
  ");

  $stmt->bind_param("ii", $instrumento_id, $aplicacion_id);
  $stmt->execute();
  $result = $stmt->get_result();

  $stmtInsert = $conexion->prepare("
    INSERT INTO resultados
      (aplicacion_id, area_id, puntaje, tiene_riesgo)
    VALUES (?, ?, ?, ?)
  ");

  while ($row = $result->fetch_assoc()) {
    $tiene_riesgo = ($row["puntaje"] >= $row["punto_corte"]) ? 1 : 0;

    $stmtInsert->bind_param(
      "iiii",
      $aplicacion_id,
      $row["area_id"],
      $row["puntaje"],
      $tiene_riesgo
    );
    $stmtInsert->execute();
  }

  // ==========================
  // 7. COMMIT
  // ==========================
  $conexion->commit();

  echo json_encode([
    "ok" => true,
    "aplicacion_id" => $aplicacion_id
  ]);

} catch (Throwable $e) {

  $conexion->rollback();

  http_response_code(500);
  echo json_encode([
    "ok" => false,
    "error" => $e->getMessage()
  ]);
}
