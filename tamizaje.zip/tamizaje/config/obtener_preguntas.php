<?php
header("Content-Type: application/json");
require_once "conexion.php";

if (!isset($_GET["instrumento_id"])) {
  echo json_encode([]);
  exit;
}

$instrumento_id = (int)$_GET["instrumento_id"];

$sql = "
  SELECT
    id,
    area_id,
    numero,
    texto,
    tipo_respuesta,
    escala_min,
    escala_max
  FROM preguntas
  WHERE instrumento_id = ?
    AND activa = 1
  ORDER BY area_id, numero
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $instrumento_id);
$stmt->execute();

$result = $stmt->get_result();

$preguntas = [];

while ($row = $result->fetch_assoc()) {
  $preguntas[] = $row;
}

echo json_encode($preguntas);
