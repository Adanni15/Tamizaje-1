<?php
require_once "../config/conexion.php";

header("Content-Type: application/json");

$instrumentoId = isset($_GET["instrumento_id"]) ? (int)$_GET["instrumento_id"] : 0;

if ($instrumentoId <= 0) {
    echo json_encode(["error" => "Instrumento inválido"]);
    exit;
}

$sql = "
    SELECT
        p.id AS id,
        p.texto,
        p.es_invertida,
        p.red_flag,
        a.id AS area_id,
        a.nombre AS area_nombre,
        i.tipo_escala AS tipo_respuesta,
        i.escala_min,
        i.escala_max
    FROM preguntas p
    INNER JOIN areas a ON p.area_id = a.id
    INNER JOIN instrumentos i ON a.instrumento_id = i.id
    WHERE i.id = ?
      AND p.activa = 1
    ORDER BY a.id, p.numero
";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "error" => "Error en SQL",
        "detalle" => $conexion->error
    ]);
    exit;
}

$stmt->bind_param("i", $instrumentoId);
$stmt->execute();

$result = $stmt->get_result();
$preguntas = [];

while ($row = $result->fetch_assoc()) {
    // 🔒 Normalización defensiva
    $row["tipo_respuesta"] = $row["tipo_respuesta"] ?? "escala";
    $row["escala_min"] = $row["escala_min"] ?? 1;
    $row["escala_max"] = $row["escala_max"] ?? 10;

    $preguntas[] = $row;
}

$stmt->close();

echo json_encode($preguntas);
