<?php
function registrarLog(
  $conexion,
  $accion,
  $tabla,
  $registroId = null,
  $descripcion = null
) {
  $usuarioId = $_SESSION["usuario_id"] ?? null;
  $usuarioNombre = $_SESSION["usuario_nombre"] ?? null;
  $ip = $_SERVER["REMOTE_ADDR"] ?? null;
  $navegador = $_SERVER["HTTP_USER_AGENT"] ?? null;

  $stmt = $conexion->prepare("
    INSERT INTO logs_sistema
    (usuario_id, usuario_nombre, accion, tabla_afectada, registro_id, descripcion, ip, navegador)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  ");

  $stmt->bind_param(
    "isssisss",
    $usuarioId,
    $usuarioNombre,
    $accion,
    $tabla,
    $registroId,
    $descripcion,
    $ip,
    $navegador
  );

  $stmt->execute();
}
