<?php
require_once "config/conexion.php";
require_once __DIR__ . "/vendor/autoload.php";

use Dompdf\Dompdf;
use Dompdf\Options;

// ==========================
// VALIDAR ID
// ==========================
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("Reporte no válido");
}

$idAplicacionTest = (int) $_GET['id'];

// ==========================
// DATOS DEL ALUMNO + TEST
// ==========================
$sql = "
SELECT
  at.nombre,
  at.edad,
  at.sexo,
  at.turno,
  at.grado,
  at.grupo,
  at.especialidad,
  at.fecha_aplicacion,
  a.id AS aplicacion_id,
  i.nombre AS instrumento
FROM aplicaciones_test at
INNER JOIN aplicaciones a ON a.id = at.aplicacion_id
INNER JOIN instrumentos i ON i.id = at.instrumento_id
WHERE at.id = ?
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $idAplicacionTest);
$stmt->execute();
$alumno = $stmt->get_result()->fetch_assoc();

if (!$alumno) {
  die("Datos no encontrados");
}

// ==========================
// RESULTADOS POR ÁREA
// ==========================
$sqlAreas = "
SELECT
  ar.nombre AS area,
  ROUND(AVG(res.porcentaje),2) AS porcentaje,
  res.nivel_riesgo
FROM resultados res
INNER JOIN areas ar ON ar.id = res.area_id
WHERE res.aplicacion_id = ?
GROUP BY ar.id
ORDER BY ar.id
";

$stmtAreas = $conexion->prepare($sqlAreas);
$stmtAreas->bind_param("i", $alumno['aplicacion_id']);
$stmtAreas->execute();
$areas = $stmtAreas->get_result();

// ==========================
// PROMEDIO TOTAL DEL TEST
// ==========================
$sqlPromedio = "
SELECT ROUND(AVG(porcentaje),2) AS promedio_total
FROM resultados
WHERE aplicacion_id = ?
";

$stmtP = $conexion->prepare($sqlPromedio);
$stmtP->bind_param("i", $alumno['aplicacion_id']);
$stmtP->execute();
$promedioTotal = $stmtP->get_result()->fetch_assoc()['promedio_total'];

// ==========================
// INTERPRETACIÓN PROFESIONAL
// ==========================
if ($promedioTotal < 25) {
  $nivelGlobal = "Sin riesgo";
  $interpretacion = "El análisis global del instrumento no muestra indicadores de riesgo significativos. El resultado se considera dentro de parámetros esperados, sin requerir intervención inmediata.";
}
elseif ($promedioTotal < 50) {
  $nivelGlobal = "Riesgo leve";
  $interpretacion = "Se identifican indicadores de riesgo leves en el resultado global. Se recomienda observación y seguimiento preventivo por parte del área correspondiente.";
}
elseif ($promedioTotal < 75) {
  $nivelGlobal = "Riesgo moderado";
  $interpretacion = "El resultado global presenta indicadores de riesgo moderados. Se sugiere valoración complementaria y seguimiento por personal especializado.";
}
else {
  $nivelGlobal = "Riesgo alto";
  $interpretacion = "El resultado global del instrumento muestra indicadores elevados de riesgo. Se recomienda canalización inmediata y atención especializada conforme a los protocolos institucionales.";
}

// ==========================
// HTML DEL PDF
// ==========================
$logoPath = 'file://' . realpath(__DIR__ . '/img/logo.png');

$html = '
<style>
body { font-family: DejaVu Sans; font-size: 12px; }
h1 { color:#691C32; text-align:center; }
h3 { color:#333; }
table { width:100%; border-collapse: collapse; margin-top:10px; }
th, td { border:1px solid #ccc; padding:6px; }
th { background:#f2f2f2; }
.badge { padding:4px 8px; border-radius:4px; color:#fff; font-weight:bold; }
.alto { background:#dc3545; }
.medio { background:#ffc107; color:#000; }
.bajo { background:#198754; }
.caja { padding:10px; background:#f8f9fa; margin-top:10px; }
</style>

<table width="100%" style="margin-bottom:10px;">
<tr>
  <td width="15%" valign="middle">
    <img src="'.$logoPath.'" width="70">
  </td>

  <td width="55%" valign="middle">
    <strong style="font-size:14px;">
      Centro de Estudios Tecnológicos Industrial y de Servicios No. 96
    </strong><br>
    <span style="font-size:12px;">
      CETis 96
    </span>
  </td>

  <td width="30%" align="right" valign="middle">
    <strong>Sistema de Tamizaje Escolar</strong><br>
    Reporte individual de resultados
  </td>
</tr>
</table>


<hr>

<h1>'.$alumno['instrumento'].'</h1>

<h3>Datos del alumno</h3>
<p>
<strong>Nombre:</strong> '.$alumno['nombre'].'<br>
<strong>Edad:</strong> '.$alumno['edad'].'<br>
<strong>Sexo:</strong> '.$alumno['sexo'].'<br>
<strong>Turno:</strong> '.$alumno['turno'].'<br>
<strong>Grupo:</strong> '.$alumno['grado'].' '.$alumno['grupo'].'<br>
<strong>Especialidad:</strong> '.$alumno['especialidad'].'<br>
<strong>Fecha de aplicación:</strong> '.date("d/m/Y H:i", strtotime($alumno['fecha_aplicacion'])).'
</p>

<h3>Resultado global del instrumento</h3>
<p>
<strong>Promedio total:</strong> '.$promedioTotal.'%<br>
<strong>Nivel global:</strong> '.$nivelGlobal.'
</p>

<h3>Interpretación</h3>
<div class="caja">'.$interpretacion.'</div>

<h3>Resultados por área</h3>
<table>
<thead>
<tr>
  <th>Área</th>
  <th>Porcentaje</th>
  <th>Nivel de riesgo</th>
</tr>
</thead>
<tbody>
';

while ($a = $areas->fetch_assoc()) {
  $clase = strtolower($a['nivel_riesgo']);
  $html .= "
  <tr>
    <td>{$a['area']}</td>
    <td>{$a['porcentaje']}%</td>
    <td><span class='badge {$clase}'>{$a['nivel_riesgo']}</span></td>
  </tr>";
}

$html .= '
</tbody>
</table>

<p style="margin-top:20px;font-size:10px;text-align:center;">
Reporte confidencial | Folio: '.$idAplicacionTest.' | Generado el '.date("d/m/Y H:i").'
</p>
';

// ==========================
// GENERAR PDF
// ==========================
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('chroot', __DIR__);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// ==========================
// MOSTRAR PDF
// ==========================
$dompdf->stream(
  "reporte_{$alumno['nombre']}.pdf",
  ["Attachment" => false]
);
