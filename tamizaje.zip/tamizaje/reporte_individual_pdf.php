<?php
ob_start();
require_once "config/auth.php";
require_once "config/conexion.php";
require_once __DIR__ . "/vendor/autoload.php";

use Dompdf\Dompdf;
use Dompdf\Options;

// Validar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    die("Debe iniciar sesión para generar el reporte.");
}

$usuario_id = $_SESSION['usuario_id'];

// ==========================
// VALIDAR ID
// ==========================
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("Reporte no válido");
}

$idAplicacionTest = (int) $_GET['id'];

$modo = $_GET['modo'] ?? 'ver';

// ==========================
// DATOS DEL ALUMNO + TEST
// ==========================
$sql = "
SELECT
  at.nombre,
  at.edad,
  at.sexo,
  at.turno,
  at.grado,
  at.grupo,
  at.especialidad,
  at.fecha_aplicacion,
  a.id AS aplicacion_id,
  i.id AS instrumento_id,
  i.nombre AS instrumento,
  e.id AS escuela_id,
  e.nombre AS escuela
FROM aplicaciones_test at
INNER JOIN aplicaciones a ON a.id = at.aplicacion_id
INNER JOIN instrumentos i ON i.id = at.instrumento_id
LEFT JOIN escuelas e ON e.id = at.escuela_id
WHERE at.id = ?
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $idAplicacionTest);
$stmt->execute();
$alumno = $stmt->get_result()->fetch_assoc();

if (!$alumno) {
  die("Datos no encontrados");
}

// ==========================
// RESULTADOS POR ÁREA (CORREGIDO)
// ==========================
$sqlAreas = "
SELECT
  ar.nombre AS area,
  ROUND(AVG(res.porcentaje),2) AS porcentaje,
  MAX(res.nivel_riesgo) AS nivel_riesgo
FROM resultados res
INNER JOIN areas ar ON ar.id = res.area_id
WHERE res.aplicacion_id = ?
GROUP BY ar.id, ar.nombre
ORDER BY FIELD(ar.nombre,
  'Uso/abuso de sustancias',
  'Salud mental',
  'Relaciones familiares',
  'Relaciones con amigos',
  'Nivel educativo',
  'Interés laboral',
  'Conducta agresiva/delictiva'
)
";

$stmtAreas = $conexion->prepare($sqlAreas);
$stmtAreas->bind_param("i", $alumno['aplicacion_id']);
$stmtAreas->execute();
$areas = $stmtAreas->get_result();

// ==========================
// PROMEDIO TOTAL DEL TEST
// ==========================
$sqlPromedio = "
SELECT ROUND(AVG(porcentaje),2) AS promedio_total
FROM resultados
WHERE aplicacion_id = ?
";

$stmtP = $conexion->prepare($sqlPromedio);
$stmtP->bind_param("i", $alumno['aplicacion_id']);
$stmtP->execute();
$promedioTotal = $stmtP->get_result()->fetch_assoc()['promedio_total'];

// ==========================
// INTERPRETACIÓN PROFESIONAL
// ==========================
if ($promedioTotal < 25) {
  $nivelGlobal = "Sin indicadores clínicamente significativos";
  $interpretacion = "
  El perfil obtenido a partir del instrumento aplicado no evidencia la presencia de indicadores de riesgo psicológico
  clínicamente relevantes al momento de la evaluación. Los resultados se encuentran dentro de parámetros esperados
  para la población adolescente, sugiriendo un funcionamiento emocional y conductual adecuado en las áreas evaluadas.

  De acuerdo con el enfoque del instrumento, estos resultados no indican la necesidad de intervención especializada.
  No obstante, se recomienda mantener acciones preventivas y promover factores protectores que favorezcan el bienestar
  emocional y social del alumno.
  ";

}
elseif ($promedioTotal < 50) {
  $nivelGlobal = "Indicadores de riesgo leve";
  $interpretacion = "
  El análisis global del instrumento aplicado muestra la presencia de indicadores leves de riesgo psicológico.
  Estos hallazgos pueden estar asociados a dificultades situacionales, procesos adaptativos propios de la etapa
  del desarrollo o manifestaciones transitorias de malestar emocional.

  Si bien los resultados no sugieren afectación significativa del funcionamiento general, se recomienda seguimiento
  preventivo y orientación psicoeducativa, con el objetivo de fortalecer habilidades socioemocionales y factores
  protectores.
  ";

}
elseif ($promedioTotal < 75) {
  $nivelGlobal = "Indicadores de riesgo moderado";
  $interpretacion = "
  El resultado global del instrumento, indica la presencia de indicadores de riesgo psicológico de intensidad moderada,
  los cuales podrían estar influyendo de manera parcial en el bienestar emocional, conductual o social del alumno.

  De acuerdo con el propósito del intrumento aplicado como instrumento de tamizaje, estos resultados no constituyen un diagnóstico
  clínico, pero sí sugieren la conveniencia de realizar una valoración psicológica complementaria que permita profundizar
  en las áreas identificadas y determinar la pertinencia de intervenciones específicas.
  ";
}
else {
  $nivelGlobal = "Indicadores de riesgo elevado";
  $interpretacion = "
  El perfil obtenido a partir del instrumento aplicado muestra indicadores elevados de riesgo psicológico, lo cual sugiere
  una alta probabilidad de presencia de dificultades emocionales, conductuales o sociales que podrían estar afectando
  de manera significativa el bienestar del alumno.

  Estos resultados requieren atención prioritaria y la realización de una valoración psicológica integral por personal
  especializado, con el fin de identificar con mayor precisión las necesidades del evaluado y establecer un plan de
  intervención acorde, conforme a los lineamientos institucionales correspondientes.
  ";
}

// ==========================
// DATOS PARA RADAR
// ==========================
$sqlRadar = "
SELECT
  ar.nombre AS area,
  ROUND(AVG(res.porcentaje),2) AS porcentaje
FROM resultados res
INNER JOIN areas ar ON ar.id = res.area_id
WHERE res.aplicacion_id = ?
GROUP BY ar.id, ar.nombre
ORDER BY ar.id
";

$stmtRadar = $conexion->prepare($sqlRadar);
$stmtRadar->bind_param("i", $alumno['aplicacion_id']);
$stmtRadar->execute();
$resRadar = $stmtRadar->get_result();

$labelsRadar = [];
$valoresRadar = [];

while ($r = $resRadar->fetch_assoc()) {
  $labelsRadar[] = $r['area'];
  $valoresRadar[] = $r['porcentaje'];
}

$chartConfig = [
  "type" => "radar",
  "data" => [
    "labels" => $labelsRadar,
    "datasets" => [[
      "label" => "Riesgo por área (%)",
      "data" => $valoresRadar,
      "backgroundColor" => "rgba(105,28,50,0.2)",
      "borderColor" => "#691C32",
      "pointBackgroundColor" => "#691C32",
      "borderWidth" => 2
    ]]
  ]
];

$chartUrl = "https://quickchart.io/chart?c=" . urlencode(json_encode($chartConfig));

// ==========================
// (EL RESTO DEL ARCHIVO NO SE TOCA)
// ==========================


// ==========================
// HTML DEL PDF
// ==========================
$logoPath = 'file://' . realpath(__DIR__ . '/img/logo.png');

$html = '
<style>
body {
  font-family: DejaVu Sans;
  font-size: 11px;
  margin: 20px;
}

h1 {
  color:#691C32;
  text-align:center;
  font-size: 16px;
  margin: 6px 0;
}

h3 {
  color:#333;
  font-size: 13px;
  margin: 8px 0 4px;
}

p {
  margin: 3px 0;
}

table {
  width:100%;
  border-collapse: collapse;
  margin-top:6px;
}

th, td {
  border:1px solid #ccc;
  padding:4px;
  font-size:10.5px;
}

th {
  background:#f2f2f2;
}

.badge {
  padding:2px 6px;
  border-radius:4px;
  color:#fff;
  font-weight:bold;
  font-size:10px;
}

.alto { background:#dc3545; }
.medio { background:#ffc107; color:#000; }
.bajo { background:#198754; }

.caja {
  padding:6px;
  background:#f8f9fa;
  margin-top:5px;
  font-size:11px;
}
</style>


<table width="100%" style="margin-bottom:10px;">
<tr>
  <td width="15%" valign="middle">
    <img src="'.$logoPath.'" width="70">
  </td>

  <td width="55%" valign="middle">
    <strong style="font-size:14px;">
      Centro de Estudios Tecnológicos Industrial y de Servicios No. 96
    </strong><br>
    <span style="font-size:12px;">
      CETis 96
    </span>
  </td>

  <td width="30%" align="right" valign="middle">
    <strong>Sistema de Tamizaje Escolar</strong><br>
    Reporte individual de resultados
  </td>
</tr>
</table>


<hr>

<h1>'.$alumno['instrumento'].'</h1>

<h3>Datos del alumno</h3>
<p>
<strong>Escuela:</strong> '.($alumno['escuela'] ?? 'No especificada').'<br>
<strong>Nombre:</strong> '.$alumno['nombre'].'<br>
<strong>Edad:</strong> '.$alumno['edad'].'<br>
<strong>Sexo:</strong> '.$alumno['sexo'].'<br>
<strong>Turno:</strong> '.$alumno['turno'].'<br>
<strong>Grupo:</strong> '.$alumno['grado'].' '.$alumno['grupo'].'<br>
<strong>Especialidad:</strong> '.$alumno['especialidad'].'<br>
<strong>Fecha de aplicación:</strong> '.date("d/m/Y H:i", strtotime($alumno['fecha_aplicacion'])).'
</p>

<h3>Resultado global del instrumento</h3>
<p>
<strong>Promedio total:</strong> '.$promedioTotal.'%<br>
</p>

<h3>Interpretación</h3>
<div class="caja">'.$interpretacion.'</div>

<h3>Perfil de riesgo por área</h3>

<div style="text-align:center;margin-top:10px;">
  <img src="'.$chartUrl.'" width="310">
</div>

<h3>Resultados por área</h3>
<table>
<thead>
<tr>
  <th>Área</th>
  <th>Porcentaje</th>
  <th>Nivel de riesgo</th>
</tr>
</thead>
<tbody>
';

while ($a = $areas->fetch_assoc()) {
  $clase = strtolower($a['nivel_riesgo']);
  $html .= "
  <tr>
    <td>{$a['area']}</td>
    <td>{$a['porcentaje']}%</td>
    <td><span class='badge {$clase}'>{$a['nivel_riesgo']}</span></td>
  </tr>";
}


$html .= '
</tbody>
</table>

<p style="margin-top:20px;font-size:10px;text-align:center;">
Reporte confidencial | Folio: '.$idAplicacionTest.' | Generado el '.date("d/m/Y H:i").'
</p>
';

// ==========================
// GENERAR PDF
// ==========================
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('chroot', __DIR__);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// ==========================
// GUARDAR PDF SOLO SI MODO = guardar
// ==========================
if ($modo === 'guardar') {

    $carpeta = __DIR__ . "/reportes/";
    if (!is_dir($carpeta)) {
        mkdir($carpeta, 0777, true);
    }

    $nombreArchivo = "reporte_{$idAplicacionTest}.pdf";
    $rutaFisica = $carpeta . $nombreArchivo;

    file_put_contents($rutaFisica, $dompdf->output());
}


// ==========================
// GUARDAR REGISTRO EN BD
// ==========================
if ($modo === 'guardar') {
  $rutaRelativa = "reportes/" . $nombreArchivo;
  $usuario_id = $_SESSION['usuario_id'];

  // Si la escuela es NULL, usar 0 o dejar NULL
  $escuela_id = $alumno['escuela_id'] ?? NULL;

  $sqlReporte = "
  INSERT INTO reportes (
      aplicacion_test_id,
      aplicacion_id,
      escuela_id,
      grado,
      grupo,
      nombre_alumno,
      instrumento_id,
      ruta_pdf,
      generado_por
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON DUPLICATE KEY UPDATE
      ruta_pdf = VALUES(ruta_pdf),
      fecha_generacion = CURRENT_TIMESTAMP,
      generado_por = VALUES(generado_por)
  ";

  $stmtReporte = $conexion->prepare($sqlReporte);

  // Bind de parámetros con NULL seguro
  $stmtReporte->bind_param(
      "iiisssisi",
      $idAplicacionTest,
      $alumno['aplicacion_id'],
      $escuela_id,
      $alumno['grado'],
      $alumno['grupo'],
      $alumno['nombre'],
      $alumno['instrumento_id'],
      $rutaRelativa,
      $usuario_id
  );

  if (!$stmtReporte->execute()) {
      die("Error al guardar en reportes: " . $stmtReporte->error);
  }
}

// ==========================
// MOSTRAR PDF EN NAVEGADOR
// ==========================
// Limpiar cualquier salida previa
ob_end_clean(); 

// Definir el nombre del PDF que se mostrará en el navegador
$nombrePDF = "reporte_" . preg_replace('/[^A-Za-z0-9]/', '_', $alumno['nombre']) . ".pdf";

// Mostrar PDF directamente en el navegador (sin descargarlo)
$dompdf->stream($nombrePDF, ["Attachment" => false]);
exit;
