<?php
require_once "config/auth.php";

$logueado = true;
$rol = $_SESSION["usuario_rol"];
?>


<!doctype html>
<html lang="es">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>

        <!-- Boton hamburguesa -->
        <input type="checkbox" id="menu" />
        <div class="menu-btn">
          <label for="menu" aria-label="Abrir menú">
            <!-- Menu animado -->
             <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
              <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                <path class="line top" d="M3 7h18"></path>
                <path class="line mid" d="M3 12h18"></path>
                <path class="line bot" d="M3 17h18"></path>
              </g>
            </svg>
          </label>
        </div>


        <!-- Navbar -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="index.php">Test</a></li>
            <li><a href="acercade.php">Acerca de</a></li>

            <?php if ($logueado): ?>
              <li><a href="resultados.php">Resultados</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <ul class="logout-menu">
          <?php if ($logueado && $rol === "administrador"): ?>
              <a href="admin/admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <?php else: ?>
              <a href="admin/mi_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <?php endif; ?>
          
          <?php if ($logueado): ?>
            <li><a href="config/logout.php" class="logout">Cerrar sesión</a></li>
          <?php else: ?>
            <li><a href="iniciarsesion.php" class="logout">Iniciar sesión</a></li>
          <?php endif; ?>
        </ul>

      </nav>
      </div>
    </div>
  </header>
  <main class="container my-5">

  <h2 class="text-center mb-4">Resultados del Test POSIT</h2>
  
  <!-- FILTROS -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form id="filtrosForm" class="row g-3">

        <div class="col-md-4">
          <input type="text" id="buscarNombre" class="form-control" placeholder="Buscar por nombre">
        </div>

        <div class="col-md-2">
          <select id="filtroSexo" class="form-select">
            <option value="">Sexo</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="edadMin" class="form-select">
            <option value="">Edad mín</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="edadMax" class="form-select">
            <option value="">Edad máx</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroTurno" class="form-select">
            <option value="">Turno</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroEspecialidad" class="form-select">
            <option value="">Especialidad</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroGrupo" class="form-select">
            <option value="">Grupo</option>
          </select>
        </div>

        <div class="col-12 text-end">
          <button type="button" class="btn btn-primary px-4" id="aplicarFiltros">
            Aplicar filtros
          </button>
          <button type="button" class="btn btn-secondary" id="limpiarFiltros">
            Limpiar
          </button>
        </div>

      </form>
    </div>
  </div>

  <!-- TABLA DE RESULTADOS -->
   <div class="card shadow-sm mb-5">
    <div class="card-body">
      <h5 class="card-title mb-3">Encuestados</h5>

        <div class="table-responsive tabla-scroll">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Sexo</th>
                <th>Turno</th>
                <th>Grado</th>
                <th>Grupo</th>
                <th>Especialidad</th>
                <th>Fecha y hora de realización</th>
              </tr>
            </thead>
            <tbody id="tablaResultados">
              <!-- Aquí irá el contenido dinámico -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- SEPARADOR RESULTADOS GENERALES -->
     <div class="separador-resultados my-5">
      <span>Resultados generales</span>
    </div>




<div class="row g-4">

  <!-- Radar POSIT (solo grupo + especialidad) -->
  <div id="contenedorRadar" class="col-12" style="display:none;">
    <div class="card shadow-sm card-grafica-lg">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">
          Perfil de riesgo POSIT por área
        </h5>
        <p class="subtitulo-grafica text-center" id="infoRadar">
        </p>
        <canvas id="graficaRadarAreas"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica 1: Resultados generales -->
  <div class="col-md-6">
    <div class="card shadow-sm card-grafica">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">Resultados generales</h5>
        <p class="subtitulo-grafica">
          Estado global del tamizaje POSIT
        </p>
        <canvas id="graficaGeneral"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica 2: Distribución por sexo -->
  <div class="col-md-6">
    <div class="card shadow-sm card-grafica">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">Distribución por sexo</h5>
        <p class="subtitulo-grafica">
          Total de encuestados por sexo
        </p>
        <canvas id="graficaSexo"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica por áreas POSIT -->
  <div class="col-12">
    <div class="card shadow-sm card-grafica-lg">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">Riesgo por área POSIT</h5>
        <p class="subtitulo-grafica">
          Estudiantes con indicadores positivos por área
        </p>
        <canvas id="graficaAreas"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica: Riesgo por sexo -->
  <div class="col-md-6">
    <div class="card shadow-sm card-grafica">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">
          Comparación de riesgo por sexo
        </h5>
        <p class="subtitulo-grafica">
          Estudiantes con y sin indicadores de riesgo
        </p>
        <canvas id="graficaRiesgoSexo"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica: Riesgo por turno -->
  <div class="col-md-6">
    <div class="card shadow-sm card-grafica">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">
          Riesgo por turno
        </h5>
        <p class="subtitulo-grafica">
          Estudiantes con al menos un área POSIT en riesgo
        </p>
        <canvas id="graficaRiesgoTurno"></canvas>
      </div>
    </div>
  </div>
  <!-- Gráfica: Riesgo por grado -->
  <div class="col-md-6">
    <div class="card shadow-sm card-grafica">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">
          Riesgo por grado escolar
        </h5>
        <p class="subtitulo-grafica">
          Estudiantes con al menos un área POSIT en riesgo
        </p>
        <canvas id="graficaRiesgoGrado"></canvas>
      </div>
    </div>
  </div>
  <!-- Evolución temporal del riesgo -->
  <div class="col-12">
    <div class="card shadow-sm card-grafica-lg">
      <div class="card-body">
        <h5 class="titulo-grafica text-center">
          Evolución temporal del riesgo POSIT
        </h5>
        <p class="subtitulo-grafica text-center">
          Porcentaje de estudiantes con indicadores de riesgo a lo largo del tiempo
        </p>
        <canvas id="graficaRiesgoTiempo"></canvas>
      </div>
    </div>
  </div>




</div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
let graficaGeneral = null;
let graficaSexo = null;
let graficaAreas = null;
let relacionesGrupoEspecialidad = [];
let graficaRiesgoSexo = null;
let graficaRiesgoTurno = null;
let graficaRiesgoGrado = null;
let graficaPerfilPromedio = null;
let graficaRiesgoTiempo = null;
let edadesDisponibles = [];


const tabla = document.getElementById("tablaResultados");
const buscarNombre = document.getElementById("buscarNombre");
const filtroSexo = document.getElementById("filtroSexo");
const filtroTurno = document.getElementById("filtroTurno");
const filtroGrupo = document.getElementById("filtroGrupo");
const filtroEspecialidad = document.getElementById("filtroEspecialidad");
</script>

<script>
async function cargarFiltros() {
  const res = await fetch("api/obtener_resultados.php?accion=filtros");
  const data = await res.json();
  const edadMin = document.getElementById("edadMin");
  const edadMax = document.getElementById("edadMax");

  relacionesGrupoEspecialidad = data.relaciones || [];

  // SEXO
  filtroSexo.innerHTML = '<option value="">Sexo</option>';
  data.sexo.forEach(s => {
    filtroSexo.innerHTML += `<option value="${s.sexo}">${s.sexo}</option>`;
  });

  // TURNO
  filtroTurno.innerHTML = '<option value="">Turno</option>';
  data.turno.forEach(t => {
    filtroTurno.innerHTML += `<option value="${t.turno}">${t.turno}</option>`;
  });

  // ESPECIALIDAD (carga inicial)
  filtroEspecialidad.innerHTML = '<option value="">Especialidad</option>';
  data.especialidad.forEach(e => {
    filtroEspecialidad.innerHTML += `<option value="${e.especialidad}">${e.especialidad}</option>`;
  });

  // GRUPO (carga inicial)
  filtroGrupo.innerHTML = '<option value="">Grupo</option>';
  (data.grupos || []).forEach(g => {
    filtroGrupo.innerHTML += `<option value="${g.grupo}">${g.grupo}</option>`;
  });

  // Cargar edades disponibles
  edadMin.innerHTML = '<option value="">Edad mín</option>';
  edadMax.innerHTML = '<option value="">Edad máx</option>';

  edadesDisponibles = data.edades || [];

  edadMin.innerHTML = '<option value="">Edad mín</option>';
  edadMax.innerHTML = '<option value="">Edad máx</option>';

  edadesDisponibles.forEach(e => {
    edadMin.innerHTML += `<option value="${e}">${e}</option>`;
  });



}
</script>

<script>
const edadMin = document.getElementById("edadMin");
const edadMax = document.getElementById("edadMax");

edadMin.addEventListener("change", () => {
  const min = parseInt(edadMin.value);

  // resetear edad max
  edadMax.innerHTML = '<option value="">Edad máx</option>';

  // cargar solo edades >= edad mínima
  edadesDisponibles
    .filter(e => isNaN(min) || e >= min)
    .forEach(e => {
      edadMax.innerHTML += `<option value="${e}">${e}</option>`;
    });

  edadMax.value = "";
});
</script>



<script>
async function cargarResultados() {
  const params = new URLSearchParams();

  if (buscarNombre.value.trim() !== "") {
    params.append("nombre", buscarNombre.value.trim());
  }
  if (filtroSexo.value !== "") {
    params.append("sexo", filtroSexo.value);
  }
  if (filtroTurno.value !== "") {
    params.append("turno", filtroTurno.value);
  }
  if (filtroGrupo.value.trim() !== "") {
    params.append("grupo", filtroGrupo.value.trim());
  }
  if (filtroEspecialidad.value !== "") {
    params.append("especialidad", filtroEspecialidad.value);
  }

  const res = await fetch("api/obtener_resultados.php?" + params.toString());
  const data = await res.json();

  tabla.innerHTML = "";
  
  if (!Array.isArray(data) || data.length === 0) {
    tabla.innerHTML = `
    <tr>
    <td colspan="9" class="text-center text-muted">
    No se encontraron resultados
      </td>
    </tr>`;
    if (graficaGeneral) graficaGeneral.destroy();
    if (graficaSexo) graficaSexo.destroy();
    if (graficaAreas) graficaAreas.destroy();
    
    return;
  }
  if (edadMin.value || edadMax.value) {
    params.append("edad_min", edadMin.value || "");
    params.append("edad_max", edadMax.value || "");
  }


  data.forEach(r => {
    tabla.innerHTML += `
      <tr>
        <td>${r.id}</td>
        <td>
        <a href="resultado_alumno.php?id=${r.id}" class="nombre-alumno">
        ${r.nombre}
        </a>
        </td>
        <td>${r.edad}</td>
        <td>${r.sexo}</td>
        <td>${r.turno}</td>
        <td>${r.grado}</td>
        <td>${r.grupo}</td>
        <td>${r.especialidad}</td>
        <td>${r.fecha_registro}</td>
      </tr>
    `;
  });

  const resumen = calcularResumen(data);
  renderGraficas(resumen);
  cargarGraficaAreas();
  cargarGraficaRadar();
  cargarGraficaRiesgoSexo();
  cargarGraficaRiesgoTurno();
  cargarGraficaRiesgoGrado();
  cargarGraficaPerfilPromedio();
  cargarGraficaRiesgoTiempo();


}


filtroEspecialidad.addEventListener("change", () => {
  const esp = filtroEspecialidad.value;

  filtroGrupo.innerHTML = '<option value="">Grupo</option>';

  relacionesGrupoEspecialidad
    .filter(r => !esp || r.especialidad === esp)
    .map(r => r.grupo)
    .filter((v, i, a) => a.indexOf(v) === i)
    .forEach(grupo => {
      filtroGrupo.innerHTML += `<option value="${grupo}">${grupo}</option>`;
    });
    filtroGrupo.value = "";
});
</script>

<script>
document.addEventListener("DOMContentLoaded", () => {

  document.getElementById("aplicarFiltros")
    .addEventListener("click", cargarResultados);

    document.getElementById("limpiarFiltros")
      .addEventListener("click", () => {
        document.getElementById("filtrosForm").reset();
      
        // 👇 ocultar radar correctamente
        const contenedor = document.getElementById("contenedorRadar");
        contenedor.style.display = "none";
        if (radarChart) {
          radarChart.destroy();
          radarChart = null;
        }
      
        cargarResultados();
      });


  cargarFiltros();
  cargarResultados();

});
</script>




<script>
function calcularResumen(data) {
  let conRiesgo = 0;
  let sinRiesgo = 0;

  let porSexo = {
    Masculino: 0,
    Femenino: 0,
    Otro: 0
  };

  data.forEach(r => {

    // === LÓGICA CORRECTA DE RIESGO ===
    if (parseInt(r.tiene_riesgo) === 1) {
      conRiesgo++;
    } else {
      sinRiesgo++;
    }


    // Conteo por sexo
    if (porSexo[r.sexo] !== undefined) {
      porSexo[r.sexo]++;
    }
  });

  return { conRiesgo, sinRiesgo, porSexo };
}
</script>





<script>
function renderGraficas(resumen) {

  /* ----------- GRAFICA GENERAL ----------- */
  if (graficaGeneral) graficaGeneral.destroy();

  graficaGeneral = new Chart(
    document.getElementById("graficaGeneral"),
    {
      type: "doughnut",
      data: {
        labels: ["Con riesgo", "Sin riesgo"],
        datasets: [{
          data: [resumen.conRiesgo, resumen.sinRiesgo],
          borderWidth: 1
        }]
      },
      options: { responsive: true }
    }
  );

  /* ----------- GRAFICA POR SEXO ----------- */
  if (graficaSexo) graficaSexo.destroy();

  graficaSexo = new Chart(
    document.getElementById("graficaSexo"),
    {
      type: "bar",
      data: {
        labels: Object.keys(resumen.porSexo),
        datasets: [{
          label: "Total de encuestados",
          data: Object.values(resumen.porSexo),
          borderWidth: 1
        }]
      },
      options: { responsive: true }
    }
  );
}
</script>

<script>
async function cargarGraficaAreas() {

  const params = new URLSearchParams();

  if (buscarNombre.value.trim()) {
    params.append("nombre", buscarNombre.value.trim());
  }
  if (filtroSexo.value) {
    params.append("sexo", filtroSexo.value);
  }
  if (filtroTurno.value) {
    params.append("turno", filtroTurno.value);
  }
  if (filtroGrupo.value.trim()) {
    params.append("grupo", filtroGrupo.value.trim());
  }
  if (filtroEspecialidad.value) {
    params.append("especialidad", filtroEspecialidad.value);
  }

  const res = await fetch(
    "api/obtener_grafica_areas.php?" + params.toString()
  );
  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaAreas) graficaAreas.destroy();
    return;
  }

  const labels = data.map(d => d.area);
  const valores = data.map(d => d.total_riesgo);

  if (graficaAreas) graficaAreas.destroy();

  graficaAreas = new Chart(
    document.getElementById("graficaAreas"),
    {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Estudiantes con riesgo",
          data: valores,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    }
  );
}

</script>

<script>
let radarChart = null;

function cargarGraficaRadar() {

  const especialidad = document.getElementById("filtroEspecialidad")?.value;
  const grupo = document.getElementById("filtroGrupo")?.value;

  const contenedor = document.getElementById("contenedorRadar");
  const infoRadar = document.getElementById("infoRadar");

  
  if (!especialidad || !grupo) {
    contenedor.style.display = "none";

    if (radarChart) {
      radarChart.destroy();
      radarChart = null;
    }

    if (infoRadar) infoRadar.innerHTML = "";
    return;
  }

  // Mostrar contenedor
  contenedor.style.display = "block";

  // Texto descriptivo profesional
  infoRadar.innerHTML = `
    <strong>Especialidad:</strong> ${especialidad} &nbsp;|&nbsp;
    <strong>Grupo:</strong> ${grupo}
  `;

  // Parámetros para el backend
  const params = new URLSearchParams({
    especialidad,
    grupo,
    sexo: document.getElementById("filtroSexo")?.value || "",
    turno: document.getElementById("filtroTurno")?.value || ""
  });

  fetch("api/obtener_grafica_areas.php?" + params.toString())
    .then(res => res.json())
    .then(data => {

      if (!Array.isArray(data) || data.length === 0) {
        contenedor.style.display = "none";
        return;
      }

      const labels = data.map(d => d.area);
      const valores = data.map(d => d.total_riesgo);

      const ctx = document
        .getElementById("graficaRadarAreas")
        .getContext("2d");

      if (radarChart) radarChart.destroy();

      radarChart = new Chart(ctx, {
        type: "radar",
        data: {
          labels: labels,
          datasets: [{
            label: "Estudiantes en riesgo",
            data: valores,
            fill: true,
            backgroundColor: "rgba(105, 28, 50, 0.2)",
            borderColor: "#691C32",
            borderWidth: 2,
            pointBackgroundColor: "#691C32",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "#691C32"
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            r: {
              beginAtZero: true,
              ticks: {
                stepSize: 1,
                backdropColor: "transparent"
              },
              pointLabels: {
                font: {
                  size: 12,
                  weight: "bold"
                }
              }
            }
          },
          plugins: {
            legend: {
              position: "top"
            }
          }
        }
      });
    })
    .catch(err => {
      console.error("Error al cargar radar:", err);
      contenedor.style.display = "none";
    });
    
    }
</script>

<script>
  async function cargarGraficaRiesgoSexo() {

  const params = new URLSearchParams();

  if (filtroTurno.value) params.append("turno", filtroTurno.value);
  if (filtroGrupo.value) params.append("grupo", filtroGrupo.value);
  if (filtroEspecialidad.value) params.append("especialidad", filtroEspecialidad.value);

  const res = await fetch(
    "api/obtener_grafica_riesgo_sexo.php?" + params.toString()
  );

  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaRiesgoSexo) graficaRiesgoSexo.destroy();
    return;
  }

  const labels = data.map(d => d.sexo);
  const conRiesgo = data.map(d => d.con_riesgo);
  const sinRiesgo = data.map(d => d.sin_riesgo);

  if (graficaRiesgoSexo) graficaRiesgoSexo.destroy();

  graficaRiesgoSexo = new Chart(
    document.getElementById("graficaRiesgoSexo"),
    {
      type: "bar",
      data: {
        labels: labels,
        datasets: [
          {
            label: "Con riesgo",
            data: conRiesgo,
            borderWidth: 1
          },
          {
            label: "Sin riesgo",
            data: sinRiesgo,
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    }
  );
}
</script>

<script>
async function cargarGraficaRiesgoTurno() {

  const params = new URLSearchParams();

  if (filtroSexo.value) params.append("sexo", filtroSexo.value);
  if (filtroGrupo.value) params.append("grupo", filtroGrupo.value);
  if (filtroEspecialidad.value) params.append("especialidad", filtroEspecialidad.value);

  const res = await fetch(
    "api/obtener_grafica_riesgo_turno.php?" + params.toString()
  );

  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaRiesgoTurno) graficaRiesgoTurno.destroy();
    return;
  }

  const labels = data.map(d => d.turno);
  const valores = data.map(d => d.total);

  if (graficaRiesgoTurno) graficaRiesgoTurno.destroy();

  graficaRiesgoTurno = new Chart(
    document.getElementById("graficaRiesgoTurno"),
    {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Estudiantes con riesgo",
          data: valores,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    }
  );
}
</script>

<script>
  async function cargarGraficaRiesgoGrado() {

  const params = new URLSearchParams();

  if (filtroSexo.value) params.append("sexo", filtroSexo.value);
  if (filtroTurno.value) params.append("turno", filtroTurno.value);
  if (filtroGrupo.value) params.append("grupo", filtroGrupo.value);
  if (filtroEspecialidad.value) params.append("especialidad", filtroEspecialidad.value);

  const res = await fetch(
    "api/obtener_grafica_riesgo_grado.php?" + params.toString()
  );

  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaRiesgoGrado) graficaRiesgoGrado.destroy();
    return;
  }

  const labels = data.map(d => d.grado);
  const valores = data.map(d => d.total);

  if (graficaRiesgoGrado) graficaRiesgoGrado.destroy();

  graficaRiesgoGrado = new Chart(
    document.getElementById("graficaRiesgoGrado"),
    {
      type: "bar",
      data: {
        labels,
        datasets: [{
          label: "Estudiantes con riesgo",
          data: valores,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    }
  );
}
</script>
<script>
  async function cargarGraficaPerfilPromedio() {

  const params = new URLSearchParams();

  if (filtroSexo.value) params.append("sexo", filtroSexo.value);
  if (filtroTurno.value) params.append("turno", filtroTurno.value);
  if (filtroGrupo.value) params.append("grupo", filtroGrupo.value);
  if (filtroEspecialidad.value) params.append("especialidad", filtroEspecialidad.value);

  const res = await fetch(
    "api/obtener_grafica_perfil_promedio.php?" + params.toString()
  );

  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaPerfilPromedio) graficaPerfilPromedio.destroy();
    return;
  }

  const labels = data.map(d => d.area);
  const valores = data.map(d => d.promedio);

  if (graficaPerfilPromedio) graficaPerfilPromedio.destroy();

  graficaPerfilPromedio = new Chart(
    document.getElementById("graficaPerfilPromedio"),
    {
      type: "radar",
      data: {
        labels,
        datasets: [{
          label: "Promedio POSIT",
          data: valores,
          fill: true,
          backgroundColor: "rgba(25, 135, 84, 0.2)",
          borderColor: "#198754",
          borderWidth: 2,
          pointBackgroundColor: "#198754"
        }]
      },
      options: {
        responsive: true,
        scales: {
          r: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              backdropColor: "transparent"
            },
            pointLabels: {
              font: {
                size: 12,
                weight: "bold"
              }
            }
          }
        },
        plugins: {
          legend: {
            position: "top"
          }
        }
      }
    }
  );
}
</script>

<script>
async function cargarGraficaRiesgoTiempo() {

  const params = new URLSearchParams();

  if (filtroSexo.value) params.append("sexo", filtroSexo.value);
  if (filtroTurno.value) params.append("turno", filtroTurno.value);
  if (filtroGrupo.value) params.append("grupo", filtroGrupo.value);
  if (filtroEspecialidad.value) params.append("especialidad", filtroEspecialidad.value);

  const res = await fetch(
    "api/obtener_grafica_tiempo.php?" + params.toString()
  );
  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    if (graficaRiesgoTiempo) graficaRiesgoTiempo.destroy();
    return;
  }

  const labels = data.map(d => d.periodo);
  const valores = data.map(d => d.total);

  if (graficaRiesgoTiempo) graficaRiesgoTiempo.destroy();

  graficaRiesgoTiempo = new Chart(
    document.getElementById("graficaRiesgoTiempo"),
    {
      type: "line",
      data: {
        labels,
        datasets: [{
          label: "Alumnos con riesgo",
          data: valores,
          tension: 0.3,
          borderWidth: 3,
          pointRadius: 4
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    }
  );
}
</script>



<script>
(function () {
  // Si el navegador vuelve desde cache (botón atrás)
  window.addEventListener("pageshow", function (event) {
    if (event.persisted) {
      // fuerza recarga real
      window.location.reload();
    }
  });
})();
</script>

</body>
</html>