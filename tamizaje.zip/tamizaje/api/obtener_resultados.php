<?php
require_once "../config/conexion.php";
header("Content-Type: application/json");

/* =====================================
   MODO 1: CARGA DE FILTROS
===================================== */
if (isset($_GET["accion"]) && $_GET["accion"] === "filtros") {

  function obtenerColumna($conexion, $sql, $campo) {
    $res = $conexion->query($sql);
    $data = [];
    while ($row = $res->fetch_assoc()) {
      $data[] = [$campo => $row[$campo]];
    }
    return $data;
  }

  $sexo = obtenerColumna($conexion,
    "SELECT DISTINCT sexo FROM aplicaciones_test ORDER BY sexo",
    "sexo"
  );

  $turno = obtenerColumna($conexion,
    "SELECT DISTINCT turno FROM aplicaciones_test ORDER BY turno",
    "turno"
  );

  $especialidad = obtenerColumna($conexion,
    "SELECT DISTINCT especialidad FROM aplicaciones_test ORDER BY especialidad",
    "especialidad"
  );

  $grupos = obtenerColumna($conexion,
    "SELECT DISTINCT grupo FROM aplicaciones_test ORDER BY grupo",
    "grupo"
  );

  // Relaciones especialidad → grupo
  $relaciones = [];
  $res = $conexion->query("
    SELECT DISTINCT especialidad, grupo
    FROM aplicaciones_test
    WHERE especialidad IS NOT NULL AND grupo IS NOT NULL
    ORDER BY especialidad, grupo
  ");
  while ($row = $res->fetch_assoc()) {
    $relaciones[] = $row;
  }

  // Edades
  $edades = [];
  $res = $conexion->query("SELECT DISTINCT edad FROM aplicaciones_test ORDER BY edad");
  while ($row = $res->fetch_assoc()) {
    $edades[] = (int)$row["edad"];
  }

  echo json_encode([
    "sexo" => $sexo,
    "turno" => $turno,
    "especialidad" => $especialidad,
    "grupos" => $grupos,
    "relaciones" => $relaciones,
    "edades" => $edades
  ]);
  exit;
}

$where = [];
$params = [];
$types = "";

if (!empty($_GET["nombre"])) {
  $where[] = "at.nombre LIKE ?";
  $params[] = "%" . $_GET["nombre"] . "%";
  $types .= "s";
}

if (!empty($_GET["sexo"])) {
  $where[] = "at.sexo = ?";
  $params[] = $_GET["sexo"];
  $types .= "s";
}

if (!empty($_GET["turno"])) {
  $where[] = "at.turno = ?";
  $params[] = $_GET["turno"];
  $types .= "s";
}

if (!empty($_GET["grupo"])) {
  $where[] = "at.grupo = ?";
  $params[] = $_GET["grupo"];
  $types .= "s";
}

if (!empty($_GET["especialidad"])) {
  $where[] = "at.especialidad = ?";
  $params[] = $_GET["especialidad"];
  $types .= "s";
}

if (!empty($_GET["edad_min"])) {
  $where[] = "at.edad >= ?";
  $params[] = (int)$_GET["edad_min"];
  $types .= "i";
}

if (!empty($_GET["edad_max"])) {
  $where[] = "at.edad <= ?";
  $params[] = (int)$_GET["edad_max"];
  $types .= "i";
}

$sql = "
  SELECT
    at.aplicacion_id AS id,
    at.nombre,
    at.edad,
    at.sexo,
    at.turno,
    at.grado,
    at.grupo,
    at.especialidad,
    at.fecha_registro
  FROM aplicaciones_test at
";


if ($where) {
  $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY at.fecha_registro DESC";

$stmt = $conexion->prepare($sql);

if ($params) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);

