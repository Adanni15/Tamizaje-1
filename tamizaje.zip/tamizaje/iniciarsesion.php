<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Test de tamizaje</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js" integrity="sha384-G/EV+4j2dNv+tEPo3++6LCgdCROaejBqfUeNjuKAiuXbjrxilcCdDz6ZAVfHWe1Y" crossorigin="anonymous"></script>

  </head>
  <body>
    <div id="body-1">
      <div class="contenedor">
        <a class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>
      </div>
    </div>
  <div id="body">
  <div id="content">
    <h1>Iniciar Sesión</h1>
    <?php if (isset($error_msg)) { echo '<p class="error">' . $error_msg . '</p>'; } ?>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<div class="form-group">
  <label for="correo">Correo de Usuario:</label>
  <div class="input-group">
    <span class="input-group-text" id="basic-addon1">
      <svg xmlns="http://www.w3.org/2000/svg" 
           width="20" height="20" 
           viewBox="0 0 24 24" 
           fill="none" 
           stroke="currentColor" 
           stroke-width="2" 
           stroke-linecap="round" 
           stroke-linejoin="round" 
           class="icon icon-tabler icon-tabler-at">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" />
        <path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" />
      </svg>
    </span>
    <input 
      type="email" 
      class="form-control" 
      id="correo" 
      name="correo" 
      placeholder="ejemplo@correo.com" 
      aria-label="Correo de usuario" 
      aria-describedby="basic-addon1" 
      required
    >
  </div>
</div>


<div class="form-group">
  <label for="password">Contraseña:</label>
  <div class="input-group">
    <span class="input-group-text" id="basic-addon2">
      <svg xmlns="http://www.w3.org/2000/svg" 
           width="20" height="20" 
           viewBox="0 0 24 24" 
           fill="none" 
           stroke="currentColor" 
           stroke-width="2" 
           stroke-linecap="round" 
           stroke-linejoin="round" 
           class="icon icon-tabler icon-tabler-lock">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
        <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
        <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
      </svg>
    </span>
    <input 
      type="password" 
      class="form-control" 
      id="password" 
      name="password" 
      placeholder="********" 
      aria-label="Contraseña" 
      aria-describedby="basic-addon2" 
      required
    >
  </div>
</div>


      <button type="submit" >Iniciar Sesión</button>
    </form>

  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>
