<?php
$id = (int)$_GET['id'];

$data = file_get_contents("php://input");
$data = str_replace('data:image/png;base64,', '', $data);
$data = base64_decode($data);

$dir = __DIR__ . "/tmp";
if (!is_dir($dir)) mkdir($dir, 0777, true);

file_put_contents("$dir/radar_$id.png", $data);
