<?php
require_once "config/auth.php";

$logueado = true;
$rol = $_SESSION["usuario_rol"];
?>
<?php
require_once "config/conexion.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("Alumno no válido");
}

$idAlumno = intval($_GET['id']);
?>
<?php
$sql = "
SELECT
  d.id,
  d.nombre,
  d.edad,
  d.sexo,
  d.turno,
  d.grado,
  d.grupo,
  d.especialidad,
  d.fecha_registro,
  CASE
    WHEN SUM(r.respuesta) >= 1 THEN 'Positivo'
    ELSE 'Negativo'
  END AS resultado
FROM datos_sociodemograficos d
INNER JOIN respuestas r
  ON r.estudiante_id = d.id
WHERE d.id = ?
GROUP BY
  d.id,
  d.nombre,
  d.edad,
  d.sexo,
  d.turno,
  d.grado,
  d.grupo,
  d.especialidad,
  d.fecha_registro
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$alumno = $result->fetch_assoc();

if (!$alumno) {
  die("Alumno no encontrado");
}

$sqlHistorial = "
SELECT
  d.fecha_registro,
  CASE
    WHEN SUM(r.respuesta) >= 1 THEN 'Positivo'
    ELSE 'Negativo'
  END AS resultado
FROM datos_sociodemograficos d
INNER JOIN respuestas r
  ON r.estudiante_id = d.id
WHERE d.id = ?
GROUP BY d.fecha_registro
ORDER BY d.fecha_registro DESC
";

$stmtHistorial = $conexion->prepare($sqlHistorial);
$stmtHistorial->bind_param("i", $idAlumno);
$stmtHistorial->execute();
$resultHistorial = $stmtHistorial->get_result();

?>





<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>


      </div>
    </div>
  </header>

  <main class="container my-5">

  <a href="resultados.php" class="btn btn-outline-secondary mb-4">
    ← Volver a resultados
  </a>

<div class="card shadow-sm mb-4">
  <div class="card-body">
    <h5 class="mb-3" style="color:#691C32;font-weight:bold;">
      Historial de aplicacion
    </h5>

    <div class="table-responsive">
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Fecha de aplicación</th>
            <th>Resultado</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($resultHistorial->num_rows > 0): ?>
            <?php $i = 1; ?>
            <?php while ($row = $resultHistorial->fetch_assoc()): ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['fecha_registro']) ?></td>
                <td>
                  <?php if ($row['resultado'] === 'Positivo'): ?>
                    <span class="badge bg-danger">POSITIVO</span>
                  <?php else: ?>
                    <span class="badge bg-success">NEGATIVO</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="3" class="text-center text-muted">
                No hay registros anteriores
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <h4 class="mb-3">Datos del alumno</h4>

      <div class="row g-3">
        <div class="col-md-4"><strong>Nombre:</strong> <?= htmlspecialchars($alumno['nombre']) ?></div>
        <div class="col-md-2"><strong>Edad:</strong> <?= $alumno['edad'] ?></div>
        <div class="col-md-3"><strong>Sexo:</strong> <?= $alumno['sexo'] ?></div>
        <div class="col-md-3"><strong>Turno:</strong> <?= $alumno['turno'] ?></div>

        <div class="col-md-3"><strong>Grado:</strong> <?= $alumno['grado'] ?></div>
        <div class="col-md-3"><strong>Grupo:</strong> <?= $alumno['grupo'] ?></div>
        <div class="col-md-6"><strong>Especialidad:</strong> <?= $alumno['especialidad'] ?></div>
      </div>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body text-center">
      <h4 class="mb-3">Resultado del Test POSIT</h4>

      <?php if ($alumno['resultado'] === 'Positivo'): ?>
        <span class="badge bg-danger fs-5 px-4 py-2">POSITIVO</span>
      <?php else: ?>
        <span class="badge bg-success fs-5 px-4 py-2">NEGATIVO</span>
      <?php endif; ?>

      <p class="text-muted mt-3">
        Fecha de aplicación: <?= $alumno['fecha_registro'] ?>
      </p>
    </div>
  </div>

</main>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>