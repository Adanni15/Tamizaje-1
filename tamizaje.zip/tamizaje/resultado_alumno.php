<?php
require_once "config/auth.php";
require_once "config/conexion.php";

$logueado = true;
$rol = $_SESSION["usuario_rol"] ?? null;

// ==========================
// VALIDAR ID DE APLICACION_TEST
// ==========================
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("Registro no válido");
}

$idAplicacionTest = (int) $_GET['id'];


// ==========================
// DATOS DEL ALUMNO + APLICACION
// ==========================
$sqlAlumno = "
SELECT
  at.id AS aplicacion_test_id,
  at.nombre,
  at.edad,
  at.sexo,
  at.turno,
  at.grado,
  at.grupo,
  at.especialidad,
  at.fecha_aplicacion,
  a.id AS aplicacion_id,
  e.nombre AS escuela
FROM aplicaciones_test at
INNER JOIN aplicaciones a ON a.id = at.aplicacion_id
LEFT JOIN escuelas e ON e.id = at.escuela_id
WHERE at.id = ?

";

$stmtAlumno = $conexion->prepare($sqlAlumno);
if (!$stmtAlumno) {
  die("Error SQL alumno: " . $conexion->error);
}

$stmtAlumno->bind_param("i", $idAplicacionTest);
$stmtAlumno->execute();
$resultAlumno = $stmtAlumno->get_result();

$alumno = $resultAlumno->fetch_assoc();
if (!$alumno) {
  die("Registro no encontrado");
}


// ==========================
// RESULTADO GLOBAL (POSITIVO / NEGATIVO)
// ==========================
$sqlResultado = "
SELECT
  CASE
    WHEN SUM(valor) >= 1 THEN 'Positivo'
    ELSE 'Negativo'
  END AS resultado
FROM respuestas
WHERE aplicacion_id = ?
";

$stmtResultado = $conexion->prepare($sqlResultado);
$stmtResultado->bind_param("i", $alumno['aplicacion_id']);
$stmtResultado->execute();
$resultResultado = $stmtResultado->get_result();

$resultadoFinal = $resultResultado->fetch_assoc()['resultado'];


// ==========================
// HISTORIAL DEL MISMO ALUMNO
// (por nombre + datos básicos)
// ==========================
$sqlHistorial = "
SELECT
  at.id AS aplicacion_test_id,
  at.fecha_aplicacion,
  ROUND(AVG(res.porcentaje), 2) AS porcentaje,
  MAX(res.nivel_riesgo) AS nivel_riesgo
FROM aplicaciones_test at
INNER JOIN aplicaciones a ON a.id = at.aplicacion_id
INNER JOIN resultados res ON res.aplicacion_id = a.id
WHERE
  at.nombre = ?
  AND at.edad = ?
  AND at.sexo = ?
GROUP BY at.id, at.fecha_aplicacion
ORDER BY at.fecha_aplicacion DESC
";

$stmtHistorial = $conexion->prepare($sqlHistorial);
$stmtHistorial->bind_param(
  "sis",
  $alumno['nombre'],
  $alumno['edad'],
  $alumno['sexo']
);

$stmtHistorial->execute();
$resultHistorial = $stmtHistorial->get_result();

// ==========================
// PUNTAJE POR AREA (RADAR)
// ==========================
$sqlRadar = "
SELECT
  ar.nombre AS area,
  SUM(r.valor) AS puntaje
FROM respuestas r
INNER JOIN preguntas p ON p.id = r.pregunta_id
INNER JOIN areas ar ON ar.id = p.area_id
WHERE r.aplicacion_id = ?
GROUP BY ar.id
ORDER BY ar.id
";

$stmtRadar = $conexion->prepare($sqlRadar);
$stmtRadar->bind_param("i", $alumno['aplicacion_id']);
$stmtRadar->execute();
$resultRadar = $stmtRadar->get_result();

$labels = [];
$valores = [];

while ($row = $resultRadar->fetch_assoc()) {
  $labels[] = $row['area'];
  $valores[] = (int)$row['puntaje'];
}
// ==========================
// NOMBRE Y TIPO DEL INSTRUMENTO
// ==========================
$sqlInstrumento = "
SELECT i.nombre, i.tipo_escala
FROM aplicaciones_test at
INNER JOIN instrumentos i ON i.id = at.instrumento_id
WHERE at.id = ?
LIMIT 1
";

$stmtInst = $conexion->prepare($sqlInstrumento);
$stmtInst->bind_param("i", $idAplicacionTest);
$stmtInst->execute();
$resInst = $stmtInst->get_result();

$instrumento = $resInst->fetch_assoc();

$nombreTest = $instrumento["nombre"] ?? "Instrumento";
$tipoInstrumento = $instrumento["tipo_escala"] ?? "escala"; // escala | sino


// ==========================
// RADAR INDIVIDUAL (POR AREA)
// ==========================
$sqlRadar = "
SELECT
  ar.nombre AS area,
  ROUND(AVG(res.porcentaje), 2) AS porcentaje
FROM resultados res
INNER JOIN areas ar ON ar.id = res.area_id
WHERE res.aplicacion_id = ?
GROUP BY ar.id
ORDER BY ar.id
";

$stmtRadar = $conexion->prepare($sqlRadar);
$stmtRadar->bind_param("i", $alumno["aplicacion_id"]);
$stmtRadar->execute();
$resRadar = $stmtRadar->get_result();

$labelsRadar = [];
$valoresRadar = [];
$coloresRadar = [];

while ($r = $resRadar->fetch_assoc()) {
  $labelsRadar[] = $r["area"];
  $valoresRadar[] = $r["porcentaje"];

  if ($r["porcentaje"] < 34) {
    $coloresRadar[] = "rgba(40,167,69,0.6)";
  } elseif ($r["porcentaje"] < 67) {
    $coloresRadar[] = "rgba(255,193,7,0.6)";
  } else {
    $coloresRadar[] = "rgba(220,53,69,0.6)";
  }
}

// ==========================
// RESPUESTAS DEL ALUMNO
// ==========================
$sqlRespuestas = "
SELECT
  ar.nombre AS area,
  p.texto AS pregunta,
  r.valor
FROM respuestas r
INNER JOIN preguntas p ON p.id = r.pregunta_id
INNER JOIN areas ar ON ar.id = p.area_id
WHERE r.aplicacion_id = ?
ORDER BY ar.id, p.id
";

$stmtResp = $conexion->prepare($sqlRespuestas);
$stmtResp->bind_param("i", $alumno["aplicacion_id"]);
$stmtResp->execute();
$resultRespuestas = $stmtResp->get_result();

$respuestasPorArea = [];

while ($row = $resultRespuestas->fetch_assoc()) {
  $area = $row["area"];
  $respuestasPorArea[$area][] = $row;
}


?>





<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
</head>
<body>
  <header>
    <div class="content">
      <div class="menu container">
        
        <!-- Logo -->
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>


      </div>
    </div>
  </header>

  <main class="container my-5">

  <a href="resultados.php" class="btn btn-outline-secondary mb-4">
    ← Volver a resultados
  </a>

<div class="card shadow-sm mb-4">
  <div class="card-body">
    <h5 class="mb-3" style="color:#691C32;font-weight:bold;">
      Historial de aplicacion
    </h5>

    <div class="table-responsive">
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Fecha de aplicación</th>
            <th>Porcentaje de nivel de riesgo</th>
            <th>Nivel de riesgo promedio</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($resultHistorial->num_rows > 0): ?>
            <?php $i = 1; ?>
            <?php while ($row = $resultHistorial->fetch_assoc()): ?>
              <tr>
                <td><?= $i++ ?></td>
                <td>
                  <a
                    href="resultado_alumno.php?id=<?= $row['aplicacion_test_id'] ?>"
                    class="text-decoration-none fw-semibold"
                  >
                    <?= date("d/m/Y H:i", strtotime($row['fecha_aplicacion'])) ?>
                  </a>
                </td>
                <td><?= $row['porcentaje'] ?>%</td>
                <td>
                  <?php
                    switch ($row['nivel_riesgo']) {
                      case 'Alto':
                        echo '<span class="badge bg-danger">ALTO</span>';
                        break;
                      case 'Medio':
                        echo '<span class="badge bg-warning text-dark">MEDIO</span>';
                        break;
                      default:
                        echo '<span class="badge bg-success">BAJO</span>';
                    }
                  ?>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="3" class="text-center text-muted">
                No hay registros anteriores
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <h4 class="mb-3">Datos del alumno</h4>

      <div class="row g-3">
        <div class="col-md-4"> <strong>Escuela:</strong> <?= htmlspecialchars($alumno['escuela'] ?? 'No especificada') ?> </div>
        <div class="col-md-4"><strong>Nombre:</strong> <?= htmlspecialchars($alumno['nombre']) ?></div>
        <div class="col-md-2"><strong>Edad:</strong> <?= $alumno['edad'] ?></div>
        <div class="col-md-3"><strong>Sexo:</strong> <?= $alumno['sexo'] ?></div>
        <div class="col-md-3"><strong>Turno:</strong> <?= $alumno['turno'] ?></div>
        <div class="col-md-3"><strong>Grado:</strong> <?= $alumno['grado'] ?></div>
        <div class="col-md-3"><strong>Grupo:</strong> <?= $alumno['grupo'] ?></div>
        <div class="col-md-6"><strong>Especialidad:</strong> <?= $alumno['especialidad'] ?></div>
      </div>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body text-center">

      <h4 class="mb-4">
        Resultado individual – <?= htmlspecialchars($nombreTest) ?>
      </h4>

      <canvas id="radarAlumno" style="max-height:360px;"></canvas>

      <p class="text-muted mt-3">
        Fecha de aplicación:
        <?= date("d/m/Y H:i", strtotime($alumno["fecha_aplicacion"])) ?>
      </p>

    </div>
  </div>
  <hr class="my-4">

  <h5 class="mb-3 text-start" style="color:#691C32;font-weight:bold;">
    Respuestas del alumno
  </h5>

<div class="accordion" id="accordionRespuestas">

<?php $i = 0; ?>
<?php foreach ($respuestasPorArea as $area => $respuestas): ?>
  <?php $i++; ?>

  <div class="accordion-item">
    <h2 class="accordion-header" id="heading<?= $i ?>">
      <button class="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapse<?= $i ?>"
              aria-expanded="false">
        <?= htmlspecialchars($area) ?>
      </button>
    </h2>

    <div id="collapse<?= $i ?>"
         class="accordion-collapse collapse">

      <div class="accordion-body">

        <table class="table table-sm table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>Pregunta</th>
              <th class="text-center">Respuesta</th>
            </tr>
          </thead>
          <tbody>

          <?php foreach ($respuestas as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r["pregunta"]) ?></td>
              <td class="text-center">
                <?php
                  $valor = (int)$r["valor"];

                  if ($tipoInstrumento === "si_no") {
                    echo $valor === 1
                      ? '<span class="badge bg-success fs-6">Sí</span>'
                      : '<span class="badge bg-secondary fs-6">No</span>';
                  } else {
                    if ($valor <= 3) {
                      $class = "bg-success";
                    } elseif ($valor <= 6) {
                      $class = "bg-warning text-dark";
                    } else {
                      $class = "bg-danger";
                    }

                    echo '<span class="badge '.$class.' fs-6">'.$valor.'</span>';
                  }
                ?>
              </td>
            </tr>
          <?php endforeach; ?>

          </tbody>
        </table>

      </div>
    </div>
  </div>

<?php endforeach; ?>

</div>
<a
  href="reporte_individual_pdf.php?id=<?= $idAplicacionTest ?>&modo=ver"
  target="_blank"
  class="btn btn-danger mt-3 ms-2"
>
  📄 Generar reporte PDF
</a>

<a
  href="reporte_individual_pdf.php?id=<?= $idAplicacionTest ?>&modo=guardar"
  class="btn btn-danger mt-3 ms-2"
  onclick="return confirm('¿Deseas generar y guardar este reporte?')"
>
  💾 Guardar reporte
</a>





</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const labelsRadar = <?= json_encode($labelsRadar) ?>;
const valoresRadar = <?= json_encode($valoresRadar) ?>;
const coloresRadar = <?= json_encode($coloresRadar) ?>;

const ctx = document.getElementById("radarAlumno");

new Chart(ctx, {
  type: "radar",
  data: {
    labels: labelsRadar,
    datasets: [{
      label: "Riesgo por área (%)",
      data: valoresRadar,
      backgroundColor: "rgba(0,0,0,0.05)",
      borderColor: "#691C32",
      pointBackgroundColor: coloresRadar,
      pointBorderColor: coloresRadar,
      pointRadius: 5
    }]
  },
  options: {
    responsive: true,
    scales: {
      r: {
        min: 0,
        max: 100,
        ticks: {
          stepSize: 20
        }
      }
    },
    plugins: {
      legend: {
        position: "bottom"
      },
      tooltip: {
        callbacks: {
          label: ctx => {
            const v = ctx.raw;
            let nivel = "Bajo";
            if (v >= 67) nivel = "Alto";
            else if (v >= 34) nivel = "Medio";
            return `${nivel}: ${v}%`;
          }
        }
      }
    }
  }
});
</script>

  <footer class="footer-sistema mt-auto">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>

</body>
</html>