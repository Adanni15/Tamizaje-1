<?php
echo "Admin: " . password_hash("admin123", PASSWORD_DEFAULT) . "<br>";
echo "Aplicador: " . password_hash("aplicador123", PASSWORD_DEFAULT);
