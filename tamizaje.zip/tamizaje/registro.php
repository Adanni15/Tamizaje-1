<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Test de tamizaje</title>
    <link rel="stylesheet" href="css/style3.css">
  </head>
  <body>
    <div id="body-1">
      <div class="contenedor">
        <a class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>
      </div>
    </div>

    <div id="body">
      <div id="content">
        <h1>Registrarse</h1>
        <form action="" method="post">

          <!-- Nombre completo -->
          <div class="form-group">
            <label for="nombre">Nombre completo:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono usuario -->
                <svg xmlns="http://www.w3.org/2000/svg" 
                     width="20" height="20" 
                     viewBox="0 0 24 24" 
                     fill="none" 
                     stroke="currentColor" 
                     stroke-width="2" 
                     stroke-linecap="round" 
                     stroke-linejoin="round" 
                     class="icon icon-tabler icon-tabler-user">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
                  <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                </svg>
              </span>
              <input type="text" id="nombre" name="nombre" placeholder="Tu nombre completo" required>
            </div>
          </div>

          <!-- Correo electrónico -->
          <div class="form-group">
            <label for="correo">Correo electrónico:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono arroba -->
                <svg xmlns="http://www.w3.org/2000/svg" 
                     width="20" height="20" 
                     viewBox="0 0 24 24" 
                     fill="none" 
                     stroke="currentColor" 
                     stroke-width="2" 
                     stroke-linecap="round" 
                     stroke-linejoin="round" 
                     class="icon icon-tabler icon-tabler-at">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" />
                  <path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" />
                </svg>
              </span>
              <input type="email" id="correo" name="correo" placeholder="ejemplo@correo.com" required>
            </div>
          </div>

          <!-- Contraseña -->
          <div class="form-group">
            <label for="password">Contraseña:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono candado -->
                <svg xmlns="http://www.w3.org/2000/svg" 
                     width="20" height="20" 
                     viewBox="0 0 24 24" 
                     fill="none" 
                     stroke="currentColor" 
                     stroke-width="2" 
                     stroke-linecap="round" 
                     stroke-linejoin="round" 
                     class="icon icon-tabler icon-tabler-lock">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
                  <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
                  <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
                </svg>
              </span>
              <input type="password" id="password" name="password" placeholder="********" required>
            </div>
          </div>

          <button type="submit">Registrar</button>
        </form>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>
