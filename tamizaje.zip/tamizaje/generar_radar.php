<?php
require_once "config/conexion.php";

$id = (int)$_GET['id'];

// DATOS RADAR
$sql = "
SELECT ar.nombre AS area, ROUND(AVG(res.porcentaje),2) AS porcentaje
FROM resultados res
INNER JOIN areas ar ON ar.id = res.area_id
WHERE res.aplicacion_id = ?
GROUP BY ar.id
ORDER BY FIELD(ar.nombre,
  'Uso/abuso de sustancias',
  'Salud mental',
  'Relaciones familiares',
  'Relaciones con amigos',
  'Nivel educativo',
  'Interés laboral',
  'Conducta agresiva/delictiva'
)
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

$labels = [];
$values = [];

while ($r = $res->fetch_assoc()) {
  $labels[] = $r['area'];
  $values[] = $r['porcentaje'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Radar</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>

<style>
body { margin:0; }
#contenedor {
  width:500px;
  height:400px;
}
</style>
</head>
<body>

<div id="contenedor">
  <canvas id="radar"></canvas>
</div>

<script>
const ctx = document.getElementById('radar');

new Chart(ctx, {
  type: 'radar',
  data: {
    labels: <?= json_encode($labels) ?>,
    datasets: [{
      data: <?= json_encode($values) ?>,
      backgroundColor: 'rgba(105,28,50,0.08)',
      borderColor: '#691C32',
      borderWidth: 2,
      pointBackgroundColor: '#691C32'
    }]
  },
  options: {
    responsive: false,
    scales: {
      r: {
        min: 0,
        max: 100,
        ticks: { stepSize: 20 }
      }
    },
    plugins: { legend: { display:false } }
  }
});

// Convertir a imagen
setTimeout(() => {
  html2canvas(document.getElementById("contenedor")).then(canvas => {
    fetch("guardar_radar.php?id=<?= $id ?>", {
      method: "POST",
      body: canvas.toDataURL("image/png")
    });
  });
}, 800);
</script>

</body>
</html>
