<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   VALIDACIÓN DE DATOS
========================= */
$id     = (int) ($_POST["id"] ?? 0);
$estado = (int) ($_POST["estado"] ?? -1);

if ($id <= 0 || !in_array($estado, [0, 1], true)) {
  die("❌ Datos inválidos");
}

/* =========================
   ACTUALIZAR ESTADO
========================= */
$stmt = $conexion->prepare("
  UPDATE instrumentos
  SET activo = ?
  WHERE id = ?
");

$stmt->bind_param("ii", $estado, $id);

if (!$stmt->execute()) {
  die("❌ Error al cambiar estado");
}

$stmt->close();

header("Location: configuracion.php");
exit;
