<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id     = (int) ($_POST["id"] ?? 0);
$nombre = trim($_POST["nombre"] ?? "");

if ($id <= 0 || $nombre === "") {
  $_SESSION["msg"] = "Datos inválidos para editar la especialidad";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* VALIDAR DUPLICADO (EXCLUYENDO EL MISMO ID) */
$check = $conexion->prepare("
  SELECT id
  FROM especialidades
  WHERE LOWER(nombre) = LOWER(?)
    AND id <> ?
  LIMIT 1
");
$check->bind_param("si", $nombre, $id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
  $check->close();
  $_SESSION["msg"] = "Ya existe otra especialidad con ese nombre";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$check->close();

/* ACTUALIZAR */
$stmt = $conexion->prepare("
  UPDATE especialidades
  SET nombre = ?
  WHERE id = ?
");
$stmt->bind_param("si", $nombre, $id);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al actualizar la especialidad";
  $_SESSION["msg_type"] = "error";
  $stmt->close();
  header("Location: configuracion.php");
  exit;
}

$stmt->close();

$_SESSION["msg"] = "Especialidad actualizada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: configuracion.php");
exit;
