<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar área
================================ */
$areaId = (int)($_GET["area_id"] ?? 0);
if ($areaId <= 0) {
    die("Área inválida");
}

/* ===============================
   3. Obtener datos del área
================================ */
$sql = "
    SELECT 
        a.nombre AS area_nombre,
        i.nombre AS instrumento_nombre
    FROM areas a
    JOIN instrumentos i ON i.id = a.instrumento_id
    WHERE a.id = ?
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $areaId);
$stmt->execute();
$area = $stmt->get_result()->fetch_assoc();

if (!$area) {
    die("Área no encontrada");
}
?>



<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">

  <a href="editar_area.php?id=<?= $areaId ?>" class="btn btn-outline-secondary mb-4">
    ← Volver al área
  </a>

  <div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">Agregar pregunta</h5>
      <small class="text-muted">
        Área: <?= htmlspecialchars($area["area_nombre"]) ?> |
        Instrumento: <?= htmlspecialchars($area["instrumento_nombre"]) ?>
      </small>
    </div>

    <div class="card-body">
      <form method="post" action="guardar_pregunta.php">

        <input type="hidden" name="area_id" value="<?= $areaId ?>">

        <div class="mb-3">
          <label class="form-label">Texto de la pregunta</label>
          <textarea name="texto" class="form-control" rows="3" required></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Tipo de pregunta</label>

          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="red_flag" id="red_flag" value="1">
            <label class="form-check-label" for="red_flag">
              Pregunta Red Flag
            </label>
          </div>

          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="invertida" id="invertida" value="1">
            <label class="form-check-label" for="invertida">
              Pregunta invertida
            </label>
          </div>

          <small class="text-muted">
            Red flag: indica riesgo alto.<br>
            Invertida: la puntuación se evalúa al revés.
          </small>
        </div>

        <button type="submit" class="btn btn-success">
          Guardar pregunta
        </button>

      </form>
    </div>
  </div>

</main>







<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
