<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   VALIDACIÓN DE DATOS
========================= */
$instrumentoId = (int)($_POST["instrumento_id"] ?? 0);
$texto         = trim($_POST["texto"] ?? "");
$tipoElegido   = $_POST["tipo_respuesta"] ?? null; // solo si es la primera

if ($instrumentoId <= 0 || $texto === "") {
  die("Datos inválidos");
}

/* =========================
   VERIFICAR INSTRUMENTO
========================= */
$stmt = $conexion->prepare("
  SELECT id
  FROM instrumentos
  WHERE id = ?
");

$stmt->bind_param("i", $instrumentoId);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

if ($result->num_rows === 0) {
  die("Instrumento no válido");
}

/* =========================
   VERIFICAR TIPO EXISTENTE
========================= */
$stmt = $conexion->prepare("
  SELECT DISTINCT tipo_respuesta
  FROM preguntas
  WHERE instrumento_id = ?
  LIMIT 1
");

$stmt->bind_param("i", $instrumentoId);
$stmt->execute();
$resTipo = $stmt->get_result();
$stmt->close();

if ($resTipo->num_rows > 0) {
  // 🔒 Ya hay preguntas → heredar tipo
  $row = $resTipo->fetch_assoc();
  $tipoRespuesta = $row["tipo_respuesta"];

} else {
  // 🆕 Primera pregunta → se define el tipo
  if (!in_array($tipoElegido, ["si_no", "escala"])) {
    die("Tipo de respuesta inválido");
  }

  $tipoRespuesta = $tipoElegido;
}

/* =========================
   INSERTAR PREGUNTA
========================= */
$stmt = $conexion->prepare("
  INSERT INTO preguntas (instrumento_id, texto, tipo_respuesta)
  VALUES (?, ?, ?)
");

$stmt->bind_param("iss", $instrumentoId, $texto, $tipoRespuesta);

if (!$stmt->execute()) {
  die("Error al guardar la pregunta");
}

$stmt->close();

/* =========================
   REDIRECCIÓN
========================= */
header("Location: editar_instrumento.php?id=$instrumentoId");
exit;
