<?php
require_once "../config/auth.php";
require_once "../config/conexion.php";

if ($_SESSION["usuario_rol"] !== "administrador") {
  header("Location: ../iniciarsesion.php");
  exit;
}

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
  die("ID de reporte no válido");
}

$reporteId = (int) $_GET["id"];

// ==========================
// OBTENER RUTA DEL PDF
// ==========================
$stmt = $conexion->prepare("
  SELECT ruta_pdf
  FROM reportes
  WHERE id = ?
");
$stmt->bind_param("i", $reporteId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  die("Reporte no encontrado");
}

$reporte = $result->fetch_assoc();
$rutaRelativa = $reporte["ruta_pdf"];
$rutaFisica = __DIR__ . "/../" . $rutaRelativa;

// ==========================
// ELIMINAR ARCHIVO FÍSICO
// ==========================
if (file_exists($rutaFisica)) {
  unlink($rutaFisica);
}

// ==========================
// ELIMINAR REGISTRO BD
// ==========================
$stmtDelete = $conexion->prepare("
  DELETE FROM reportes
  WHERE id = ?
");
$stmtDelete->bind_param("i", $reporteId);
$stmtDelete->execute();

// ==========================
// REDIRIGIR
// ==========================
header("Location: reportes_guardados.php?eliminado=1");
exit;
