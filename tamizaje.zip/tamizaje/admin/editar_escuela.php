<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id        = (int)($_POST["id"] ?? 0);
$nombre    = trim($_POST["nombre"] ?? "");
$clave     = trim($_POST["clave"] ?? "");
$direccion = trim($_POST["direccion"] ?? "");

if ($id <= 0 || $nombre === "") {
  $_SESSION["msg"] = "Datos inválidos para editar la escuela";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* VALIDAR NOMBRE DUPLICADO */
$checkNombre = $conexion->prepare("
  SELECT id
  FROM escuelas
  WHERE LOWER(nombre) = LOWER(?)
    AND id <> ?
  LIMIT 1
");
$checkNombre->bind_param("si", $nombre, $id);
$checkNombre->execute();
$checkNombre->store_result();

if ($checkNombre->num_rows > 0) {
  $checkNombre->close();
  $_SESSION["msg"] = "Ya existe otra escuela con ese nombre";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$checkNombre->close();

/* VALIDAR CLAVE DUPLICADA (SI EXISTE) */
if ($clave !== "") {
  $checkClave = $conexion->prepare("
    SELECT id
    FROM escuelas
    WHERE clave = ?
      AND id <> ?
    LIMIT 1
  ");
  $checkClave->bind_param("si", $clave, $id);
  $checkClave->execute();
  $checkClave->store_result();

  if ($checkClave->num_rows > 0) {
    $checkClave->close();
    $_SESSION["msg"] = "La clave de la escuela ya existe";
    $_SESSION["msg_type"] = "error";
    header("Location: configuracion.php");
    exit;
  }
  $checkClave->close();
}

/* ACTUALIZAR */
$stmt = $conexion->prepare("
  UPDATE escuelas
  SET nombre = ?, clave = ?, direccion = ?
  WHERE id = ?
");
$stmt->bind_param("sssi", $nombre, $clave, $direccion, $id);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al actualizar la escuela";
  $_SESSION["msg_type"] = "error";
  $stmt->close();
  header("Location: configuracion.php");
  exit;
}

$stmt->close();

$_SESSION["msg"] = "Escuela actualizada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: configuracion.php");
exit;
