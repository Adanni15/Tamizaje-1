<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar pregunta_id
================================ */
$preguntaId = (int)($_GET["id"] ?? 0);
if ($preguntaId <= 0) {
    die("Pregunta inválida");
}

/* ===============================
   3. Obtener datos de la pregunta
================================ */
$sql = "
    SELECT 
        p.id,
        p.texto,
        p.es_invertida,
        p.red_flag,
        p.activa,
        p.area_id,
        a.nombre AS area_nombre
    FROM preguntas p
    JOIN areas a ON a.id = p.area_id
    WHERE p.id = ?
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $preguntaId);
$stmt->execute();
$pregunta = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pregunta) {
    die("Pregunta no encontrada");
}

$areaId = $pregunta["area_id"];
?>


<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_resultados.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">

  <!-- Volver -->
  <a href="ver_preguntas.php?id=<?= $areaId ?>"
     class="btn btn-secondary mb-4">
    ← Volver al área
  </a>
  <?php if (isset($_SESSION["msg"])): ?>
  <div class="row mb-4">
    <div class="col-12">
      <div class="mensaje-sistema card-test-e text-center <?= $_SESSION["msg_type"] === "success" ? "border-success" : "border-danger" ?>">
        <?= htmlspecialchars($_SESSION["msg"]) ?>
      </div>
    </div>
  </div>
  <?php
    unset($_SESSION["msg"], $_SESSION["msg_type"]);
  ?>
<?php endif; ?>

  <!-- Tarjeta editar pregunta -->
  <div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">Editar pregunta</h5>
      <small class="text-muted">
        Área: <?= htmlspecialchars($pregunta["area_nombre"]) ?>
      </small>
    </div>

    <div class="card-body">
      <form method="post" action="guardar_editar_pregunta.php">

        <input type="hidden" name="pregunta_id" value="<?= $preguntaId ?>">
        <input type="hidden" name="area_id" value="<?= $areaId ?>">

        <!-- Texto -->
        <div class="mb-3">
          <label class="form-label">Pregunta</label>
          <textarea
            name="texto"
            class="form-control"
            rows="3"
            required><?= htmlspecialchars($pregunta["texto"]) ?></textarea>
        </div>

        <!-- Flags -->
        <div class="mb-3">
          <label class="form-label">Configuración</label>

          <div class="form-check">
            <input
              class="form-check-input"
              type="checkbox"
              name="red_flag"
              value="1"
              <?= $pregunta["red_flag"] ? "checked" : "" ?>>
            <label class="form-check-label">
              Pregunta Red Flag
            </label>
          </div>

          <div class="form-check">
            <input
              class="form-check-input"
              type="checkbox"
              name="es_invertida"
              value="1"
              <?= $pregunta["es_invertida"] ? "checked" : "" ?>>
            <label class="form-check-label">
              Pregunta invertida
            </label>
          </div>

          <div class="form-check">
            <input
              class="form-check-input"
              type="checkbox"
              name="activa"
              value="1"
              <?= $pregunta["activa"] ? "checked" : "" ?>>
            <label class="form-check-label">
              Pregunta activa
            </label>
          </div>

          <small class="text-muted">
            Red flag = riesgo alto · Invertida = puntaje inverso
          </small>
        </div>

        <button type="submit" class="btn btn-primary">
          Guardar cambios
        </button>

      </form>
    </div>
  </div>

</main>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<footer class="footer-sistema mt-auto footer-margin">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
