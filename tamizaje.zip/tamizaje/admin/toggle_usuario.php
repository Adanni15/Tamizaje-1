<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_GET["id"] ?? 0);
$accion = $_GET["accion"] ?? "";

if ($id && in_array($accion, ["activar", "desactivar"])) {
  $estado = ($accion === "activar") ? 1 : 0;

  $stmt = $conexion->prepare(
    "UPDATE usuarios SET activo = ? WHERE id = ?"
  );
  $stmt->bind_param("ii", $estado, $id);
  $stmt->execute();
}

header("Location: usuarios.php");
exit;
