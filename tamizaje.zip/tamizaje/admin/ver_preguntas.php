<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDAR SESIÓN
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. VALIDAR ID DEL ÁREA
================================ */
$areaId = (int)($_GET["id"] ?? 0);
if ($areaId <= 0) {
    die("Área inválida");
}

/* ===============================
   3. OBTENER ÁREA + INSTRUMENTO
================================ */
$sqlArea = "
    SELECT 
        a.nombre AS area_nombre,
        i.id AS instrumento_id,
        i.nombre AS instrumento_nombre,
        i.tipo_escala,
        i.escala_min,
        i.escala_max
    FROM areas a
    JOIN instrumentos i ON i.id = a.instrumento_id
    WHERE a.id = ?
";

$stmtArea = $conexion->prepare($sqlArea);
if (!$stmtArea) {
    die("Error SQL área: " . $conexion->error);
}

$stmtArea->bind_param("i", $areaId);
$stmtArea->execute();
$area = $stmtArea->get_result()->fetch_assoc();
$stmtArea->close();

if (!$area) {
    die("Área no encontrada");
}

/* ===============================
   4. OBTENER PREGUNTAS DEL ÁREA
================================ */
$preguntas = [];

$sqlPreg = "
    SELECT 
        p.id,
        p.numero,
        p.texto,
        p.activa,
        p.es_invertida,
        p.red_flag
    FROM preguntas p
    WHERE p.area_id = ?
    ORDER BY p.numero
";

$stmtPreg = $conexion->prepare($sqlPreg);
if (!$stmtPreg) {
    die("Error SQL preguntas: " . $conexion->error);
}

$stmtPreg->bind_param("i", $areaId);
$stmtPreg->execute();
$resPreg = $stmtPreg->get_result();

while ($row = $resPreg->fetch_assoc()) {
    $preguntas[] = $row;
}

$stmtPreg->close();
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">

  <a href="editar_area.php?id=<?= $areaId ?>"
     class="btn btn-outline-secondary mb-4">
    ← Volver al área
  </a>

  <div class="card shadow-sm mb-4">
    <div class="card-header">
      <h5 class="mb-0">
        Preguntas del área: <?= htmlspecialchars($area["area_nombre"]) ?>
      </h5>
      <small class="text-muted">
        Instrumento: <?= htmlspecialchars($area["instrumento_nombre"]) ?>
      </small>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h5 class="mb-0">Listado de preguntas</h5>
      <a href="agregar_pregunta.php?area_id=<?= $areaId ?>"
         class="btn btn-sm btn-success">
        ➕ Nueva pregunta
      </a>
    </div>

    <div class="card-body p-0">
      <table class="table table-bordered mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Pregunta</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>

        <?php if (empty($preguntas)): ?>
          <tr>
            <td colspan="2" class="text-center text-muted">
              No hay preguntas registradas
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($preguntas as $p): ?>
        <tr>
          <td class="text-center"><?= $p["id"] ?></td>
        
          <td><?= htmlspecialchars($p["texto"]) ?></td>
        
          <td class="text-center">
            <?= $p["activa"] ? 'Activa' : 'Inactiva' ?>
          </td>
        
          <td class="text-center">
            <a href="editar_pregunta.php?id=<?= $p["id"] ?>"
               class="btn btn-sm btn-primary">
              Editar
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

</main>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
