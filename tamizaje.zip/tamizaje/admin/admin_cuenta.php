<?php
require_once "../config/auth.php";

if ($_SESSION["usuario_rol"] !== "administrador") {
  header("Location: ../iniciarsesion.php");
  exit;
}
?>
<?php
$sexo = $_SESSION["usuario_sexo"] ?? "Otro";

if ($sexo === "Masculino") {
  $saludo = "Bienvenido";
} elseif ($sexo === "Femenino") {
  $saludo = "Bienvenida";
} else {
  $saludo = "Bienvenido/a";
}

$nombre = htmlspecialchars($_SESSION["usuario_nombre"]);
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- CSS propio -->
  <link rel="stylesheet" href="../css/style2.css">
</head>
<?php if (!empty($_SESSION["mostrar_bienvenida"])): ?>
  <div id="mensajeBienvenida" class="toast-institucional">
    <div class="toast-header">
      <span class="toast-icon"></span>
      <strong><?= $saludo ?>, <?= $nombre ?></strong>
    </div>
    <div class="toast-body">
      Has iniciado sesión como <b>Administrador</b>
    </div>
  </div>
<?php unset($_SESSION["mostrar_bienvenida"]); ?>
<?php endif; ?>



<body>

<header>
  <div class="content">
    <div class="menu container">

      <!-- Logo -->
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>

      <!-- Botón hamburguesa -->
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>

      <!-- Navbar -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>

        <ul class="logout-menu">
          <li class="usuario-info">
            <span class="usuario-badge">
              <span class="usuario-icono">👤</span>
              <span class="usuario-texto">
                <span class="usuario-nombre">
                  <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                </span>
                <span class="usuario-rol">
                  <?= strtoupper($_SESSION["usuario_rol"]) ?>
                </span>
              </span>
            </span>
          </li>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>

    </div>
  </div>
</header>

<main class="container mt-5">
    <h1 class="mb-2">Panel de Administración</h1>
    <div class="row g-4">
      <!-- Configuración -->
      <div class="col-md-4">
        <a href="configuracion.php" class="card card-admin h-100 text-decoration-none">
          <div class="card-body text-center">
            <div class="icono-admin">⚙️</div>
            <h5 class="card-title">Configuración</h5>
            <p class="card-text">
              Ajustes del sistema, puntos de corte y parámetros.
            </p>
          </div>
        </a>
      </div>
      <!-- Gestión de Usuarios -->
      <div class="col-md-4">
        <a href="usuarios.php" class="card card-admin h-100 text-decoration-none">
          <div class="card-body text-center">
            <div class="icono-admin">👥</div>
            <h5 class="card-title">Gestión de usuarios</h5>
            <p class="card-text">
              Crear, editar, activar o desactivar cuentas del sistema.
            </p>
          </div>
        </a>
      </div>
      <div class="col-md-4">
        <a href="mi_cuenta.php" class="card card-admin h-100 text-decoration-none">
          <div class="card-body text-center">
            <div class="icono-admin">👤</div>
            <h5 class="card-title">Mi cuenta</h5>
            <p class="card-text">
              Edita tus datos personales, contraseña y seguridad de sesión.
            </p>
          </div>
        </a>
      </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const toast = document.getElementById("mensajeBienvenida");
  const cerrar = document.getElementById("cerrarToast");

  function ocultarToast() {
    toast.classList.add("ocultar");

    // Quitar del DOM después de la animación
    setTimeout(() => {
      toast.style.display = "none";
    }, 600);
  }

  // Auto cerrar después de 4 segundos
  setTimeout(ocultarToast, 4000);

  // Cerrar manual
  cerrar.addEventListener("click", ocultarToast);
});
</script>

<script>
(function () {
  // Si el navegador vuelve desde cache (botón atrás)
  window.addEventListener("pageshow", function (event) {
    if (event.persisted) {
      // fuerza recarga real
      window.location.reload();
    }
  });
})();
</script>

</body>
</html>
