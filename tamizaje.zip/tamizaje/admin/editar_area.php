<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDACIÓN DE SESIÓN
================================ */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* ===============================
   2. VALIDAR ID DEL ÁREA
================================ */
$areaId = (int)($_GET["id"] ?? 0);
if ($areaId <= 0) {
  $_SESSION["msg"] = "Área inválida";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* ===============================
   3. OBTENER ÁREA + INSTRUMENTO
================================ */
$stmtArea = $conexion->prepare("
  SELECT
    a.id,
    a.nombre AS area_nombre,
    a.descripcion,
    a.instrumento_id,
    i.nombre AS instrumento_nombre
  FROM areas a
  INNER JOIN instrumentos i ON i.id = a.instrumento_id
  WHERE a.id = ?
");
$stmtArea->bind_param("i", $areaId);
$stmtArea->execute();
$area = $stmtArea->get_result()->fetch_assoc();
$stmtArea->close();

if (!$area) {
  $_SESSION["msg"] = "Área no encontrada";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* ===============================
   4. PROCESAR ACTUALIZACIÓN
================================ */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

  $nombre = trim($_POST["nombre"] ?? "");
  $descripcion = trim($_POST["descripcion"] ?? "");

  if ($nombre === "") {
    $_SESSION["msg"] = "El nombre del área es obligatorio";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_area.php?id=$areaId");
    exit;
  }

  /* ===============================
     5. EVITAR DUPLICADOS (MISMO INSTRUMENTO)
     CASE-INSENSITIVE
  ================================ */
  $stmtDup = $conexion->prepare("
    SELECT id
    FROM areas
    WHERE instrumento_id = ?
      AND LOWER(nombre) = LOWER(?)
      AND id != ?
    LIMIT 1
  ");
  $stmtDup->bind_param(
    "isi",
    $area["instrumento_id"],
    $nombre,
    $areaId
  );
  $stmtDup->execute();
  $stmtDup->store_result();

  if ($stmtDup->num_rows > 0) {
    $_SESSION["msg"] = "Ya existe un área con ese nombre en este instrumento";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_area.php?id=$areaId");
    exit;
  }
  $stmtDup->close();

  /* ===============================
     6. ACTUALIZAR ÁREA
  ================================ */
  $stmtUp = $conexion->prepare("
    UPDATE areas
    SET nombre = ?, descripcion = ?
    WHERE id = ?
  ");
  $stmtUp->bind_param("ssi", $nombre, $descripcion, $areaId);

  if (!$stmtUp->execute()) {
    $_SESSION["msg"] = "Error al actualizar el área";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_area.php?id=$areaId");
    exit;
  }
  $stmtUp->close();

  $_SESSION["msg"] = "Área actualizada correctamente";
  $_SESSION["msg_type"] = "success";

  header("Location: editar_area.php?id=$areaId");
  exit;
}
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_resultados.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">

  <a href="editar_instrumento.php?id=<?= $area["instrumento_id"] ?>"
     class="btn btn-secondary mb-4">
    ← Volver al instrumento
  </a>

<?php if (isset($_SESSION["msg"])): ?>
  <div class="row mb-4">
    <div class="col-12">
      <div class="mensaje-sistema card-test-e text-center <?= $_SESSION["msg_type"] === "success" ? "border-success" : "border-danger" ?>">
        <?= htmlspecialchars($_SESSION["msg"]) ?>
      </div>
    </div>
  </div>
  <?php
    unset($_SESSION["msg"], $_SESSION["msg_type"]);
  ?>
<?php endif; ?>


  <div class="card shadow-sm mb-4">
    <div class="card-header">
      <h5 class="mb-0">
        Área: <?= htmlspecialchars($area["area_nombre"]) ?>
      </h5>
      <small class="text-muted">
        Instrumento: <?= htmlspecialchars($area["instrumento_nombre"]) ?>
      </small>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">Editar área</h5>
    </div>

    <div class="card-body">
      <form method="post">

        <div class="mb-3">
          <label class="form-label">Nombre del área</label>
          <input
            type="text"
            name="nombre"
            class="form-control"
            value="<?= htmlspecialchars($area["area_nombre"]) ?>"
            required
          >
        </div>

        <div class="mb-3">
          <label class="form-label">Descripción</label>
          <textarea
            name="descripcion"
            class="form-control"
            rows="3"
          ><?= htmlspecialchars($area["descripcion"]) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">
          Guardar cambios
        </button>

        <a href="editar_instrumento.php?id=<?= $area["instrumento_id"] ?>"
           class="btn btn-secondary">
          Cancelar
        </a>

        <a href="ver_preguntas.php?id=<?= $areaId ?>"
           class="btn btn-outline-success">
          Administrar preguntas
        </a>

      </form>
    </div>
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const mensaje = document.getElementById("mensajeSistema");

  if (mensaje) {
    // Tiempo visible (en ms)
    const tiempoVisible = 3500;

    setTimeout(() => {
      mensaje.classList.add("ocultar");

      // Eliminar del DOM después de la animación
      setTimeout(() => {
        mensaje.remove();
      }, 500);

    }, tiempoVisible);
  }
</script>
<footer class="footer-sistema mt-auto footer-margin">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
