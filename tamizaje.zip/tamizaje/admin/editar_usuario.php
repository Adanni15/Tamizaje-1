<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
  header("Location: usuarios.php");
  exit;
}

/* Obtener usuario */
$stmt = $conexion->prepare("
  SELECT id, nombre_completo, correo, rol_id
  FROM usuarios
  WHERE id = ?
  LIMIT 1
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
  header("Location: usuarios.php");
  exit;
}

$usuario = $result->fetch_assoc();

/* Obtener roles */
$roles = $conexion->query("SELECT id, nombre FROM roles ORDER BY nombre");
