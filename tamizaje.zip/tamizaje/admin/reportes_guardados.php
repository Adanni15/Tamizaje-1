<?php
require_once "../config/auth.php";
require_once "../config/conexion.php";

if ($_SESSION["usuario_rol"] !== "administrador") {
  header("Location: ../iniciarsesion.php");
  exit;
}

// ==========================
// CONSULTAR REPORTES
// ==========================
$sql = "
SELECT
  r.id,
  r.nombre_alumno,
  r.grado,
  r.grupo,
  r.fecha_generacion,
  r.ruta_pdf,

  i.nombre AS instrumento,

  COALESCE(at.especialidad, 'Sin especialidad') AS especialidad,
  COALESCE(at.turno, 'Sin turno') AS turno,
  COALESCE(e.nombre, 'Sin escuela') AS escuela

FROM reportes r

INNER JOIN instrumentos i 
  ON i.id = r.instrumento_id

INNER JOIN aplicaciones_test at
  ON at.id = r.aplicacion_test_id

LEFT JOIN escuelas e
  ON e.id = at.escuela_id

ORDER BY r.fecha_generacion DESC
";

$reportes = $conexion->query($sql);

if (!$reportes) {
  die("Error en la consulta SQL: " . $conexion->error);
}
// ==========================
// ESCUELAS CON REPORTES
// ==========================
$sqlEscuelas = "
SELECT DISTINCT e.id, e.nombre
FROM reportes r
INNER JOIN aplicaciones_test at ON at.id = r.aplicacion_test_id
INNER JOIN escuelas e ON e.id = at.escuela_id
ORDER BY e.nombre
";

$escuelas = $conexion->query($sqlEscuelas);

?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_resultados.css">
  
  
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">
<div>
  <a href="admin_cuenta.php" class="btn btn-secondary mb-4">
      ← Volver
  </a>
</div>


  <h2 class="mb-4 card-test-e">📂 Reportes Generados</h2>
    <!-- FILTROS -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form id="filtrosForm" class="row g-3">
        <div class="col-md-3">
          <select id="filtroEscuela" class="form-select">
            <option value="">Escuela</option>
            <?php while ($esc = $escuelas->fetch_assoc()): ?>
              <option value="<?= htmlspecialchars($esc['nombre']) ?>">
                <?= htmlspecialchars($esc['nombre']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="col-md-4">
          <input type="text" id="buscarNombre" class="form-control" placeholder="Buscar por nombre">
        </div>

        <div class="col-md-2">
          <select id="filtroTurno" class="form-select">
            <option value="">Turno</option>
          </select>
        </div>
        <div class="col-md-2">
          <select id="filtroGrado" class="form-select">
            <option value="">Grado</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroEspecialidad" class="form-select">
            <option value="">Especialidad</option>
          </select>
        </div>

        <div class="col-md-2">
          <select id="filtroGrupo" class="form-select">
            <option value="">Grupo</option>
          </select>
        </div>

        <div class="col-12 text-end">
          <button type="button" class="btn btn-primary px-4" id="aplicarFiltros">
            Aplicar filtros
          </button>
          <button type="button" class="btn btn-secondary" id="limpiarFiltros">
            Limpiar
          </button>
        </div>

      </form>
    </div>
  </div>

  <?php if ($reportes->num_rows === 0): ?>
    <div class="alert alert-warning">
      No hay reportes generados todavía.
    </div>
  <?php else: ?>
    <div class="table-responsive tabla-reportes">
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-dark">
          <tr>
            <th>Alumno</th>
            <th>Escuela</th>
            <th>Instrumento</th>
            <th>Especialidad</th>
            <th>Turno</th>
            <th>Grado</th>
            <th>Grupo</th>
            <th>Fecha</th>
            <th class="text-center">PDF</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $reportes->fetch_assoc()): ?>
            <tr
              data-nombre="<?= strtolower($row['nombre_alumno']) ?>"
              data-escuela="<?= strtolower($row['escuela']) ?>"
              data-grado="<?= strtolower($row['grado']) ?>"
              data-grupo="<?= strtolower($row['grupo']) ?>"
              data-especialidad="<?= strtolower($row['especialidad']) ?>"
              data-turno="<?= strtolower($row['turno']) ?>"
            >
              <td><?= htmlspecialchars($row["nombre_alumno"]) ?></td>
              <td><?= htmlspecialchars($row["escuela"]) ?></td>
              <td><?= htmlspecialchars($row["instrumento"]) ?></td>
              <td>
                <?= $row["especialidad"]
                  ? htmlspecialchars($row["especialidad"])
                  : '<span class="text-muted">Sin especialidad</span>' ?>
              </td>
              <td><?= htmlspecialchars($row["turno"]) ?></td>
              <td><?= htmlspecialchars($row["grado"]) ?></td>
              <td><?= htmlspecialchars($row["grupo"]) ?></td>
              <td><?= date("d/m/Y H:i", strtotime($row["fecha_generacion"])) ?></td>
              <td class="text-center">
                <?php if (!empty($row["ruta_pdf"])): ?>
                  <a
                    href="../<?= htmlspecialchars($row["ruta_pdf"]) ?>"
                    target="_blank"
                    class="btn btn-sm btn-primary mb-1"
                  >
                    Ver
                  </a>
                  <a
                    href="../<?= htmlspecialchars($row["ruta_pdf"]) ?>"
                    download
                    class="btn btn-sm btn-success mb-1"
                  >
                    Descargar
                  </a>
                  <a
                    href="eliminar_reporte.php?id=<?= $row["id"] ?>"
                    class="btn btn-sm btn-danger mb-1"
                    onclick="return confirm('¿Seguro que deseas eliminar este reporte? Esta acción no se puede deshacer.')"
                  >
                    Eliminar
                  </a>
                <?php else: ?>
                  <span class="text-muted">No disponible</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>

      </table>
    </div>
  <?php endif; ?>

</main>

<script>
const filtroEscuela = document.getElementById("filtroEscuela");
const filtroGrado = document.getElementById("filtroGrado");
const filtroGrupo = document.getElementById("filtroGrupo");
const filtroEspecialidad = document.getElementById("filtroEspecialidad");
const buscarNombre = document.getElementById("buscarNombre");
const filtroTurno = document.getElementById("filtroTurno");


const filas = document.querySelectorAll("tbody tr");

function resetSelect(select, placeholder) {
  select.innerHTML = `<option value="">${placeholder}</option>`;
}

function llenarOpciones() {
  const escuela = filtroEscuela.value.toLowerCase();

  const grados = new Set();
  const grupos = new Set();
  const especialidades = new Set();
  const turnos = new Set();


  filas.forEach(fila => {
    if (!escuela || fila.dataset.escuela === escuela) {
      if (fila.dataset.grado) grados.add(fila.dataset.grado);
      if (fila.dataset.grupo) grupos.add(fila.dataset.grupo);
      if (fila.dataset.especialidad) especialidades.add(fila.dataset.especialidad);
      if (fila.dataset.turno) turnos.add(fila.dataset.turno);
    }
  });

  resetSelect(filtroGrado, "Grado");
  resetSelect(filtroGrupo, "Grupo");
  resetSelect(filtroEspecialidad, "Especialidad");
  resetSelect(filtroTurno, "Turno");


  grados.forEach(g => {
    filtroGrado.innerHTML += `<option value="${g}">${g.toUpperCase()}</option>`;
  });

  grupos.forEach(g => {
    filtroGrupo.innerHTML += `<option value="${g}">${g.toUpperCase()}</option>`;
  });

  especialidades.forEach(e => {
    filtroEspecialidad.innerHTML += `<option value="${e}">${e.toUpperCase()}</option>`;
  });
  turnos.forEach(t => {
    filtroTurno.innerHTML += `<option value="${t}">${t.toUpperCase()}</option>`;
  });
}

function aplicarFiltros() {
  const nombre = buscarNombre.value.toLowerCase();
  const escuela = filtroEscuela.value.toLowerCase();
  const grado = filtroGrado.value.toLowerCase();
  const grupo = filtroGrupo.value.toLowerCase();
  const especialidad = filtroEspecialidad.value.toLowerCase();
  const turno = filtroTurno.value.toLowerCase();


  filas.forEach(fila => {
    const match =
      fila.dataset.nombre.includes(nombre) &&
      fila.dataset.escuela.includes(escuela) &&
      fila.dataset.grado.includes(grado) &&
      fila.dataset.grupo.includes(grupo) &&
      fila.dataset.especialidad.includes(especialidad)&&
      fila.dataset.turno.includes(turno);

    fila.style.display = match ? "" : "none";
  });
}

// 🔗 EVENTOS
filtroEscuela.addEventListener("change", () => {
  llenarOpciones();
  aplicarFiltros();
});

document.getElementById("aplicarFiltros").addEventListener("click", aplicarFiltros);

document.getElementById("limpiarFiltros").addEventListener("click", () => {
  document.getElementById("filtrosForm").reset();
  resetSelect(filtroGrado, "Grado");
  resetSelect(filtroGrupo, "Grupo");
  resetSelect(filtroEspecialidad, "Especialidad");
  resetSelect(filtroTurno, "Turno");
  filas.forEach(f => f.style.display = "");
});
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<footer class="footer-sistema mt-auto">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
