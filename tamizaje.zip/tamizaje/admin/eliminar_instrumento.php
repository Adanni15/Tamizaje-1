<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   VALIDACIÓN DE DATOS
========================= */
$id = (int)($_POST["id"] ?? 0);

if ($id <= 0) {
  die("❌ Instrumento inválido");
}

$conexion->begin_transaction();

try {

  /* =========================
     VERIFICAR PREGUNTAS
     (preguntas → areas → instrumentos)
  ========================= */
  $stmt = $conexion->prepare("
    SELECT COUNT(*) 
    FROM preguntas p
    INNER JOIN areas a ON a.id = p.area_id
    WHERE a.instrumento_id = ?
  ");

  if (!$stmt) {
    throw new Exception("Error SQL verificación preguntas: " . $conexion->error);
  }

  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->bind_result($totalPreguntas);
  $stmt->fetch();
  $stmt->close();

  if ($totalPreguntas > 0) {
    throw new Exception(
      "No se puede eliminar el cuestionario porque tiene preguntas asociadas"
    );
  }

  /* =========================
     ELIMINAR ÁREAS DEL INSTRUMENTO
  ========================= */
  $stmt = $conexion->prepare("
    DELETE FROM areas
    WHERE instrumento_id = ?
  ");

  if (!$stmt) {
    throw new Exception("Error SQL eliminar áreas: " . $conexion->error);
  }

  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->close();

  /* =========================
     ELIMINAR INSTRUMENTO
  ========================= */
  $stmt = $conexion->prepare("
    DELETE FROM instrumentos
    WHERE id = ?
  ");

  if (!$stmt) {
    throw new Exception("Error SQL eliminar instrumento: " . $conexion->error);
  }

  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->close();

  /* =========================
     CONFIRMAR
  ========================= */
  $conexion->commit();

  header("Location: configuracion.php?msg=instrumento_eliminado");
  exit;

} catch (Exception $e) {

  $conexion->rollback();
  die("❌ " . $e->getMessage());

}
