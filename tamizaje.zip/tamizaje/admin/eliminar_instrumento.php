<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   VALIDACIÓN DE DATOS
========================= */
$id = (int) ($_POST["id"] ?? 0);

if ($id <= 0) {
  die("❌ Instrumento inválido");
}

/* =========================
   VERIFICAR PREGUNTAS
========================= */
$check = $conexion->prepare("
  SELECT COUNT(*) AS total
  FROM preguntas
  WHERE instrumento_id = ?
");

$check->bind_param("i", $id);
$check->execute();
$res = $check->get_result()->fetch_assoc();
$check->close();

if ($res["total"] > 0) {
  die("❌ No se puede eliminar: el instrumento tiene preguntas asociadas");
}

/* =========================
   ELIMINAR INSTRUMENTO
========================= */
$stmt = $conexion->prepare("
  DELETE FROM instrumentos
  WHERE id = ?
");

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
  die("❌ Error al eliminar instrumento");
}

$stmt->close();

header("Location: configuracion.php");
exit;
