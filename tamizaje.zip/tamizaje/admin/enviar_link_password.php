<?php
session_start();
require_once "../config/conexion.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar PHPMailer
require_once __DIR__ . '/vendor/PHPMailer/src/Exception.php';
require_once __DIR__ . '/vendor/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/vendor/PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: recuperar_password.php");
  exit;
}

$correo = trim($_POST["correo"]);

// Buscar usuario
$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE correo = ?");
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  $_SESSION["mensaje_error"] = "No existe una cuenta con ese correo.";
  header("Location: recuperar_password.php");
  exit;
}

$usuario = $result->fetch_assoc();

// Generar token
$token = bin2hex(random_bytes(32));
$expira = date("Y-m-d H:i:s", strtotime("+1 hour"));

// Guardar token
$stmt = $conexion->prepare("
  UPDATE usuarios
  SET reset_token = ?, reset_expira = ?
  WHERE id = ?
");
$stmt->bind_param("ssi", $token, $expira, $usuario["id"]);
$stmt->execute();

// Link de recuperación
$link = "http://192.168.100.5/tamizaje/admin/restablecer_password.php?token=" . $token;

try {
  $mail = new PHPMailer(true);

  // Configuración SMTP
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'sistema.tamizaje@gmail.com';
  $mail->Password = 'jjzt vpxq sgmp hnzd';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587;

  // Correo
  $mail->setFrom('sistema.tamizaje@gmail.com', 'Sistema de Tamizaje');
  $mail->addAddress($correo);

  $mail->isHTML(true);
  $mail->Subject = 'Recuperación de contraseña';
  $mail->Body = "
    <h3>Recuperación de contraseña</h3>
    <p>Haz clic en el siguiente enlace para restablecer tu contraseña:</p>
    <p><a href='$link'>$link</a></p>
    <p><small>Este enlace expira en 1 hora.</small></p>
  ";

  $mail->send();

  $_SESSION["mensaje_exito"] = "Se ha enviado un enlace de recuperación a tu correo.";
  header("Location: recuperar_password.php");
  exit;

} catch (Exception $e) {
  $_SESSION["mensaje_error"] = "Error al enviar correo: " . $mail->ErrorInfo;

  // Link de respaldo para pruebas
  $_SESSION["debug_link"] = $link;

  header("Location: recuperar_password.php");
  exit;
}
