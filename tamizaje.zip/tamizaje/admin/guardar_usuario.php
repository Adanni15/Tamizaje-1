<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* Validar método */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: usuarios.php");
  exit;
}

/* Obtener datos */
$nombre   = trim($_POST["nombre"] ?? "");
$correo   = trim($_POST["correo"] ?? "");
$password = $_POST["password"] ?? "";
$sexo     = $_POST["sexo"] ?? "";
$rol_id   = $_POST["rol_id"] ?? "";

/* Validaciones básicas */
if ($nombre === "" || $correo === "" || $password === "" || $sexo === "" || $rol_id === "") {
  die("Todos los campos son obligatorios");
}

/* Verificar correo duplicado */
$check = $conexion->prepare("SELECT id FROM usuarios WHERE correo = ?");
$check->bind_param("s", $correo);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
  die("El correo ya está registrado");
}

/* Encriptar contraseña */
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

/* Insertar usuario */
$sql = "
  INSERT INTO usuarios 
  (nombre_completo, correo, password, sexo, rol_id, activo)
  VALUES (?, ?, ?, ?, ?, 1)
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param(
  "ssssi",
  $nombre,
  $correo,
  $passwordHash,
  $sexo,
  $rol_id
);

if ($stmt->execute()) {
  header("Location: usuarios.php");
  exit;
} else {
  die("Error al guardar el usuario");
}
