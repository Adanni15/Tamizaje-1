<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* Valor recibido */
$usarEspecialidades = isset($_POST["usar_especialidades"]) ? "1" : "0";

/* Actualizar configuración existente */
$stmt = $conexion->prepare("
  UPDATE configuracion_sistema
  SET valor = ?
  WHERE clave = 'usar_especialidades'
");
$stmt->bind_param("s", $usarEspecialidades);
$stmt->execute();

header("Location: configuracion.php");
exit;
