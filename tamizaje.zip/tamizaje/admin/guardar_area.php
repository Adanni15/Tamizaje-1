<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDACIÓN DE SESIÓN
================================ */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* ===============================
   2. RECIBIR DATOS
================================ */
$instrumentoId = (int)($_POST["instrumento_id"] ?? 0);
$nombre        = trim($_POST["nombre"] ?? "");
$descripcion   = trim($_POST["descripcion"] ?? "");

/* ===============================
   3. VALIDACIONES BÁSICAS
================================ */
if ($instrumentoId <= 0) {
  $_SESSION["msg"] = "Instrumento inválido";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

if ($nombre === "") {
  $_SESSION["msg"] = "El nombre del área es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_instrumento.php?id=$instrumentoId");
  exit;
}

/* ===============================
   4. VALIDAR QUE EL INSTRUMENTO EXISTA
================================ */
$stmtInst = $conexion->prepare("
  SELECT id
  FROM instrumentos
  WHERE id = ?
");
$stmtInst->bind_param("i", $instrumentoId);
$stmtInst->execute();
$stmtInst->store_result();

if ($stmtInst->num_rows === 0) {
  $_SESSION["msg"] = "El instrumento no existe";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$stmtInst->close();

/* ===============================
   5. EVITAR ÁREAS DUPLICADAS
   (por instrumento, case-insensitive)
================================ */
$stmtDup = $conexion->prepare("
  SELECT id
  FROM areas
  WHERE instrumento_id = ?
    AND LOWER(nombre) = LOWER(?)
  LIMIT 1
");
$stmtDup->bind_param("is", $instrumentoId, $nombre);
$stmtDup->execute();
$stmtDup->store_result();

if ($stmtDup->num_rows > 0) {
  $_SESSION["msg"] = "Ya existe un área con ese nombre en este instrumento";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_instrumento.php?id=$instrumentoId");
  exit;
}
$stmtDup->close();

/* ===============================
   6. INSERTAR ÁREA
================================ */
$stmt = $conexion->prepare("
  INSERT INTO areas (
    instrumento_id,
    nombre,
    descripcion
  ) VALUES (?, ?, ?)
");

$stmt->bind_param("iss", $instrumentoId, $nombre, $descripcion);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al guardar el área";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_instrumento.php?id=$instrumentoId");
  exit;
}

$stmt->close();

/* ===============================
   7. MENSAJE ÉXITO + REDIRECCIÓN
================================ */
$_SESSION["msg"] = "Área agregada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: editar_instrumento.php?id=$instrumentoId");
exit;
