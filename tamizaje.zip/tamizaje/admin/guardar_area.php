<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDACIÓN DE SESIÓN
================================ */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* ===============================
   2. RECIBIR DATOS
================================ */
$instrumentoId = (int)($_POST["instrumento_id"] ?? 0);
$nombre        = trim($_POST["nombre"] ?? "");
$descripcion   = trim($_POST["descripcion"] ?? "");

/* ===============================
   3. VALIDACIONES BÁSICAS
================================ */
if ($instrumentoId <= 0) {
  die("Instrumento inválido");
}

if ($nombre === "") {
  die("El nombre del área es obligatorio");
}

/* ===============================
   4. VALIDAR QUE EL INSTRUMENTO EXISTA
================================ */
$stmtInst = $conexion->prepare("
  SELECT id
  FROM instrumentos
  WHERE id = ?
");
$stmtInst->bind_param("i", $instrumentoId);
$stmtInst->execute();

if (!$stmtInst->get_result()->fetch_assoc()) {
  die("El instrumento no existe");
}
$stmtInst->close();

/* ===============================
   5. EVITAR ÁREAS DUPLICADAS
================================ */
$stmtDup = $conexion->prepare("
  SELECT id
  FROM areas
  WHERE instrumento_id = ?
    AND nombre = ?
");
$stmtDup->bind_param("is", $instrumentoId, $nombre);
$stmtDup->execute();

if ($stmtDup->get_result()->fetch_assoc()) {
  die("Ya existe un área con ese nombre en este instrumento");
}
$stmtDup->close();

/* ===============================
   6. INSERTAR ÁREA
================================ */
$stmt = $conexion->prepare("
  INSERT INTO areas (
    instrumento_id,
    nombre,
    descripcion
  ) VALUES (?, ?, ?)
");

if (!$stmt) {
  die("Error SQL al insertar área");
}

$stmt->bind_param(
  "iss",
  $instrumentoId,
  $nombre,
  $descripcion
);

if (!$stmt->execute()) {
  die("Error al guardar el área");
}

$stmt->close();

/* ===============================
   7. REDIRECCIÓN
================================ */
header("Location: editar_instrumento.php?id=$instrumentoId&area_creada=1");
exit;
