<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión y rol
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar método POST
================================ */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Acceso no permitido");
}

/* ===============================
   3. Validar datos obligatorios
================================ */
$instrumentoId = (int)($_POST["instrumento_id"] ?? 0);
$nombre = trim($_POST["nombre"] ?? "");

if ($instrumentoId <= 0) {
    die("Instrumento inválido");
}

if ($nombre === "") {
    die("El nombre del área es obligatorio");
}

/* ===============================
   4. Verificar que el instrumento exista
================================ */
$sqlCheck = "SELECT id FROM instrumentos WHERE id = ?";
$stmtCheck = $conexion->prepare($sqlCheck);
$stmtCheck->bind_param("i", $instrumentoId);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows === 0) {
    die("El instrumento no existe");
}

/* ===============================
   5. Insertar área
================================ */
$sqlInsert = "
    INSERT INTO areas (nombre)
    VALUES (?)
";

$stmtInsert = $conexion->prepare($sqlInsert);

if (!$stmtInsert) {
    die("Error SQL áreas: " . $conexion->error);
}

$stmtInsert->bind_param("s", $nombre);

if (!$stmtInsert->execute()) {
    die("Error al guardar el área");
}

/* ===============================
   6. Redirigir al editor del instrumento
================================ */
header("Location: editar_instrumento.php?id=" . $instrumentoId);
exit;
