<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";
$usuarios = [];

$result = $conexion->query("
  SELECT 
    u.id,
    u.nombre_completo AS nombre,
    u.correo,
    r.nombre AS rol,
    u.activo
  FROM usuarios u
  INNER JOIN roles r ON u.rol_id = r.id
  ORDER BY u.nombre_completo
");


while ($row = $result->fetch_assoc()) {
  $usuarios[] = $row;
}


$sexo = $_SESSION["usuario_sexo"] ?? "Otro";

if ($sexo === "Masculino") {
  $saludo = "Bienvenido";
} elseif ($sexo === "Femenino") {
  $saludo = "Bienvenida";
} else {
  $saludo = "Bienvenido/a";
}

$nombre = htmlspecialchars($_SESSION["usuario_nombre"]);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">
    <a href="admin_cuenta.php" class="btn btn-outline-secondary mb-4">
        ← Volver
    </a>
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1 class="mb-0">Gestión de usuarios</h1>

      <a href="registro.php" class="btn btn-activar">
        + Agregar usuario
      </a>
    </div>
  <div class="table-responsive">
    <table class="table tabla-admin align-middle">
      <thead class="table-dark">
        <tr>
          <th>Nombre</th>
          <th>Correo</th>
          <th>Rol</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($usuarios as $u): ?>
        <tr>
          <td><?= htmlspecialchars($u["nombre"]) ?></td>
          <td><?= htmlspecialchars($u["correo"]) ?></td>
          <td><?= strtoupper($u["rol"]) ?></td>
          <td>
            <?php if ($u["activo"]): ?>
              <span class="badge badge-activo">Activo</span>
            <?php else: ?>
              <span class="badge badge-inactivo">Inactivo</span>
            <?php endif; ?>
          </td>
            <td>
            <?php if ($u["id"] == $_SESSION["usuario_id"]): ?>
              <span class="text-muted">No disponible</span>
            <?php else: ?>
              <a href="editar.php?id=<?= $u["id"] ?>"
                 class="btn btn-sm btn-editar">
                 Editar
              </a>   
              <?php if ($u["activo"]): ?>
                <a href="toggle_usuario.php?id=<?= $u["id"] ?>&accion=desactivar"
                   class="btn btn-sm btn-activar">
                   Desactivar
                </a>
              <?php else: ?>
                <a href="toggle_usuario.php?id=<?= $u["id"] ?>&accion=activar"
                   class="btn btn-sm btn-desactivar">
                   Activar
                </a>
                <a href="eliminar_usuario.php?id=<?= $u["id"] ?>"
                   class="btn btn-sm btn-eliminar"
                   onclick="return confirm('¿Seguro que deseas eliminar este usuario? Esta acción NO se puede deshacer.');">
                   Eliminar
                </a>
              <?php endif; ?>
            <?php endif; ?>
            </td>
        </tr>
      <?php endforeach; ?>

      </tbody>
    </table>
  </div>
</main>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const toast = document.getElementById("mensajeBienvenida");
  if (!toast) return;

  function ocultarToast() {
    toast.classList.add("ocultar");
    setTimeout(() => {
      toast.style.display = "none";
    }, 600);
  }

  // Auto ocultar después de 4 segundos
  setTimeout(ocultarToast, 4000);
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
