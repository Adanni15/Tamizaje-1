<?php
session_start();

if (!isset($_SESSION["usuario_id"])) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = (int)$_SESSION["usuario_id"];
$actual     = $_POST["password_actual"] ?? "";
$nueva      = $_POST["password_nueva"] ?? "";
$confirmar  = $_POST["password_confirmar"] ?? "";

/* Validaciones */
if ($nueva !== $confirmar) {
  $_SESSION["mensaje_error"] = "Las contraseñas no coinciden.";
  header("Location: mi_cuenta.php");
  exit;
}

if (strlen($nueva) < 8) {
  $_SESSION["mensaje_error"] = "La nueva contraseña debe tener al menos 8 caracteres.";
  header("Location: mi_cuenta.php");
  exit;
}

/* Obtener contraseña actual */
$stmt = $conexion->prepare("
  SELECT password 
  FROM usuarios 
  WHERE id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

/* Verificar contraseña actual */
if (!$user || !password_verify($actual, $user["password"])) {
  $_SESSION["mensaje_error"] = "La contraseña actual es incorrecta.";
  header("Location: mi_cuenta.php");
  exit;
}

/* Evitar reutilizar la misma contraseña */
if (password_verify($nueva, $user["password"])) {
  $_SESSION["mensaje_error"] = "La nueva contraseña debe ser diferente a la actual.";
  header("Location: mi_cuenta.php");
  exit;
}

/* Actualizar contraseña + invalidar sesiones */
$hash = password_hash($nueva, PASSWORD_DEFAULT);

$stmt = $conexion->prepare("
  UPDATE usuarios
  SET 
    password = ?,
    session_version = session_version + 1
  WHERE id = ?
");
$stmt->bind_param("si", $hash, $id);
$stmt->execute();

/* Cerrar sesión actual (opcional pero recomendado) */
session_unset();
session_destroy();

/* Forzar nuevo login */
session_start();
$_SESSION["login_error"] = "Tu contraseña fue cambiada. Inicia sesión nuevamente.";
header("Location: ../iniciarsesion.php");
exit;
