<?php
session_start();

if (!isset($_SESSION["usuario_id"])) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = $_SESSION["usuario_id"];

$nombre = trim($_POST["nombre"]);
$correo = trim($_POST["correo"]);
$sexo   = $_POST["sexo"];

$stmt = $conexion->prepare("
  UPDATE usuarios
  SET nombre_completo = ?, correo = ?, sexo = ?
  WHERE id = ?
");
$stmt->bind_param("sssi", $nombre, $correo, $sexo, $id);
$stmt->execute();

/* Actualizar sesión */
$_SESSION["usuario_nombre"] = $nombre;
$_SESSION["usuario_sexo"]   = $sexo;

$_SESSION["mensaje_exito"] = "Datos personales actualizados correctamente.";
header("Location: mi_cuenta.php?ok=1");
exit;
