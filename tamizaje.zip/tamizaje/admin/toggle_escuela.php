<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_POST["id"] ?? 0);
$estado = intval($_POST["estado"] ?? 0);

if ($id <= 0) {
  die("ID inválido");
}

$stmt = $conexion->prepare("
  UPDATE escuelas
  SET activo = ?
  WHERE id = ?
");

$stmt->bind_param("ii", $estado, $id);

if (!$stmt->execute()) {
  die("Error al cambiar estado: " . $stmt->error);
}

$stmt->close();

header("Location: configuracion.php");
exit;
