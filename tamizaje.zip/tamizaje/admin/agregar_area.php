<?php
session_start();
require_once "../config/conexion.php";

/* VALIDACIÓN DE SESIÓN */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* VALIDAR ID */
$instrumentoId = (int)($_GET["instrumento_id"] ?? 0);
if ($instrumentoId <= 0) {
  die("Instrumento inválido");
}

/* OBTENER INSTRUMENTO */
$stmt = $conexion->prepare("
  SELECT id, nombre
  FROM instrumentos
  WHERE id = ?
");

$stmt->bind_param("i", $instrumentoId);
$stmt->execute();
$instrumento = $stmt->get_result()->fetch_assoc();

if (!$instrumento) {
  die("Instrumento no encontrado");
}
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">

  <a href="editar_instrumento.php?id=<?= $instrumentoId ?>" class="btn btn-outline-secondary mb-4">
    ← Volver al instrumento
  </a>

  <div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">Agregar nueva área</h5>
    </div>

    <div class="card-body">
<form action="guardar_area.php" method="post">

  <input type="hidden" name="instrumento_id" value="<?= $instrumentoId ?>">

  <div class="mb-3">
    <label class="form-label">Nombre del área</label>
    <input
      type="text"
      name="nombre"
      class="form-control"
      required
    >
  </div>

  <div class="mb-3">
    <label class="form-label">Descripción</label>
    <textarea
      name="descripcion"
      class="form-control"
      rows="3"
    ></textarea>
  </div>

  <button type="submit" class="btn btn-success">
    Guardar área
  </button>

</form>

    </div>
  </div>

</main>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
