<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar método POST
================================ */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: configuracion.php");
    exit;
}

/* ===============================
   3. Validar ID
================================ */
$id = (int)($_POST["id"] ?? 0);
if ($id <= 0) {
    $_SESSION["msg"] = "Instrumento inválido";
    $_SESSION["msg_type"] = "error";
    header("Location: configuracion.php");
    exit;
}

/* ===============================
   4. Obtener datos
================================ */
$nombre      = trim($_POST["nombre"] ?? "");
$descripcion = trim($_POST["descripcion"] ?? "");

/* ===============================
   5. Validaciones
================================ */
if ($nombre === "") {
    $_SESSION["msg"] = "El nombre del instrumento es obligatorio";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_instrumento.php?id=$id");
    exit;
}

/* ===============================
   6. Validar duplicados (EXCLUYENDO el mismo ID)
================================ */
$check = $conexion->prepare("
    SELECT id
    FROM instrumentos
    WHERE LOWER(nombre) = LOWER(?)
      AND id != ?
    LIMIT 1
");
$check->bind_param("si", $nombre, $id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    $_SESSION["msg"] = "Ya existe otro instrumento con ese nombre";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_instrumento.php?id=$id");
    exit;
}
$check->close();

/* ===============================
   7. Actualizar instrumento
================================ */
$stmt = $conexion->prepare("
    UPDATE instrumentos
    SET nombre = ?, descripcion = ?
    WHERE id = ?
");

$stmt->bind_param("ssi", $nombre, $descripcion, $id);

if (!$stmt->execute()) {
    $_SESSION["msg"] = "Error al actualizar el instrumento";
    $_SESSION["msg_type"] = "error";
    header("Location: editar_instrumento.php?id=$id");
    exit;
}

$stmt->close();

/* ===============================
   8. Mensaje éxito
================================ */
$_SESSION["msg"] = "Instrumento actualizado correctamente";
$_SESSION["msg_type"] = "success";

header("Location: editar_instrumento.php?id=$id");
exit;
