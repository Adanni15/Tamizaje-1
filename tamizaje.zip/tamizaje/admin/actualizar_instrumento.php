<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar método POST
================================ */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: configuracion.php");
    exit;
}

/* ===============================
   3. Validar ID
================================ */
$id = (int)($_POST["id"] ?? 0);
if ($id <= 0) {
    die("Instrumento inválido");
}

/* ===============================
   4. Obtener datos permitidos
================================ */
$nombre      = trim($_POST["nombre"] ?? "");
$descripcion = trim($_POST["descripcion"] ?? "");

/* ===============================
   5. Validaciones
================================ */
if ($nombre === "") {
    die("El nombre del instrumento es obligatorio");
}

/* ===============================
   6. UPDATE (solo campos permitidos)
================================ */
$sql = "
    UPDATE instrumentos
    SET nombre = ?, descripcion = ?
    WHERE id = ?
";

$stmt = $conexion->prepare($sql);
if (!$stmt) {
    die("Error SQL: " . $conexion->error);
}

$stmt->bind_param("ssi", $nombre, $descripcion, $id);

if (!$stmt->execute()) {
    die("Error al actualizar el instrumento");
}

$stmt->close();

/* ===============================
   7. Redirección
================================ */
header("Location: editar_instrumento.php?id=$id&actualizado=1");
exit;
