<?php
session_start();

/* ===============================
   1. Validación de sesión y rol
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

require_once "../config/conexion.php";

/* ===============================
   2. Validar método POST
================================ */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: instrumentos.php");
    exit;
}

/* ===============================
   3. Validar ID del instrumento
================================ */
if (!isset($_POST["id"]) || empty($_POST["id"])) {
    die("ID del instrumento no válido.");
}

$id = intval($_POST["id"]);

/* ===============================
   4. Obtener datos del formulario
================================ */
$nombre       = trim($_POST["nombre"] ?? "");
$descripcion  = trim($_POST["descripcion"] ?? "");
$tipo         = trim($_POST["tipo"] ?? "");
$activo       = isset($_POST["activo"]) ? 1 : 0;

/* ===============================
   5. Construcción dinámica del UPDATE
   (solo actualiza lo que venga lleno)
================================ */
$campos = [];
$parametros = [];
$tipos = "";

if ($nombre !== "") {
    $campos[] = "nombre = ?";
    $parametros[] = $nombre;
    $tipos .= "s";
}

if ($descripcion !== "") {
    $campos[] = "descripcion = ?";
    $parametros[] = $descripcion;
    $tipos .= "s";
}

if ($tipo !== "") {
    $campos[] = "tipo = ?";
    $parametros[] = $tipo;
    $tipos .= "s";
}

/* Siempre se puede actualizar el estado */
$campos[] = "activo = ?";
$parametros[] = $activo;
$tipos .= "i";

/* ===============================
   6. Validar que haya algo a actualizar
================================ */
if (count($campos) === 0) {
    header("Location: editar_instrumento.php?id=$id");
    exit;
}

/* ===============================
   7. Preparar y ejecutar UPDATE
================================ */
$sql = "UPDATE instrumentos SET " . implode(", ", $campos) . " WHERE id = ?";
$parametros[] = $id;
$tipos .= "i";

$stmt = $conexion->prepare($sql);
$stmt->bind_param($tipos, ...$parametros);

if ($stmt->execute()) {
    header("Location: editar_instrumento.php?id=$id&actualizado=1");
    exit;
} else {
    die("Error al actualizar el instrumento.");
}

