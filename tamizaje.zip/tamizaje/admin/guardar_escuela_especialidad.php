<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$escuelaId = (int)($_POST["escuela_id"] ?? 0);
$especialidades = $_POST["especialidades"] ?? [];

if ($escuelaId <= 0) {
  die("Escuela no válida");
}

/* Desactivar todas las especialidades de esa escuela */
$conexion->query("
  UPDATE escuela_especialidad
  SET activo = 0
  WHERE escuela_id = $escuelaId
");

/* Activar las seleccionadas */
$stmt = $conexion->prepare("
  INSERT INTO escuela_especialidad
    (escuela_id, especialidad_id, activo)
  VALUES (?, ?, 1)
  ON DUPLICATE KEY UPDATE activo = 1
");

foreach ($especialidades as $espId) {
  $espId = (int)$espId;
  $stmt->bind_param("ii", $escuelaId, $espId);
  $stmt->execute();
}

$stmt->close();

header("Location: configuracion.php");
exit;
