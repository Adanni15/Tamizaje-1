<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDACIÓN DE SESIÓN
================================ */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* ===============================
   2. RECIBIR DATOS
================================ */
$preguntaId = (int)($_POST["pregunta_id"] ?? 0);
$areaId     = (int)($_POST["area_id"] ?? 0);
$texto      = trim($_POST["texto"] ?? "");

$redFlag     = isset($_POST["red_flag"]) ? 1 : 0;
$esInvertida = isset($_POST["es_invertida"]) ? 1 : 0;
$activa      = isset($_POST["activa"]) ? 1 : 0;

/* ===============================
   3. VALIDACIONES BÁSICAS
================================ */
if ($preguntaId <= 0 || $areaId <= 0) {
  $_SESSION["msg"] = "Pregunta inválida";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

if ($texto === "") {
  $_SESSION["msg"] = "El texto de la pregunta es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_pregunta.php?id=$preguntaId");
  exit;
}

/* ===============================
   4. VALIDAR QUE LA PREGUNTA EXISTA
================================ */
$stmtQ = $conexion->prepare("
  SELECT id
  FROM preguntas
  WHERE id = ?
");
$stmtQ->bind_param("i", $preguntaId);
$stmtQ->execute();
$stmtQ->store_result();

if ($stmtQ->num_rows === 0) {
  $_SESSION["msg"] = "La pregunta no existe";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$stmtQ->close();

/* ===============================
   5. EVITAR DUPLICADOS (MISMA ÁREA)
================================ */
$stmtDup = $conexion->prepare("
  SELECT id
  FROM preguntas
  WHERE area_id = ?
    AND LOWER(texto) = LOWER(?)
    AND id != ?
  LIMIT 1
");
$stmtDup->bind_param("isi", $areaId, $texto, $preguntaId);
$stmtDup->execute();
$stmtDup->store_result();

if ($stmtDup->num_rows > 0) {
  $_SESSION["msg"] = "Ya existe otra pregunta con ese texto en esta área";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_pregunta.php?id=$preguntaId");
  exit;
}
$stmtDup->close();

/* ===============================
   6. ACTUALIZAR PREGUNTA
================================ */
$stmtUp = $conexion->prepare("
  UPDATE preguntas
  SET
    texto = ?,
    red_flag = ?,
    es_invertida = ?,
    activa = ?
  WHERE id = ?
");

$stmtUp->bind_param(
  "siiii",
  $texto,
  $redFlag,
  $esInvertida,
  $activa,
  $preguntaId
);

if (!$stmtUp->execute()) {
  $_SESSION["msg"] = "Error al actualizar la pregunta";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_pregunta.php?id=$preguntaId");
  exit;
}

$stmtUp->close();

/* ===============================
   7. MENSAJE ÉXITO
================================ */
$_SESSION["msg"] = "Pregunta actualizada correctamente";
$_SESSION["msg_type"] = "success";

/* ===============================
   8. REDIRECCIÓN
================================ */
header("Location: editar_pregunta.php?id=$preguntaId");
exit;
