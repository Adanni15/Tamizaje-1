<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validar datos recibidos
================================ */
$preguntaId = (int)($_POST["pregunta_id"] ?? 0);
$areaId     = (int)($_POST["area_id"] ?? 0);
$texto      = trim($_POST["texto"] ?? "");

$redFlag     = isset($_POST["red_flag"]) ? 1 : 0;
$esInvertida = isset($_POST["es_invertida"]) ? 1 : 0;
$activa      = isset($_POST["activa"]) ? 1 : 0;

if ($preguntaId <= 0 || $areaId <= 0 || $texto === "") {
    die("❌ Datos inválidos");
}

/* ===============================
   3. Verificar que la pregunta exista
================================ */
$stmt = $conexion->prepare("
    SELECT id
    FROM preguntas
    WHERE id = ?
");

if (!$stmt) {
    die("❌ Error SQL (verificar pregunta): " . $conexion->error);
}

$stmt->bind_param("i", $preguntaId);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    die("❌ La pregunta no existe");
}

$stmt->close();

/* ===============================
   4. Actualizar la pregunta
================================ */
$stmt = $conexion->prepare("
    UPDATE preguntas
    SET
        texto = ?,
        red_flag = ?,
        es_invertida = ?,
        activa = ?
    WHERE id = ?
");

if (!$stmt) {
    die("❌ Error SQL (actualizar pregunta): " . $conexion->error);
}

$stmt->bind_param(
    "siiii",
    $texto,
    $redFlag,
    $esInvertida,
    $activa,
    $preguntaId
);

if (!$stmt->execute()) {
    die("❌ Error al actualizar la pregunta");
}

$stmt->close();

/* ===============================
   5. Redirección
================================ */
header("Location: editar_area.php?id=" . $areaId);
exit;
