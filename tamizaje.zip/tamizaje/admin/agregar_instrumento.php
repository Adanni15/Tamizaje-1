<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   DATOS
========================= */
$nombre            = trim($_POST["nombre"] ?? "");
$descripcion       = trim($_POST["descripcion"] ?? "");
$tipoEscala        = $_POST["tipo_escala"] ?? "";
$escalaMin         = $_POST["escala_min"] ?? null;
$escalaMax         = $_POST["escala_max"] ?? null;
$creadoPor         = (int) $_SESSION["usuario_id"];
$tipoInstrumento   = "tamizaje";

/* =========================
   VALIDACIONES
========================= */
if ($nombre === "") {
  $_SESSION["msg"] = "El nombre del cuestionario es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

if (!in_array($tipoEscala, ["si_no", "escala"], true)) {
  $_SESSION["msg"] = "Tipo de escala inválido";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* =========================
   VALIDAR DUPLICADO
========================= */
$check = $conexion->prepare("
  SELECT id
  FROM instrumentos
  WHERE LOWER(nombre) = LOWER(?)
  LIMIT 1
");
$check->bind_param("s", $nombre);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
  $_SESSION["msg"] = "Ya existe un cuestionario con ese nombre";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$check->close();

/* =========================
   VALIDAR ESCALA
========================= */
if ($tipoEscala === "escala") {

  if ($escalaMin === null || $escalaMax === null) {
    $_SESSION["msg"] = "Debe definir los valores mínimo y máximo";
    $_SESSION["msg_type"] = "error";
    header("Location: configuracion.php");
    exit;
  }

  $escalaMin = (int) $escalaMin;
  $escalaMax = (int) $escalaMax;

  if ($escalaMin >= $escalaMax) {
    $_SESSION["msg"] = "El valor mínimo debe ser menor al máximo";
    $_SESSION["msg_type"] = "error";
    header("Location: configuracion.php");
    exit;
  }

} else {
  $escalaMin = null;
  $escalaMax = null;
}

/* =========================
   INSERTAR INSTRUMENTO
========================= */
$stmt = $conexion->prepare("
  INSERT INTO instrumentos
    (nombre, descripcion, tipo, tipo_escala, escala_min, escala_max, activo, creado_por)
  VALUES
    (?, ?, ?, ?, ?, ?, 1, ?)
");

$stmt->bind_param(
  "ssssiii",
  $nombre,
  $descripcion,
  $tipoInstrumento,
  $tipoEscala,
  $escalaMin,
  $escalaMax,
  $creadoPor
);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al guardar el cuestionario";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

$stmt->close();

/* =========================
   ÉXITO
========================= */
$_SESSION["msg"] = "Cuestionario agregado correctamente";
$_SESSION["msg_type"] = "success";

header("Location: configuracion.php");
exit;
