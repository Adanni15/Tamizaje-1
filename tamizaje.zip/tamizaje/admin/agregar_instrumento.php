<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   VALIDACIÓN DE DATOS
========================= */
$nombre      = trim($_POST["nombre"] ?? "");
$descripcion = trim($_POST["descripcion"] ?? "");
$tipoEscala  = $_POST["tipo_escala"] ?? null; // si_no | escala
$creadoPor   = (int) $_SESSION["usuario_id"];

/* 🔑 tipo del instrumento (por ahora fijo) */
$tipoInstrumento = "tamizaje";

if ($nombre === "") {
  die("❌ El nombre del cuestionario es obligatorio");
}

if (!in_array($tipoEscala, ["si_no", "escala"], true)) {
  die("❌ Tipo de escala inválido");
}

/* =========================
   INSERTAR INSTRUMENTO
========================= */
$stmt = $conexion->prepare("
  INSERT INTO instrumentos
    (nombre, descripcion, tipo, activo, creado_por)
  VALUES
    (?, ?, ?, 1, ?)
");

if (!$stmt) {
  die("❌ Error en prepare(): " . $conexion->error);
}

$stmt->bind_param(
  "sssi",
  $nombre,
  $descripcion,
  $tipoInstrumento, // 👈 AQUÍ VA tamizaje
  $creadoPor
);

if (!$stmt->execute()) {
  die("❌ Error al guardar el instrumento: " . $stmt->error);
}

$stmt->close();

/* =========================
   REDIRECCIÓN
========================= */
header("Location: configuracion.php");
exit;
