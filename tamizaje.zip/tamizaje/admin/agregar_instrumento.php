<?php
session_start();
require_once "../config/conexion.php";

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* =========================
   DATOS
========================= */
$nombre       = trim($_POST["nombre"] ?? "");
$descripcion  = trim($_POST["descripcion"] ?? "");
$tipoEscala   = $_POST["tipo_escala"] ?? "";
$escalaMin    = $_POST["escala_min"] ?? null;
$escalaMax    = $_POST["escala_max"] ?? null;
$creadoPor    = (int) $_SESSION["usuario_id"];
$tipoInstrumento = "tamizaje";

/* =========================
   VALIDACIONES
========================= */
if ($nombre === "") {
  die("❌ El nombre del cuestionario es obligatorio");
}

if (!in_array($tipoEscala, ["si_no", "escala"], true)) {
  die("❌ Tipo de escala inválido");
}

if ($tipoEscala === "escala") {
  if ($escalaMin === null || $escalaMax === null) {
    die("❌ Debe definir valores mínimo y máximo");
  }

  $escalaMin = (int)$escalaMin;
  $escalaMax = (int)$escalaMax;

  if ($escalaMin >= $escalaMax) {
    die("❌ El valor mínimo debe ser menor al máximo");
  }
} else {
  // si_no → valores nulos (BD alineada)
  $escalaMin = null;
  $escalaMax = null;
}

/* =========================
   INSERT
========================= */
$stmt = $conexion->prepare("
  INSERT INTO instrumentos
    (nombre, descripcion, tipo, tipo_escala, escala_min, escala_max, activo, creado_por)
  VALUES
    (?, ?, ?, ?, ?, ?, 1, ?)
");

if (!$stmt) {
  die("❌ Error prepare(): " . $conexion->error);
}

$stmt->bind_param(
  "ssssiii",
  $nombre,
  $descripcion,
  $tipoInstrumento,
  $tipoEscala,
  $escalaMin,
  $escalaMax,
  $creadoPor
);

if (!$stmt->execute()) {
  die("❌ Error al guardar el instrumento: " . $stmt->error);
}

$stmt->close();

/* =========================
   REDIRECCIÓN
========================= */
header("Location: configuracion.php");
exit;
