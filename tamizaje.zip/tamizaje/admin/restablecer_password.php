<?php
session_start();
require_once "../config/conexion.php";

$token = $_GET["token"] ?? "";

$stmt = $conexion->prepare("
  SELECT id FROM usuarios
  WHERE reset_token = ?
  AND reset_expira > NOW()
");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  die("Enlace inválido o expirado.");
}
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Nueva contraseña</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
</head>

<body class="container mt-5">

<h3>Establecer nueva contraseña</h3>

<form action="guardar_nueva_password.php" method="POST" class="card p-4 mt-3">
  <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

  <input type="password" name="password" class="form-control mb-3" minlength="8" required>
  <button class="btn btn-activar">Guardar contraseña</button>
</form>

</body>
</html>
