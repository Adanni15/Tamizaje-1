<?php
session_start();

if ($_SESSION["usuario_rol"] !== "administrador") {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$nombre = trim($_POST["nombre"]);

if ($nombre === "") {
  header("Location: admin_cuenta.php");
  exit;
}

$stmt = $conexion->prepare("
  INSERT INTO especialidades (nombre, activa)
  VALUES (?, 1)
");
$stmt->bind_param("s", $nombre);
$stmt->execute();

header("Location: admin_cuenta.php");
exit;
