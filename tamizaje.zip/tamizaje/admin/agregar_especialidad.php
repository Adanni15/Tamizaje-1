<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* =======================
   LIMPIAR DATOS
======================= */
$nombre = trim($_POST["nombre"] ?? "");

/* =======================
   VALIDACIÓN
======================= */
if ($nombre === "") {
  $_SESSION["msg"] = "El nombre de la especialidad es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* =======================
   VALIDAR DUPLICADOS
======================= */
$check = $conexion->prepare("
  SELECT id
  FROM especialidades
  WHERE LOWER(nombre) = LOWER(?)
  LIMIT 1
");
$check->bind_param("s", $nombre);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
  $check->close();
  $_SESSION["msg"] = "La especialidad ya existe";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$check->close();

/* =======================
   INSERTAR ESPECIALIDAD
======================= */
$stmt = $conexion->prepare("
  INSERT INTO especialidades (nombre, activa)
  VALUES (?, 1)
");

$stmt->bind_param("s", $nombre);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al agregar especialidad";
  $_SESSION["msg_type"] = "error";
  $stmt->close();
  header("Location: configuracion.php");
  exit;
}

$stmt->close();

/* =======================
   MENSAJE DE ÉXITO
======================= */
$_SESSION["msg"] = "Especialidad agregada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: configuracion.php");
exit;
