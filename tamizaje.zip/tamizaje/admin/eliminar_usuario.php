<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_GET["id"] ?? 0);

// Evitar que el admin se borre solo
if ($id > 0 && $id != $_SESSION["usuario_id"]) {

  $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
}

header("Location: usuarios.php");
exit;
