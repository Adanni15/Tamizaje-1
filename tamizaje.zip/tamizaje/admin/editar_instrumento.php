<?php
session_start();
require_once "../config/conexion.php";

/* VALIDACIÓN DE SESIÓN */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* VALIDAR ID */
$instrumentoId = (int)($_GET["id"] ?? 0);
if ($instrumentoId <= 0) {
  die("Instrumento inválido");
}

/* OBTENER INSTRUMENTO */
$sql = "
  SELECT id, nombre, descripcion
  FROM instrumentos
  WHERE id = ?
";

$stmt = $conexion->prepare($sql);
if (!$stmt) {
  die("Error SQL instrumentos: " . $conexion->error);
}

$stmt->bind_param("i", $instrumentoId);
$stmt->execute();
$instrumento = $stmt->get_result()->fetch_assoc();

if (!$instrumento) {
  die("Instrumento no encontrado");
}

/* OBTENER ÁREAS USADAS EN EL INSTRUMENTO */
$areas = [];

$sqlAreas = "
  SELECT 
    a.id,
    a.nombre,
    COUNT(p.id) AS total_preguntas
  FROM areas a
  LEFT JOIN preguntas p ON p.area_id = a.id
  WHERE a.instrumento_id = ?
  GROUP BY a.id, a.nombre
  ORDER BY a.nombre
";


$stmtAreas = $conexion->prepare($sqlAreas);
if (!$stmtAreas) {
  die("Error SQL áreas: " . $conexion->error);
}

$stmtAreas->bind_param("i", $instrumentoId);
$stmtAreas->execute();
$resultAreas = $stmtAreas->get_result();

while ($row = $resultAreas->fetch_assoc()) {
  $areas[] = $row;
}

$sqlTienePreguntas = "
  SELECT COUNT(*) AS total
  FROM preguntas p
  INNER JOIN areas a ON a.id = p.area_id
  WHERE a.instrumento_id = ?
";

$stmtCheck = $conexion->prepare($sqlTienePreguntas);
$stmtCheck->bind_param("i", $instrumentoId);
$stmtCheck->execute();
$tienePreguntas = $stmtCheck->get_result()->fetch_assoc()["total"] > 0;
$stmtCheck->close();

?>


<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_resultados.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">
    <a href="configuracion.php" class="btn btn-secondary mb-4">
        ← Volver
    </a>
    <?php if (isset($_SESSION["msg"])): ?>
  <div class="row mb-4">
    <div class="col-12">
      <div
        id="mensajeSistema"
        class="mensaje-sistema card-test-e text-center <?= $_SESSION["msg_type"] === "success" ? "border-success" : "border-danger" ?>"
      >
        <?= htmlspecialchars($_SESSION["msg"]) ?>
      </div>
    </div>
  </div>
  <?php
    unset($_SESSION["msg"]);
    unset($_SESSION["msg_type"]);
  ?>
<?php endif; ?>
    <div class="card shadow-sm">
  <div class="card-header">
    <h5 class="mb-0">Editar instrumento</h5>
  </div>

  <div class="card-body">
    <?php if ($tienePreguntas): ?>
      <div class="alert alert-warning">
        ⚠️ Este cuestionario ya tiene preguntas registradas.
        Solo se recomienda modificar el nombre o la descripción.
      </div>
    <?php endif; ?>

    <form action="actualizar_instrumento.php" method="post">
      <input type="hidden" name="id" value="<?= $instrumento["id"] ?>">

      <div class="mb-3">
        <label class="form-label">Nombre del instrumento</label>
        <input
          type="text"
          name="nombre"
          class="form-control"
          required
          value="<?= htmlspecialchars($instrumento["nombre"]) ?>"
        >
      </div>

      <div class="mb-3">
        <label class="form-label">Descripción</label>
        <textarea
          name="descripcion"
          class="form-control"
          rows="3"
        ><?= htmlspecialchars($instrumento["descripcion"]) ?></textarea>
      </div>

      <button type="submit" class="btn btn-primary">
        Guardar cambios
      </button>
    </form>
  </div>
</div>
<div class="card shadow-sm mt-4">
  <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Áreas del cuestionario</h5>
    <a
      href="agregar_area.php?instrumento_id=<?= $instrumentoId ?>"
      class="btn btn-primary"
    >
      ➕ Nueva área
    </a>
  </div>

  <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
    <table class="table table-bordered table-hover align-middle">
      <thead class="sticky-top">
        <tr>
          <th>Área</th>
          <th class="text-center">Acciones</th>
        </tr>
      </thead>
      <tbody>

      <?php if (empty($areas)): ?>
        <tr>
          <td colspan="2" class="text-center text-muted">
            No hay áreas registradas
          </td>
        </tr>
      <?php endif; ?>

      <?php foreach ($areas as $area): ?>
        <tr>
          <td>
            <?= htmlspecialchars($area["nombre"]) ?>
            <br>
            <small class="text-muted">
              Preguntas: <?= (int)$area["total_preguntas"] ?>
            </small>
          </td>

          <td class="text-center">
            <a
              href="editar_area.php?id=<?= $area["id"] ?>"
              class="btn btn-sm btn-primary"
            >
              Editar área
            </a>
            <a
              href="#"
              class="btn btn-sm btn-danger"
              data-bs-toggle="modal"
              data-bs-target="#eliminarAreaModal"
              data-area-id="<?= $area["id"] ?>"
              data-area-nombre="<?= htmlspecialchars($area["nombre"]) ?>"
            >
              Eliminar área
            </a>

          </td>
        </tr>
      <?php endforeach; ?>

      </tbody>
    </table>
  </div>
</div>
</main>

<div class="modal fade" id="eliminarAreaModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title text-danger">Eliminar área</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <p>
          ¿Estás seguro de eliminar el área
          <strong id="nombreArea"></strong>?
        </p>
        <p class="text-danger mb-0">
          ⚠️ Esta acción eliminará también todas las preguntas asociadas.
        </p>
      </div>

      <div class="modal-footer">
        <form action="eliminar_area.php" method="post">
          <input type="hidden" name="area_id" id="areaIdInput">
          <input type="hidden" name="instrumento_id" value="<?= $instrumentoId ?>">

          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
          <button type="submit" class="btn btn-danger">
            Sí, eliminar
          </button>
        </form>
      </div>

    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
const eliminarAreaModal = document.getElementById('eliminarAreaModal');

eliminarAreaModal.addEventListener('show.bs.modal', function (event) {
  const button = event.relatedTarget;

  const areaId = button.getAttribute('data-area-id');
  const areaNombre = button.getAttribute('data-area-nombre');

  document.getElementById('areaIdInput').value = areaId;
  document.getElementById('nombreArea').textContent = areaNombre;
});
</script>
<footer class="footer-sistema mt-auto footer-margin">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>

</body>
</html>
