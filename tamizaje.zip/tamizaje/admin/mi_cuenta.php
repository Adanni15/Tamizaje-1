<?php
session_start();

if (!isset($_SESSION["usuario_id"])) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id_usuario = $_SESSION["usuario_id"];

$stmt = $conexion->prepare("
  SELECT nombre_completo, correo, sexo
  FROM usuarios
  WHERE id = ?
");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

if (!$usuario) {
  die("Usuario no encontrado");
}


?>

<?php
$sexo = $_SESSION["usuario_sexo"] ?? "Otro";

if ($sexo === "Masculino") {
  $saludo = "Bienvenido";
} elseif ($sexo === "Femenino") {
  $saludo = "Bienvenida";
} else {
  $saludo = "Bienvenido/a";
}

$nombre = htmlspecialchars($_SESSION["usuario_nombre"]);
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- CSS propio -->
  <link rel="stylesheet" href="../css/style2.css">
</head>
<?php if (!empty($_SESSION["mostrar_bienvenida"])): ?>
  <div id="mensajeBienvenida" class="toast-institucional">
    <div class="toast-header">
      <span class="toast-icon"></span>
      <strong><?= $saludo ?>, <?= $nombre ?></strong>
    </div>
    <div class="toast-body">
      Has iniciado sesión como <b>Administrador</b>
    </div>
  </div>
<?php unset($_SESSION["mostrar_bienvenida"]); ?>
<?php endif; ?>


<body>
<header>
  <div class="content">
    <div class="menu container">

      <!-- Logo -->
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>

      <!-- Botón hamburguesa -->
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>

      <!-- Navbar -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<?php if (!empty($_SESSION["mensaje_exito"])): ?>
  <div class="mensaje-institucional exito">
    <i class="bi bi-check-circle-fill"></i>
    <span><?= htmlspecialchars($_SESSION["mensaje_exito"]) ?></span>
  </div>
<?php unset($_SESSION["mensaje_exito"]); ?>
<?php endif; ?>


<?php if (!empty($_SESSION["mensaje_error"])): ?>
  <div class="mensaje-institucional error">
    <i class="bi bi-exclamation-triangle-fill"></i>
    <span><?= htmlspecialchars($_SESSION["mensaje_error"]) ?></span>
  </div>
<?php unset($_SESSION["mensaje_error"]); ?>
<?php endif; ?>




<main class="container mt-5">
<div>
  <a href="admin_cuenta.php" class="btn btn-secondary mb-4">
      ← Volver
  </a>
</div>
<h1 class="mb-4 card-test-e">Mi cuenta</h1>


<div class="card card-admin mb-4">
  <div class="card-body">
    <h5 class="card-title mb-3">Datos personales</h5>

    <form id="formDatos" action="actualizar_mi_cuenta.php" method="POST">

      <div class="mb-3">
        <label class="form-label">Nombre completo</label>
        <input type="text" name="nombre" class="form-control" required
          value="<?= htmlspecialchars($usuario["nombre_completo"]) ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Correo electrónico</label>
        <input type="email" name="correo" class="form-control" required
          value="<?= htmlspecialchars($usuario["correo"]) ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Sexo</label>
        <select name="sexo" class="form-select">
          <option value="Masculino" <?= $usuario["sexo"]==="Masculino"?"selected":"" ?>>Masculino</option>
          <option value="Femenino" <?= $usuario["sexo"]==="Femenino"?"selected":"" ?>>Femenino</option>
          <option value="Otro" <?= $usuario["sexo"]==="Otro"?"selected":"" ?>>Otro</option>
        </select>
      </div>
        <button
          type="button"
          id="btnGuardar"
          class="btn btn-activar px-4"
          disabled
          data-bs-toggle="modal"
          data-bs-target="#modalConfirmacion">
          Guardar cambios
        </button>
    </form>
  </div>
</div>
<div class="card card-admin mb-4">
  <div class="card-body">
    <h5 class="card-title mb-3">Cambiar contraseña</h5>

    <form id="formCambiarPassword" action="cambiar_password.php" method="POST">
        <div class="mb-3">
          <label class="form-label">Contraseña actual</label>
          <div class="input-group">
            <input
              type="password"
              id="password_actual"
              name="password_actual"
              class="form-control"
              required>
            <button
              type="button"
              class="btn btn-outline-secondary"
              onclick="togglePassword('password_actual', this)">
              <i class="bi bi-eye"></i>
            </button>
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Nueva contraseña</label>
          <input
            type="password"
            id="password_nueva"
            name="password_nueva"
            class="form-control"
            minlength="8"
            required>
        </div>
        <div class="mb-3">
          <label class="form-label">Confirmar nueva contraseña</label>
          <input
            type="password"
            id="password_confirmar"
            name="password_confirmar"
            class="form-control"
            minlength="8"
            required>
        </div>
            <button
              type="button"
              id="btnCambiarPassword"
              class="btn btn-desactivar px-4"
              disabled
              data-bs-toggle="modal"
              data-bs-target="#modalConfirmarPassword">
              Cambiar contraseña
            </button>
    </form>
    <div class="text-center mt-3">
</div>

  </div>
</div>


</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const toast = document.getElementById("mensajeBienvenida");
  const cerrar = document.getElementById("cerrarToast");

  function ocultarToast() {
    toast.classList.add("ocultar");

    // Quitar del DOM después de la animación
    setTimeout(() => {
      toast.style.display = "none";
    }, 600);
  }

  // Auto cerrar después de 4 segundos
  setTimeout(ocultarToast, 4000);

  // Cerrar manual
  cerrar.addEventListener("click", ocultarToast);
});
</script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("formDatos");
  const btnGuardar = document.getElementById("btnGuardar");

  const valoresIniciales = {};
  form.querySelectorAll("input, select").forEach(el => {
    valoresIniciales[el.name] = el.value;
  });

  form.addEventListener("input", () => {
    let cambiado = false;

    form.querySelectorAll("input, select").forEach(el => {
      if (el.value !== valoresIniciales[el.name]) {
        cambiado = true;
      }
    });

    btnGuardar.disabled = !cambiado;
  });
});
</script>

<script>
function togglePassword(id, btn) {
  const input = document.getElementById(id);
  const icon = btn.querySelector("i");

  if (input.type === "password") {
    input.type = "text";
    icon.classList.remove("bi-eye");
    icon.classList.add("bi-eye-slash");
  } else {
    input.type = "password";
    icon.classList.remove("bi-eye-slash");
    icon.classList.add("bi-eye");
  }
}
</script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const actual = document.getElementById("password_actual");
  const nueva = document.getElementById("password_nueva");
  const confirmar = document.getElementById("password_confirmar");
  const btn = document.getElementById("btnCambiarPassword");

  function validarPasswords() {
    const actualVal = actual.value.trim();
    const nuevaVal = nueva.value.trim();
    const confirmarVal = confirmar.value.trim();

    let valido =
      actualVal.length > 0 &&
      nuevaVal.length >= 8 &&
      confirmarVal.length >= 8 &&
      nuevaVal === confirmarVal &&
      nuevaVal !== actualVal;

    btn.disabled = !valido;
  }

  actual.addEventListener("input", validarPasswords);
  nueva.addEventListener("input", validarPasswords);
  confirmar.addEventListener("input", validarPasswords);
});
</script>

<script>
setTimeout(() => {
  document.querySelectorAll('.mensaje-institucional')
    .forEach(m => m.remove());
}, 4500);
</script>


<div class="modal fade" id="modalConfirmacion" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Confirmar cambios</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        ¿Estás seguro de que deseas guardar los cambios en tu cuenta?
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
          Cancelar
        </button>

        <button type="submit" class="btn btn-activar" form="formDatos">
          Confirmar
        </button>
      </div>

    </div>
  </div>
</div>
<div class="modal fade" id="modalConfirmarPassword" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Confirmar cambio de contraseña</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <p>
          ¿Estás seguro de que deseas cambiar tu contraseña?
        </p>
        <small class="text-muted">
          Asegúrate de recordar tu nueva contraseña, ya que será necesaria para futuros accesos.
        </small>
      </div>

      <div class="modal-footer">
        <button
          type="button"
          class="btn btn-secondary"
          data-bs-dismiss="modal">
          Cancelar
        </button>
        <button
          type="submit"
          class="btn btn-activar"
          form="formCambiarPassword">
          Confirmar
        </button>
      </div>

    </div>
  </div>
</div>

<footer class="footer-sistema mt-auto footer-margin">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
