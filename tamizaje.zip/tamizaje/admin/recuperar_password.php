<?php
session_start();

/* Si el usuario ya inició sesión, no debe recuperar contraseña */
if (isset($_SESSION["usuario_id"])) {
  header("Location: ../admin/admin_cuenta.php");
  exit;
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Recuperar contraseña</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
</head>

<body class="container mt-5">

<h2 class="mb-4">Recuperar contraseña</h2>

<?php if (!empty($_SESSION["mensaje_exito"])): ?>
  <div class="mensaje-institucional exito">
    <i class="bi bi-check-circle-fill"></i>
    <?= htmlspecialchars($_SESSION["mensaje_exito"]) ?>
  </div>
<?php unset($_SESSION["mensaje_exito"]); endif; ?>

<?php if (!empty($_SESSION["mensaje_error"])): ?>
  <div class="mensaje-institucional error">
    <i class="bi bi-exclamation-triangle-fill"></i>
    <?= htmlspecialchars($_SESSION["mensaje_error"]) ?>
  </div>
<?php unset($_SESSION["mensaje_error"]); endif; ?>

<form action="enviar_link_password.php" method="POST" class="card p-4 mt-3">

  <label class="form-label">Correo electrónico</label>
  <input
    type="email"
    name="correo"
    class="form-control mb-3"
    placeholder="correo@ejemplo.com"
    required>

  <button type="submit" class="btn btn-activar w-100">
    Enviar enlace de recuperación
  </button>

</form>

<div class="text-center mt-3">
  <a href="../iniciarsesion.php" class="link-institucional">
    Volver a iniciar sesión
  </a>
</div>

<?php if (!empty($_SESSION["debug_link"])): ?>
  <div class="alert alert-warning mt-4">
    <strong>Link de prueba (solo desarrollo):</strong><br>
    <a href="<?= htmlspecialchars($_SESSION["debug_link"]) ?>">
      <?= htmlspecialchars($_SESSION["debug_link"]) ?>
    </a>
  </div>
<?php unset($_SESSION["debug_link"]); endif; ?>

</body>
</html>
