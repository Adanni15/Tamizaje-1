<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_POST["id"] ?? 0);

if ($id <= 0) {
  die("ID inválido");
}

/* 🔍 Verificar si la escuela tiene aplicaciones */
$check = $conexion->prepare("
  SELECT COUNT(*) AS total
  FROM aplicaciones_test
  WHERE escuela_id = ?
");

$check->bind_param("i", $id);
$check->execute();
$result = $check->get_result()->fetch_assoc();
$check->close();

if ($result["total"] > 0) {
  die("No se puede eliminar la escuela porque tiene aplicaciones registradas.");
}

/* 🗑️ Eliminar escuela */
$stmt = $conexion->prepare("
  DELETE FROM escuelas
  WHERE id = ?
");

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
  die("Error al eliminar escuela: " . $stmt->error);
}

$stmt->close();

header("Location: configuracion.php");
exit;
