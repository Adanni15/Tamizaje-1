<?php
session_start();

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* =========================
   DATOS DEL USUARIO
========================= */
$sexo = $_SESSION["usuario_sexo"] ?? "Otro";

switch ($sexo) {
  case "Masculino":
    $saludo = "Bienvenido";
    break;
  case "Femenino":
    $saludo = "Bienvenida";
    break;
  default:
    $saludo = "Bienvenido/a";
}

$nombre = htmlspecialchars($_SESSION["usuario_nombre"] ?? "Usuario");

/* =========================
   CONFIGURACIÓN DEL SISTEMA
========================= */
$config = [];

$resultConfig = $conexion->query("
  SELECT clave, valor
  FROM configuracion_sistema
");

if (!$resultConfig) {
  die("Error en configuración: " . $conexion->error);
}

while ($row = $resultConfig->fetch_assoc()) {
  $config[$row["clave"]] = $row["valor"];
}

$usarEspecialidades = (int)($config["usar_especialidades"] ?? 0);

/* =========================
   ESPECIALIDADES
========================= */
$especialidades = [];

if ($usarEspecialidades === 1) {
  $resultEsp = $conexion->query("
    SELECT id, nombre, activa
    FROM especialidades
    WHERE activa = 1
    ORDER BY nombre
  ");

  if (!$resultEsp) {
    die("Error en especialidades: " . $conexion->error);
  }

  while ($row = $resultEsp->fetch_assoc()) {
    $especialidades[] = $row;
  }
}

/* =========================
   INSTRUMENTOS
========================= */
$instrumentos = [];

$resultInst = $conexion->query("
  SELECT 
    i.id,
    i.nombre,
    i.descripcion,
    i.tipo,
    i.activo,
    MIN(p.tipo_respuesta) AS tipo_respuesta
  FROM instrumentos i
  LEFT JOIN preguntas p ON p.instrumento_id = i.id
  GROUP BY i.id, i.nombre, i.descripcion, i.tipo, i.activo
  ORDER BY i.nombre
");


if (!$resultInst) {
  die("Error en instrumentos: " . $conexion->error);
}

while ($row = $resultInst->fetch_assoc()) {
  $instrumentos[] = $row;
}

$inconsistentes = $conexion->query("
  SELECT instrumento_id
  FROM preguntas
  GROUP BY instrumento_id
  HAVING COUNT(DISTINCT tipo_respuesta) > 1
");

if ($inconsistentes && $inconsistentes->num_rows > 0) {
  error_log("⚠️ Instrumentos con tipos de respuesta mezclados detectados");
}


?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">
    <a href="admin_cuenta.php" class="btn btn-outline-secondary mb-4">
        ← Volver
    </a>
    <h2 class="mb-4">Configuración del sistema</h2>

    <div class="card shadow-sm mb-4">
      <div class="card-body">
        <h5 class="card-title">Especialidades</h5>
        <p class="card-text">
          Define si el sistema debe solicitar la especialidad del alumno
          durante la aplicación del test.
        </p>
    
        <form action="guardar_configuracion.php" method="post">
          <div class="form-check form-switch mb-3">
            <input
              class="form-check-input"
              type="checkbox"
              id="usarEspecialidades"
              name="usar_especialidades"
              value="1"
              <?= $usarEspecialidades ? "checked" : "" ?>
            >
            <label class="form-check-label" for="usarEspecialidades">
              Solicitar especialidad
            </label>
          </div>
    
          <button type="submit" class="btn btn-primary">
            Guardar cambios
          </button>
        </form>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-3">      
        <button
          class="btn btn-success btn-sm"
          data-bs-toggle="modal"
          data-bs-target="#modalAgregarEspecialidad"
        >
          ➕ Agregar especialidad
        </button>
    </div>
    <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-light sticky-top">
          <tr>
            <th>Especialidad</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>

          <?php if (empty($especialidades)): ?>
            <tr>
              <td colspan="3" class="text-center text-muted">
                No hay especialidades registradas
              </td>
            </tr>
          <?php endif; ?>

          <?php foreach ($especialidades as $esp): ?>
            <tr>
              <td><?= htmlspecialchars($esp["nombre"]) ?></td>

              <td class="text-center">
                <?php if ($esp["activa"]): ?>
                  <span class="badge bg-success">Activa</span>
                <?php else: ?>
                  <span class="badge bg-secondary">Inactiva</span>
                <?php endif; ?>
              </td>

              <td class="text-center">
                <!-- ACTIVAR / DESACTIVAR -->
                <form
                  action="toggle_especialidad.php"
                  method="post"
                  class="d-inline"
                >
                  <input type="hidden" name="id" value="<?= $esp["id"] ?>">
                  <input type="hidden" name="estado" value="<?= $esp["activa"] ? 0 : 1 ?>">

                  <button
                    class="btn btn-sm <?= $esp["activa"] ? "btn-warning" : "btn-success" ?>"
                    type="submit"
                  >
                    <?= $esp["activa"] ? "Desactivar" : "Activar" ?>
                  </button>
                </form>

                <!-- ELIMINAR -->
                <form
                  action="eliminar_especialidad.php"
                  method="post"
                  class="d-inline"
                  onsubmit="return confirm('¿Eliminar esta especialidad?');"
                >
                  <input type="hidden" name="id" value="<?= $esp["id"] ?>">
                  <button class="btn btn-sm btn-danger">
                    Eliminar
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>

        </tbody>
      </table>
    </div>
    <hr class="my-5">

    <h4 class="mb-3">Cuestionarios</h4>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="text-muted mb-0">
        Administra los instrumentos de evaluación del sistema.
      </p>

      <button
        class="btn btn-success btn-sm"
        data-bs-toggle="modal"
        data-bs-target="#modalAgregarInstrumento"
      >
        ➕ Nuevo cuestionario
      </button>
    </div>

    <div class="table-responsive" style="max-height: 300px; overflow-y:auto;">
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-light sticky-top">
          <tr>
            <th>Nombre</th>
            <th>Tipo de respuestas</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>

        <?php if (empty($instrumentos)): ?>
          <tr>
            <td colspan="4" class="text-center text-muted">
              No hay cuestionarios registrados
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($instrumentos as $inst): ?>
          <tr>
            <td>
              <strong><?= htmlspecialchars($inst["nombre"]) ?></strong><br>
              <small class="text-muted">
                <?= htmlspecialchars($inst["descripcion"]) ?>
              </small>
            </td>

            <td>
              <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $inst['tipo_respuesta'] ?? 'Sin definir'))) ?>
            </td>

            <td class="text-center">
              <?php if ($inst["activo"]): ?>
                <span class="badge bg-success">Activo</span>
              <?php else: ?>
                <span class="badge bg-secondary">Inactivo</span>
              <?php endif; ?>
            </td>

            <td class="text-center">

              <!-- ACTIVAR / DESACTIVAR -->
              <form action="toggle_instrumento.php" method="post" class="d-inline">
                <input type="hidden" name="id" value="<?= $inst["id"] ?>">
                <input type="hidden" name="estado" value="<?= $inst["activo"] ? 0 : 1 ?>">
                <button class="btn btn-sm <?= $inst["activo"] ? "btn-warning" : "btn-success" ?>">
                  <?= $inst["activo"] ? "Desactivar" : "Activar" ?>
                </button>
              </form>

              <!-- ELIMINAR -->
              <form
                action="eliminar_instrumento.php"
                method="post"
                class="d-inline"
                onsubmit="return confirm('¿Eliminar este cuestionario?');"
              >
                <input type="hidden" name="id" value="<?= $inst["id"] ?>">
                <button class="btn btn-sm btn-danger">
                  Eliminar
                </button>
              </form>
              <a
                href="editar_instrumento.php?id=<?= $inst["id"] ?>"
                class="btn btn-sm btn-primary"
              >
                Editar
              </a>


            </td>
          </tr>
        <?php endforeach; ?>

        </tbody>
      </table>
    </div>




</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<div class="modal fade" id="modalAgregarEspecialidad" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="agregar_especialidad.php" method="post">
        <div class="modal-header">
          <h5 class="modal-title">Agregar especialidad</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <label class="form-label">Nombre de la especialidad</label>
          <input
            type="text"
            name="nombre"
            class="form-control"
            required
          >
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success">
            Guardar
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>
      </form>

    </div>
  </div>
</div>
<div class="modal fade" id="modalAgregarInstrumento" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="agregar_instrumento.php" method="post">

        <div class="modal-header">
          <h5 class="modal-title">Nuevo cuestionario</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required>

          <label class="form-label mt-3">Descripción</label>
          <textarea name="descripcion" class="form-control" rows="2"></textarea>

          <label class="form-label mt-3">Tipo de escala</label>
          <select name="tipo_escala" id="tipoEscala" class="form-select" required>
            <option value="si_no">Sí / No</option>
            <option value="escala">Escala numérica</option>
          </select>

          <div id="configEscala" style="display:none;">
            <label class="form-label mt-3">Valor mínimo</label>
            <input type="number" name="escala_min" class="form-control">

            <label class="form-label mt-2">Valor máximo</label>
            <input type="number" name="escala_max" class="form-control">
          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success">
            Guardar
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>

      </form>

    </div>
  </div>
</div>

<script>
document.getElementById("tipoEscala").addEventListener("change", function () {
  document.getElementById("configEscala").style.display =
    this.value === "escala" ? "block" : "none";
});
</script>


</body>
</html>
