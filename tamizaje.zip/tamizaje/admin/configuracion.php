<?php
session_start();

/* =========================
   VALIDACIÓN DE SESIÓN
========================= */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* =========================
   DATOS DEL USUARIO
========================= */
$sexo = $_SESSION["usuario_sexo"] ?? "Otro";

switch ($sexo) {
  case "Masculino":
    $saludo = "Bienvenido";
    break;
  case "Femenino":
    $saludo = "Bienvenida";
    break;
  default:
    $saludo = "Bienvenido/a";
}

$nombre = htmlspecialchars($_SESSION["usuario_nombre"] ?? "Usuario");

/* =========================
   CONFIGURACIÓN DEL SISTEMA
========================= */
$config = [];

$resultConfig = $conexion->query("
  SELECT clave, valor
  FROM configuracion_sistema
");

if (!$resultConfig) {
  die("Error en configuración: " . $conexion->error);
}

while ($row = $resultConfig->fetch_assoc()) {
  $config[$row["clave"]] = $row["valor"];
}

$usarEspecialidades = (int)($config["usar_especialidades"] ?? 0);

/* =========================
   ESPECIALIDADES
========================= */
$especialidades = [];

if ($usarEspecialidades === 1) {
  $resultEsp = $conexion->query("
    SELECT id, nombre, activa
    FROM especialidades
    ORDER BY nombre
  ");


  if (!$resultEsp) {
    die("Error en especialidades: " . $conexion->error);
  }

  while ($row = $resultEsp->fetch_assoc()) {
    $especialidades[] = $row;
  }
}

/* =========================
   INSTRUMENTOS
========================= */
$instrumentos = [];

$resultInst = $conexion->query("
  SELECT 
    id,
    nombre,
    descripcion,
    tipo,
    tipo_escala,
    escala_min,
    escala_max,
    activo
  FROM instrumentos
  ORDER BY nombre
");



if (!$resultInst) {
  die("Error en instrumentos: " . $conexion->error);
}

while ($row = $resultInst->fetch_assoc()) {
  $instrumentos[] = $row;
}
/* =========================
   ESCUELAS
========================= */
$escuelas = [];

$resultEsc = $conexion->query("
  SELECT id, nombre, clave, direccion, activo
  FROM escuelas
  ORDER BY nombre
");

if (!$resultEsc) {
  die("Error en escuelas: " . $conexion->error);
}

while ($row = $resultEsc->fetch_assoc()) {
  $escuelas[] = $row;
}

/* =========================
   ESCUELAS ACTIVAS
========================= */
$escuelasActivas = $conexion->query("
  SELECT id, nombre
  FROM escuelas
  WHERE activo = 1
  ORDER BY nombre
");

if (!$escuelasActivas) {
  die("Error escuelas activas: " . $conexion->error);
}

/* =========================
   ESPECIALIDADES ACTIVAS
========================= */
$especialidadesActivas = $conexion->query("
  SELECT id, nombre
  FROM especialidades
  WHERE activa = 1
  ORDER BY nombre
");

if (!$especialidadesActivas) {
  die("Error especialidades activas: " . $conexion->error);
}


?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrar Cuenta | Test de Tamizaje</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style2.css">
  <link rel="stylesheet" href="../css/style_resultados.css">
  <link rel="stylesheet" href="../css/style_usuarios.css">
</head>
<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="../index.php" class="logo">
        <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>
      <input type="checkbox" id="menu">
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32">
            <g fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path d="M3 7h18"/>
              <path d="M3 12h18"/>
              <path d="M3 17h18"/>
            </g>
          </svg>
        </label>
      </div>
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="../index.php">Test</a></li>
            <li><a href="../acercade.php">Acerca de</a></li>
            <li><a href="../resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
              <a href="admin_cuenta.php" class="usuario-link">
                <span class="usuario-badge">
                  <span class="usuario-icono">👤</span>
                  <span class="usuario-texto">
                    <span class="usuario-nombre">
                      <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                    </span>
                    <span class="usuario-rol">
                      <?= strtoupper($_SESSION["usuario_rol"]) ?>
                    </span>
                  </span>
                </span>
              </a>
          <li>
            <a href="../config/logout.php" class="logout">Cerrar sesión</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<main class="container mt-5">
<div>
  <a href="admin_cuenta.php" class="btn btn-secondary mb-4">
      ← Volver
  </a>
</div>



  <h2 class="mb-4 card-test-e">Configuración del sistema</h2>
<?php if (isset($_SESSION["msg"])): ?>
  <div class="row mb-4">
    <div class="col-12">
      <div
        id="mensajeSistema"
        class="mensaje-sistema card-test-e text-center <?= $_SESSION["msg_type"] === "success" ? "border-success" : "border-danger" ?>"
      >
        <?= htmlspecialchars($_SESSION["msg"]) ?>
      </div>
    </div>
  </div>
  <?php
    unset($_SESSION["msg"]);
    unset($_SESSION["msg_type"]);
  ?>
<?php endif; ?>

        
    <div class="card shadow-sm mb-4">
      <div class="card-body">
        <h2 class="mb-4 card-test-e">Escuelas</h2>

          <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="text-muted mb-0">
              Administra las escuelas registradas en el sistema.
            </p>

            <button
              class="btn btn-activar"
              data-bs-toggle="modal"
              data-bs-target="#modalAgregarEscuela"
            >
              ➕ Agregar escuela
            </button>
          </div>

          <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
            <table class="table table-bordered table-hover align-middle">
              <thead class="sticky-top">
                <tr>
                  <th>Nombre</th>
                  <th>Clave</th>
                  <th class="text-center">Estado</th>
                  <th class="text-center">Acciones</th>
                </tr>
              </thead>
              <tbody>

              <?php if (empty($escuelas)): ?>
                <tr>
                  <td colspan="4" class="text-center text-muted">
                    No hay escuelas registradas
                  </td>
                </tr>
              <?php endif; ?>
              
              <?php foreach ($escuelas as $esc): ?>
                <tr>
                  <td><?= htmlspecialchars($esc["nombre"]) ?></td>
                  <td><?= htmlspecialchars($esc["clave"]) ?></td>
              
                  <td class="text-center">
                    <?php if ($esc["activo"]): ?>
                      <span class="badge badge-activo">Activa</span>
                    <?php else: ?>
                      <span class="badge badge-inactivo">Inactiva</span>
                    <?php endif; ?>
                  </td>
                    
                  <td class="text-center">
                    
                    <!-- ACTIVAR / DESACTIVAR -->
                    <form action="toggle_escuela.php" method="post" class="d-inline">
                      <input type="hidden" name="id" value="<?= $esc["id"] ?>">
                      <input type="hidden" name="estado" value="<?= $esc["activo"] ? 0 : 1 ?>">
                      <button class="btn btn-sm <?= $esc["activo"] ? "btn-warning" : "btn-success" ?>">
                        <?= $esc["activo"] ? "Desactivar" : "Activar" ?>
                      </button>
                    </form>
                      <!-- EDITAR -->
                    <button
                      class="btn btn-sm btn-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#modalEditarEscuela"
                      data-id="<?= $esc["id"] ?>"
                      data-nombre="<?= htmlspecialchars($esc["nombre"], ENT_QUOTES, 'UTF-8') ?>"
                      data-clave="<?= htmlspecialchars($esc["clave"], ENT_QUOTES, 'UTF-8') ?>"
                      data-direccion="<?= htmlspecialchars($esc["direccion"], ENT_QUOTES, 'UTF-8') ?>"
                    >
                      Editar
                    </button>
                    
                    <!-- ELIMINAR -->
                    <form
                      action="eliminar_escuela.php"
                      method="post"
                      class="d-inline"
                      onsubmit="return confirm('¿Eliminar esta escuela?');"
                    >
                      <input type="hidden" name="id" value="<?= $esc["id"] ?>">
                      <button class="btn btn-sm btn-danger">
                        Eliminar
                      </button>
                    </form>
                    
                  </td>
                </tr>
              <?php endforeach; ?>
                    
              </tbody>
            </table>
          </div>

<hr class="mb-4">

        
        <h5 class="card-title">Especialidades</h5>
        <p class="card-text">
          Define si el sistema debe solicitar la especialidad del alumno
          durante la aplicación del test.
        </p>
    
        <form action="guardar_configuracion.php" method="post">
          <div class="form-check form-switch mb-3">
            <input
              class="form-check-input"
              type="checkbox"
              id="usarEspecialidades"
              name="usar_especialidades"
              value="1"
              <?= $usarEspecialidades ? "checked" : "" ?>
            >
            <label class="form-check-label" for="usarEspecialidades">
              Solicitar especialidad
            </label>
          </div>
    
          <button type="submit" class="btn btn-primary">
            Guardar cambios
          </button>
        </form>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-3">      
        <button
          class="btn btn-activar"
          data-bs-toggle="modal"
          data-bs-target="#modalAgregarEspecialidad"
        >
          ➕ Agregar especialidad
        </button>
    </div>
    <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
      <table class="table table-bordered table-hover align-middle">
        <thead class="sticky-top">
          <tr>
            <th>Especialidad</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>

          <?php if (empty($especialidades)): ?>
            <tr>
              <td colspan="3" class="text-center text-muted">
                No hay especialidades registradas
              </td>
            </tr>
          <?php endif; ?>

          <?php foreach ($especialidades as $esp): ?>
            <tr>
              <td><?= htmlspecialchars($esp["nombre"]) ?></td>

              <td class="text-center">
                <?php if ($esp["activa"]): ?>
                  <span class="badge badge-activo">Activa</span>
                <?php else: ?>
                  <span class="badge badge-inactivo">Inactiva</span>
                <?php endif; ?>
              </td>

              <td class="text-center">
                <!-- ACTIVAR / DESACTIVAR -->
                <form action="toggle_especialidad.php" method="post" class="d-inline">
                  <input type="hidden" name="id" value="<?= $esp["id"] ?>">
                  <input type="hidden" name="estado" value="<?= $esp["activa"] ? 0 : 1 ?>">

                  <button
                    class="btn btn-sm <?= $esp["activa"] ? "btn-warning" : "btn-success" ?>"
                    type="submit"
                  >
                    <?= $esp["activa"] ? "Desactivar" : "Activar" ?>
                  </button>
                </form>
                  <!-- EDITAR -->
                <button
                  class="btn btn-sm btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalEditarEspecialidad"
                  data-id="<?= $esp["id"] ?>"
                  data-nombre="<?= htmlspecialchars($esp["nombre"], ENT_QUOTES, 'UTF-8') ?>"
                >
                  Editar
                </button>
                <!-- ELIMINAR -->
                <form
                  action="eliminar_especialidad.php"
                  method="post"
                  class="d-inline"
                  onsubmit="return confirm('¿Eliminar esta especialidad?');"
                >
                  <input type="hidden" name="id" value="<?= $esp["id"] ?>">
                  <button class="btn btn-sm btn-danger">
                    Eliminar
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>

        </tbody>
      </table>
    </div>
    <hr class="mb-4">

<h2 class="mb-4 card-test-e">Especialidades por escuela</h2>
<p class="text-muted mb-0 card-test-e">
  Selecciona una escuela y asigna sus especialidades.
</p>

<div class="card shadow-sm mb-4">
  <div class="card-body">

    <!-- SELECT DE ESCUELA -->
    <div class="mb-3">
      <label class="form-label fw-bold">Escuela</label>
      <select id="escuelaSelect" class="form-select">
        <option value="">-- Selecciona una escuela --</option>
        <?php while ($esc = $escuelasActivas->fetch_assoc()): ?>
          <option value="<?= $esc["id"] ?>">
            <?= htmlspecialchars($esc["nombre"]) ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <!-- FORMULARIO -->
    <form method="POST" action="guardar_escuela_especialidad.php" id="formEspecialidades" style="display:none;">
      <input type="hidden" name="escuela_id" id="escuelaId">

      <div class="row" id="listaEspecialidades">
        <?php
        $especialidadesActivas->data_seek(0);
        while ($esp = $especialidadesActivas->fetch_assoc()):
        ?>
          <div class="col-md-4">
            <label class="form-check-label">
              <input
                class="form-check-input me-2 especialidad-check"
                type="checkbox"
                name="especialidades[]"
                value="<?= $esp["id"] ?>"
              >
              <?= htmlspecialchars($esp["nombre"]) ?>
            </label>
          </div>
        <?php endwhile; ?>
      </div>

      <button class="btn btn-primary mt-3">
        Guardar especialidades
      </button>
    </form>

  </div>
</div>



    <h2 class="mb-4 card-test-e">Cuestionarios</h2>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="text-muted mb-0 card-test-e">
        Administra los instrumentos de evaluación del sistema.
      </p>

      <button
        class="btn btn-activar"
        data-bs-toggle="modal"
        data-bs-target="#modalAgregarInstrumento"
      >
        ➕ Nuevo cuestionario
      </button>
    </div>

    <div class="table-responsive" style="max-height: 300px; overflow-y:auto;">
      <table class="table table-bordered table-hover align-middle">
        <thead class="sticky-top">
          <tr>
            <th>Nombre</th>
            <th>Tipo de respuestas</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>

        <?php if (empty($instrumentos)): ?>
          <tr>
            <td colspan="4" class="text-center text-muted">
              No hay cuestionarios registrados
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($instrumentos as $inst): ?>
          <tr>
            <td>
              <strong><?= htmlspecialchars($inst["nombre"]) ?></strong><br>
              <small class="text-muted">
                <?= htmlspecialchars($inst["descripcion"]) ?>
              </small>
            </td>

            <td>
              <?php
              if ($inst["tipo_escala"] === "escala") {
                echo "Escala ({$inst['escala_min']} – {$inst['escala_max']})";
              } elseif ($inst["tipo_escala"] === "si_no") {
                echo "Sí / No";
              } else {
                echo "Sin definir";
              }
              ?>
            </td>

            <td class="text-center">
              <?php if ($inst["activo"]): ?>
                <span class="badge badge-activo">Activa</span>
              <?php else: ?>
                <span class="badge badge-inactivo">Inactiva</span>
              <?php endif; ?>
            </td>

            <td class="text-center">

              <!-- ACTIVAR / DESACTIVAR -->
              <form action="toggle_instrumento.php" method="post" class="d-inline">
                <input type="hidden" name="id" value="<?= $inst["id"] ?>">
                <input type="hidden" name="estado" value="<?= $inst["activo"] ? 0 : 1 ?>">
                <button class="btn btn-sm <?= $inst["activo"] ? "btn-warning" : "btn-success" ?>">
                  <?= $inst["activo"] ? "Desactivar" : "Activar" ?>
                </button>
              </form>

              <!-- ELIMINAR -->
              <form
                action="eliminar_instrumento.php"
                method="post"
                class="d-inline"
                onsubmit="return confirm('¿Eliminar este cuestionario?');"
              >
                <input type="hidden" name="id" value="<?= $inst["id"] ?>">
                <button class="btn btn-sm btn-danger">
                  Eliminar
                </button>
              </form>
              <a
                href="editar_instrumento.php?id=<?= $inst["id"] ?>"
                class="btn btn-sm btn-primary"
              >
                Editar
              </a>


            </td>
          </tr>
        <?php endforeach; ?>

        </tbody>
      </table>
    </div>




</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<div class="modal fade" id="modalAgregarEspecialidad" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="agregar_especialidad.php" method="post">
        <div class="modal-header">
          <h5 class="modal-title">Agregar especialidad</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <label class="form-label">Nombre de la especialidad</label>
          <input
            type="text"
            name="nombre"
            class="form-control"
            required
          >
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-institucional">
            Guardar
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>
      </form>

    </div>
  </div>
</div>
<div class="modal fade" id="modalAgregarInstrumento" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="agregar_instrumento.php" method="post">

        <div class="modal-header">
          <h5 class="modal-title">Nuevo cuestionario</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required>

          <label class="form-label mt-3">Descripción</label>
          <textarea name="descripcion" class="form-control" rows="2"></textarea>

          <label class="form-label mt-3">Tipo de escala</label>

          <div class="opciones-test" id="tipoEscala">

            <label class="opcion-test">
              <input type="radio" name="tipo_escala" value="si_no" required>
              <span class="punto"></span>
              <span class="texto">Sí / No</span>
            </label>

            <label class="opcion-test">
              <input type="radio" name="tipo_escala" value="escala" required>
              <span class="punto"></span>
              <span class="texto">Escala numérica</span>
            </label>

          </div>

          <div id="configEscala" style="display:none;">
            <label class="form-label mt-3">Valor mínimo</label>
            <input type="number" name="escala_min" id="escalaMin" class="form-control">
            
            <label class="form-label mt-2">Valor máximo</label>
            <input type="number" name="escala_max" id="escalaMax" class="form-control">
          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-institucional">
            Guardar
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>

      </form>

    </div>
  </div>
</div>

<script>
const radios = document.querySelectorAll('input[name="tipo_escala"]');
const configEscala = document.getElementById("configEscala");
const escalaMin = document.getElementById("escalaMin");
const escalaMax = document.getElementById("escalaMax");

radios.forEach(radio => {
  radio.addEventListener("change", function () {
    if (this.value === "escala") {
      configEscala.style.display = "block";
      escalaMin.required = true;
      escalaMax.required = true;
    } else {
      configEscala.style.display = "none";
      escalaMin.required = false;
      escalaMax.required = false;
      escalaMin.value = "";
      escalaMax.value = "";
    }
  });
});
</script>

<script>
const escuelaSelect = document.getElementById("escuelaSelect");
const form = document.getElementById("formEspecialidades");
const escuelaIdInput = document.getElementById("escuelaId");

escuelaSelect.addEventListener("change", () => {
  const escuelaId = escuelaSelect.value;

  form.style.display = escuelaId ? "block" : "none";
  escuelaIdInput.value = escuelaId;

  document.querySelectorAll(".especialidad-check").forEach(chk => {
    chk.checked = false;
  });

  if (!escuelaId) return;

  fetch("obtener_especialidades_escuela.php?escuela_id=" + escuelaId)
    .then(res => res.json())
    .then(data => {
      data.forEach(id => {
        const chk = document.querySelector(
          `.especialidad-check[value="${id}"]`
        );
        if (chk) chk.checked = true;
      });
    });
});
</script>
<script>
  const mensaje = document.getElementById("mensajeSistema");

  if (mensaje) {
    // Tiempo visible (en ms)
    const tiempoVisible = 3500;

    setTimeout(() => {
      mensaje.classList.add("ocultar");

      // Eliminar del DOM después de la animación
      setTimeout(() => {
        mensaje.remove();
      }, 500);

    }, tiempoVisible);
  }
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {

  const modalEditar = document.getElementById("modalEditarEspecialidad");

  if (!modalEditar) return;

  modalEditar.addEventListener("show.bs.modal", function (event) {
    const button = event.relatedTarget;

    if (!button) return;

    const id = button.getAttribute("data-id");
    const nombre = button.getAttribute("data-nombre");

    document.getElementById("editarEspecialidadId").value = id;
    document.getElementById("editarEspecialidadNombre").value = nombre;
  });

});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {

  const modalEditarEscuela = document.getElementById("modalEditarEscuela");
  if (!modalEditarEscuela) return;

  modalEditarEscuela.addEventListener("show.bs.modal", function (event) {
    const button = event.relatedTarget;
    if (!button) return;

    document.getElementById("editarEscuelaId").value = button.getAttribute("data-id");
    document.getElementById("editarEscuelaNombre").value = button.getAttribute("data-nombre");
    document.getElementById("editarEscuelaClave").value = button.getAttribute("data-clave");
    document.getElementById("editarEscuelaDireccion").value = button.getAttribute("data-direccion");
  });

});
</script>




<div class="modal fade" id="modalAgregarEscuela" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="agregar_escuela.php" method="post">
        <div class="modal-header">
          <h5 class="modal-title">Agregar escuela</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required>

          <label class="form-label mt-2">Clave</label>
          <input type="text" name="clave" class="form-control">

          <label class="form-label mt-2">Dirección</label>
          <textarea name="direccion" class="form-control" rows="2"></textarea>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-institucional">
            Guardar
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>
      </form>

    </div>
  </div>
</div>

<div class="modal fade" id="modalEditarEspecialidad" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="editar_especialidad.php" method="post">

        <div class="modal-header">
          <h5 class="modal-title">Editar especialidad</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <input type="hidden" name="id" id="editarEspecialidadId">

          <label class="form-label">Nombre de la especialidad</label>
          <input
            type="text"
            name="nombre"
            id="editarEspecialidadNombre"
            class="form-control"
            required
          >

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-institucional">
            Guardar cambios
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>

      </form>

    </div>
  </div>
</div>
<div class="modal fade" id="modalEditarEscuela" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <form action="editar_escuela.php" method="post">

        <div class="modal-header">
          <h5 class="modal-title">Editar escuela</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <input type="hidden" name="id" id="editarEscuelaId">

          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" id="editarEscuelaNombre" class="form-control" required>

          <label class="form-label mt-2">Clave</label>
          <input type="text" name="clave" id="editarEscuelaClave" class="form-control">

          <label class="form-label mt-2">Dirección</label>
          <textarea name="direccion" id="editarEscuelaDireccion" class="form-control" rows="2"></textarea>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-institucional">
            Guardar cambios
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Cancelar
          </button>
        </div>

      </form>

    </div>
  </div>
</div>


<footer class="footer-sistema mt-auto footer-margin">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>

</body>
</html>
