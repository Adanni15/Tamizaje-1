<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: iniciarsesion.php");
  exit;
}
?>
<?php
require_once "../config/conexion.php";

/* Roles */
$roles = [];
$resultRoles = $conexion->query("SELECT id, nombre FROM roles");
while ($r = $resultRoles->fetch_assoc()) {
  $roles[] = $r;
}
?>

<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Agregar usuario</title>
    <link rel="stylesheet" href="../css/style3.css">
  </head>
  <body>

    <!-- Botón volver -->
    <a href="usuarios.php" class="btn-volver">← Volver</a>

    <div id="body-1">
      <div class="contenedor">
        <a class="logo">
          <img src="../img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>
      </div>
    </div>

    <div id="body">
      <div id="content">
        <h1>Agregar usuario</h1>

        <form action="guardar_usuario.php" method="post">

          <!-- Nombre completo -->
          <div class="form-group">
            <label for="nombre">Nombre completo:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono usuario -->
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M8 7a4 4 0 1 0 8 0"/>
                  <path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/>
                </svg>
              </span>
              <input type="text" id="nombre" name="nombre" required>
            </div>
          </div>

          <!-- Correo -->
          <div class="form-group">
            <label for="correo">Correo electrónico:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono correo -->
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="4"/>
                  <path d="M16 12v1.5a2.5 2.5 0 0 0 5 0"/>
                </svg>
              </span>
              <input type="email" id="correo" name="correo" required>
            </div>
          </div>

          <!-- Contraseña -->
          <div class="form-group">
            <label for="password">Contraseña:</label>
            <div class="input-group">
              <span class="input-group-text">
                <!-- Ícono candado -->
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="5" y="11" width="14" height="10" rx="2"/>
                  <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                </svg>
              </span>
              <input type="password" id="password" name="password" required>
            </div>
          </div>
          <!-- Sexo -->
          <div class="form-group">
            <label for="sexo">Sexo:</label>
            <select id="sexo" name="sexo" required>
              <option value="">Seleccione una opción</option>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <!-- Rol -->
          <div class="form-group">
            <label for="rol">Rol:</label>
            <select id="rol" name="rol_id" required>
              <option value="">Seleccione un rol</option>
              <?php foreach ($roles as $rol): ?>
                <option value="<?= $rol["id"] ?>">
                  <?= htmlspecialchars($rol["nombre"]) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit">Guardar usuario</button>
        </form>
      </div>
    </div>

  </body>
</html>
