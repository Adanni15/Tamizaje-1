<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. Validación de sesión
================================ */
if (
    !isset($_SESSION["usuario_id"]) ||
    $_SESSION["usuario_rol"] !== "administrador"
) {
    header("Location: ../iniciarsesion.php");
    exit;
}

/* ===============================
   2. Validación de datos
================================ */
$areaId = (int)($_POST["area_id"] ?? 0);
$texto  = trim($_POST["texto"] ?? "");

$redFlag     = isset($_POST["red_flag"]) ? 1 : 0;
$esInvertida = isset($_POST["invertida"]) ? 1 : 0;

if ($areaId <= 0 || $texto === "") {
    die("Datos inválidos");
}

/* ===============================
   3. Obtener siguiente número
================================ */
$stmt = $conexion->prepare("
    SELECT COALESCE(MAX(numero), 0) + 1 AS siguiente
    FROM preguntas
    WHERE area_id = ?
");

$stmt->bind_param("i", $areaId);
$stmt->execute();
$siguiente = $stmt->get_result()->fetch_assoc()["siguiente"];
$stmt->close();

/* ===============================
   4. Insertar pregunta
================================ */
$stmt = $conexion->prepare("
    INSERT INTO preguntas (
        area_id,
        numero,
        texto,
        es_invertida,
        red_flag
    ) VALUES (?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "iisii",
    $areaId,
    $siguiente,
    $texto,
    $esInvertida,
    $redFlag
);

$stmt->execute();
$stmt->close();

/* ===============================
   5. Redirección
================================ */
header("Location: editar_area.php?id=" . $areaId);
exit;
