<?php
session_start();
require_once "../config/conexion.php";

/* ===============================
   1. VALIDACIÓN DE SESIÓN
================================ */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

/* ===============================
   2. RECIBIR DATOS
================================ */
$areaId = (int)($_POST["area_id"] ?? 0);
$texto  = trim($_POST["texto"] ?? "");

$redFlag     = isset($_POST["red_flag"]) ? 1 : 0;
$esInvertida = isset($_POST["invertida"]) ? 1 : 0;

/* ===============================
   3. VALIDACIONES BÁSICAS
================================ */
if ($areaId <= 0) {
  $_SESSION["msg"] = "Área inválida";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

if ($texto === "") {
  $_SESSION["msg"] = "El texto de la pregunta es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: editar_area.php?id=$areaId");
  exit;
}

/* ===============================
   4. VALIDAR QUE EL ÁREA EXISTA
================================ */
$stmtArea = $conexion->prepare("
  SELECT id
  FROM areas
  WHERE id = ?
");
$stmtArea->bind_param("i", $areaId);
$stmtArea->execute();
$stmtArea->store_result();

if ($stmtArea->num_rows === 0) {
  $_SESSION["msg"] = "El área no existe";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$stmtArea->close();

/* ===============================
   5. EVITAR PREGUNTAS DUPLICADAS
   (MISMO ÁREA, MISMO TEXTO)
================================ */
$stmtDup = $conexion->prepare("
  SELECT id
  FROM preguntas
  WHERE area_id = ?
    AND LOWER(texto) = LOWER(?)
  LIMIT 1
");
$stmtDup->bind_param("is", $areaId, $texto);
$stmtDup->execute();
$stmtDup->store_result();

if ($stmtDup->num_rows > 0) {
  $_SESSION["msg"] = "Ya existe una pregunta con ese texto en esta área";
  $_SESSION["msg_type"] = "error";
  header("Location: ver_preguntas.php?id=$areaId");
  exit;
}
$stmtDup->close();

/* ===============================
   6. OBTENER SIGUIENTE NÚMERO
================================ */
$stmtNum = $conexion->prepare("
  SELECT COALESCE(MAX(numero), 0) + 1 AS siguiente
  FROM preguntas
  WHERE area_id = ?
");
$stmtNum->bind_param("i", $areaId);
$stmtNum->execute();
$siguiente = $stmtNum->get_result()->fetch_assoc()["siguiente"];
$stmtNum->close();

/* ===============================
   7. INSERTAR PREGUNTA
================================ */
$stmt = $conexion->prepare("
  INSERT INTO preguntas (
    area_id,
    numero,
    texto,
    es_invertida,
    red_flag
  ) VALUES (?, ?, ?, ?, ?)
");

$stmt->bind_param(
  "iisii",
  $areaId,
  $siguiente,
  $texto,
  $esInvertida,
  $redFlag
);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al guardar la pregunta";
  $_SESSION["msg_type"] = "error";
  header("Location: ver_preguntas.php?id=$areaId");
  exit;
}

$stmt->close();

/* ===============================
   8. MENSAJE ÉXITO + REDIRECCIÓN
================================ */
$_SESSION["msg"] = "Pregunta agregada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: ver_preguntas.php?id=$areaId");
exit;
