<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

/* =======================
   LIMPIAR DATOS
======================= */
$nombre    = trim($_POST["nombre"] ?? "");
$clave     = trim($_POST["clave"] ?? "");
$direccion = trim($_POST["direccion"] ?? "");

/* =======================
   VALIDACIONES
======================= */
if ($nombre === "") {
  $_SESSION["msg"] = "El nombre de la escuela es obligatorio";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

/* =======================
   VALIDAR DUPLICADOS
======================= */

/* Por nombre */
$checkNombre = $conexion->prepare("
  SELECT id
  FROM escuelas
  WHERE LOWER(nombre) = LOWER(?)
  LIMIT 1
");
$checkNombre->bind_param("s", $nombre);
$checkNombre->execute();
$checkNombre->store_result();

if ($checkNombre->num_rows > 0) {
  $_SESSION["msg"] = "Ya existe una escuela con ese nombre";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}
$checkNombre->close();

/* Por clave */
if ($clave !== "") {
  $checkClave = $conexion->prepare("
    SELECT id
    FROM escuelas
    WHERE clave = ?
    LIMIT 1
  ");
  $checkClave->bind_param("s", $clave);
  $checkClave->execute();
  $checkClave->store_result();

  if ($checkClave->num_rows > 0) {
    $_SESSION["msg"] = "La clave de la escuela ya existe";
    $_SESSION["msg_type"] = "error";
    header("Location: configuracion.php");
    exit;
  }
  $checkClave->close();
}

/* =======================
   INSERTAR ESCUELA
======================= */
$stmt = $conexion->prepare("
  INSERT INTO escuelas (nombre, clave, direccion, activo)
  VALUES (?, ?, ?, 1)
");

$stmt->bind_param("sss", $nombre, $clave, $direccion);

if (!$stmt->execute()) {
  $_SESSION["msg"] = "Error al agregar la escuela";
  $_SESSION["msg_type"] = "error";
  header("Location: configuracion.php");
  exit;
}

$stmt->close();

/* =======================
   ÉXITO
======================= */
$_SESSION["msg"] = "Escuela agregada correctamente";
$_SESSION["msg_type"] = "success";

header("Location: configuracion.php");
exit;
