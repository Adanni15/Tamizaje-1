<?php
session_start();

if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = intval($_POST["id"] ?? 0);

if ($id <= 0) {
  die("ID inválido");
}

/* 🔍 Verificar relación con escuelas */
$check = $conexion->prepare("
  SELECT COUNT(*) AS total
  FROM escuela_especialidad
  WHERE especialidad_id = ?
");
$check->bind_param("i", $id);
$check->execute();
$result = $check->get_result()->fetch_assoc();
$check->close();

if ($result["total"] > 0) {
  die("No se puede eliminar la especialidad porque está asignada a una escuela.");
}

/* 🗑️ Eliminar especialidad */
$stmt = $conexion->prepare("
  DELETE FROM especialidades
  WHERE id = ?
");

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
  die("Error al eliminar especialidad: " . $stmt->error);
}

$stmt->close();

header("Location: configuracion.php");
exit;
