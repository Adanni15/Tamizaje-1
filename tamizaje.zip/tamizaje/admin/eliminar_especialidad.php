<?php
session_start();

if ($_SESSION["usuario_rol"] !== "administrador") {
  header("Location: ../iniciarsesion.php");
  exit;
}

require_once "../config/conexion.php";

$id = (int)$_POST["id"];

$stmt = $conexion->prepare("
  DELETE FROM especialidades
  WHERE id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: admin_cuenta.php");
exit;
