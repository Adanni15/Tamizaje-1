<?php
session_start();
require_once "../config/conexion.php";

$token    = $_POST["token"] ?? "";
$password = $_POST["password"] ?? "";

/* Validaciones básicas */
if (strlen($password) < 8) {
  $_SESSION["mensaje_error"] = "La contraseña debe tener al menos 8 caracteres.";
  header("Location: recuperar_password.php");
  exit;
}

/* Buscar token válido */
$stmt = $conexion->prepare("
  SELECT id, password
  FROM usuarios
  WHERE reset_token = ?
  AND reset_expira > NOW()
  LIMIT 1
");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  $_SESSION["mensaje_error"] = "El enlace es inválido o ya expiró.";
  header("Location: recuperar_password.php");
  exit;
}

$usuario = $result->fetch_assoc();

/* Evitar reutilizar la misma contraseña */
if (password_verify($password, $usuario["password"])) {
  $_SESSION["mensaje_error"] = "La nueva contraseña debe ser diferente a la anterior.";
  header("Location: recuperar_password.php");
  exit;
}

/* Hashear nueva contraseña */
$hash = password_hash($password, PASSWORD_DEFAULT);

/* Actualizar contraseña + invalidar sesiones */
$stmt = $conexion->prepare("
  UPDATE usuarios
  SET 
    password = ?,
    reset_token = NULL,
    reset_expira = NULL,
    session_version = session_version + 1
  WHERE id = ?
");
$stmt->bind_param("si", $hash, $usuario["id"]);
$stmt->execute();

/* Limpiar sesión actual (si existiera) */
session_unset();
session_destroy();

/* Nuevo mensaje y redirección */
session_start();
$_SESSION["login_error"] = "Tu contraseña fue restablecida. Inicia sesión nuevamente.";

header("Location: ../iniciarsesion.php");
exit;
