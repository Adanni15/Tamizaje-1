<?php
require_once "../config/conexion.php";

$escuelaId = (int)($_GET["escuela_id"] ?? 0);

$ids = [];

$res = $conexion->query("
  SELECT especialidad_id
  FROM escuela_especialidad
  WHERE escuela_id = $escuelaId
    AND activo = 1
");

while ($row = $res->fetch_assoc()) {
  $ids[] = $row["especialidad_id"];
}

echo json_encode($ids);
