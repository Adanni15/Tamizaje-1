<?php
session_start();
require_once "../config/conexion.php";

/* VALIDACIÓN DE SESIÓN */
if (
  !isset($_SESSION["usuario_id"]) ||
  $_SESSION["usuario_rol"] !== "administrador"
) {
  header("Location: ../iniciarsesion.php");
  exit;
}

$areaId = (int)($_POST["area_id"] ?? 0);
$instrumentoId = (int)($_POST["instrumento_id"] ?? 0);

if ($areaId <= 0 || $instrumentoId <= 0) {
  die("Datos inválidos");
}

/* ELIMINAR PREGUNTAS DEL ÁREA */
$stmt = $conexion->prepare("
  DELETE FROM preguntas
  WHERE area_id = ?
");
$stmt->bind_param("i", $areaId);
$stmt->execute();
$stmt->close();

/* ELIMINAR ÁREA */
$stmt = $conexion->prepare("
  DELETE FROM areas
  WHERE id = ?
");
$stmt->bind_param("i", $areaId);
$stmt->execute();
$stmt->close();

/* REGRESAR A EDITAR INSTRUMENTO */
header("Location: editar_instrumento.php?id=" . $instrumentoId);
exit;
