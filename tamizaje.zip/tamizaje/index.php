<?php
session_start();
if (isset($_SESSION["usuario_id"]) && !isset($_SESSION["usuario_rol"])) {
    session_destroy();
    header("Location: iniciarsesion.php");
    exit;
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

require_once "config/conexion.php";

$config = [];

$resultConfig = $conexion->query("
  SELECT clave, valor
  FROM configuracion_sistema
");

while ($row = $resultConfig->fetch_assoc()) {
  $config[$row["clave"]] = $row["valor"];
}

$usarEspecialidades = (int)($config["usar_especialidades"] ?? 0);


$logueado = isset($_SESSION["usuario_id"]);
$rol = $_SESSION["usuario_rol"] ?? null;

?>


<?php
require_once "config/conexion.php";

$instrumentos = [];
$result = $conexion->query("
  SELECT id, nombre, descripcion
  FROM instrumentos
  WHERE activo = 1
");

while ($row = $result->fetch_assoc()) {
  $instrumentos[] = $row;
}

$especialidades = [];

if ($usarEspecialidades === 1) {
  $resultEsp = $conexion->query("
    SELECT id, nombre
    FROM especialidades
    WHERE activa = 1
    ORDER BY nombre
  ");

  while ($row = $resultEsp->fetch_assoc()) {
    $especialidades[] = $row;
  }
}

$escuelas = [];

$resultEsc = $conexion->query("
  SELECT id, nombre
  FROM escuelas
  WHERE activo = 1
  ORDER BY nombre
");

while ($row = $resultEsc->fetch_assoc()) {
  $escuelas[] = $row;
}

?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de Tamizaje POSIT</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
</head>

<body>
<div class="page-content">
  <header>
    <div class="content">
      <div class="menu container">
        <a href="index.php" class="logo">
          <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
        </a>

        <!-- Menú responsive -->
        <input type="checkbox" id="menu" />
        <div class="menu-btn">
          <label for="menu" aria-label="Abrir menú">
            <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
              <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                <path class="line top" d="M3 7h18"></path>
                <path class="line mid" d="M3 12h18"></path>
                <path class="line bot" d="M3 17h18"></path>
              </g>
            </svg>
          </label>
        </div>

        <!-- Navegación -->
        <nav class="navbar">
          <div class="main-menu">
            <ul>
              <li><a href="index.php">Test</a></li>
              <li><a href="acercade.php">Acerca de</a></li>

              <?php if ($logueado): ?>
                <li><a href="resultados.php">Resultados</a></li>
              <?php endif; ?>
            </ul>
          </div>
          <ul class="logout-menu">
            <?php if ($logueado && $rol === "administrador"): ?>
                <a href="admin/admin_cuenta.php" class="usuario-link">
                  <span class="usuario-badge">
                    <span class="usuario-icono">👤</span>
                    <span class="usuario-texto">
                      <span class="usuario-nombre">
                        <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                      </span>
                      <span class="usuario-rol">
                        <?= strtoupper($_SESSION["usuario_rol"]) ?>
                      </span>
                    </span>
                  </span>
                </a>
            <?php elseif ($logueado && $rol === "aplicador"):?>
                  <span class="usuario-badge">
                    <span class="usuario-icono">👤</span>
                    <span class="usuario-texto">
                      <span class="usuario-nombre">
                        <?= htmlspecialchars($_SESSION["usuario_nombre"]) ?>
                      </span>
                      <span class="usuario-rol">
                        <?= strtoupper($_SESSION["usuario_rol"]) ?>
                      </span>
                    </span>
                  </span>
            <?php endif; ?>
            
            <?php if ($logueado): ?>
              <li><a href="config/logout.php" class="logout">Cerrar sesión</a></li>
            <?php else: ?>
              <li><a href="iniciarsesion.php" class="logout">Iniciar sesión</a></li>
            <?php endif; ?>
          </ul>
        </nav>
      </div>
    </div>
  </header>

  <main class="container my-4">
    <!-- PASO 0: SELECCIÓN DE TEST -->
    <div id="seleccionTest" class="selector-test">

      <h2 class="titulo-selector card-test-e" >Selecciona el test a aplicar</h2>

      <div class="lista-tests">
        <?php foreach ($instrumentos as $test): ?>
          <div class="card-test">
            <h3><?= htmlspecialchars($test["nombre"]) ?></h3>
            <p><?= htmlspecialchars($test["descripcion"]) ?></p>

            <button
              class="btn-seleccionar seleccionar-test"
              data-id="<?= $test["id"] ?>"
              data-nombre="<?= htmlspecialchars($test["nombre"]) ?>">
              Seleccionar
            </button>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- CONFIRMACIÓN DE TEST -->
    <div id="confirmacionTest" class="confirmacion-test" style="display:none;">
      <div class="confirmacion-card">
        <h3>Confirmar selección</h3>
        <p>
          ¿Deseas continuar con el test
          <strong id="nombreTest"></strong>?
        </p>

        <div class="acciones-confirmacion">
          <button id="cancelarTest" class="btn-cancelar">Cancelar</button>
          <button id="confirmarTest" class="btn-cancelar">Aceptar</button>
        </div>
      </div>
    </div>


    <!-- Paso 1: Formulario sociodemográfico -->
    <div id="formularioDatos" style="display:none;">
      <h2 class="mb-3 text-center">Ingresa tus datos</h2>
      <form id="datosForm" class="p-4 border rounded bg-light shadow-sm">
        <div class="mb-3">
          <label for="escuela_id" class="form-label">Escuela:</label>
          <select id="escuela_id" name="escuela_id" class="form-select" required>
            <option value="">Seleccione su escuela...</option>

            <?php foreach ($escuelas as $esc): ?>
              <option value="<?= $esc["id"] ?>">
                <?= htmlspecialchars($esc["nombre"]) ?>
              </option>
            <?php endforeach; ?>
            
          </select>
        </div>

        <div class="mb-3">
          <label for="nombre" class="form-label">Nombre completo:</label>
          <input type="text" class="form-control" id="nombre" name="nombre" required>
        </div>

        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="edad" class="form-label">Edad:</label>
            <input type="number" class="form-control" id="edad" name="edad" required min="12" max="18">
          </div>

          <div class="col-md-6 mb-3">
            <label for="sexo" class="form-label">Sexo:</label>
            <select id="sexo" name="sexo" class="form-select" required>
              <option value="">Seleccione...</option>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="col-md-4 mb-3">
            <label for="turno" class="form-label">Turno:</label>
            <select id="turno" name="turno" class="form-select" required>
              <option value="">Seleccione...</option>
              <option value="Matutino">Matutino</option>
              <option value="Vespertino">Vespertino</option>
            </select>
          </div>

          <div class="col-md-4 mb-3">
            <label for="grado" class="form-label">Semestre:</label>
            <select id="grado" name="grado" class="form-select" required>
              <option value="">Seleccione...</option>
              <option value="1">1ro</option>
              <option value="2">2do</option>
              <option value="3">3ro</option>
              <option value="4">4to</option>
              <option value="5">5to</option>
              <option value="6">6to</option>
            </select>
          </div>

          <div class="col-md-4 mb-3">
            <label for="grupo" class="form-label">Grupo:</label>
            <input type="text" class="form-control" id="grupo" name="grupo" required maxlength="1" pattern="[A-Za-z]" title="Solo se permiten letras" style="text-transform: uppercase;">
          </div>
        </div>

        <?php if ($usarEspecialidades === 1): ?>
        <div class="mb-3">
          <label for="especialidad" class="form-label">Especialidad:</label>
          <select
            id="especialidad"
            name="especialidad"
            class="form-select"
            disabled
            required
          >
            <option value="">Seleccione primero su escuela...</option>
          </select>
        </div>
        <?php endif; ?>


        <div class="text-center">
          <button type="submit" class="btn btn-primary px-4">Comenzar Test</button>
        </div>
      </form>
    </div>

    <!-- Paso 1.5: Mensaje de advertencia -->
    <div id="mensajeAdvertencia" class="text-center" style="display: none;">
      <div class="alert alert-warning p-4 mt-4 shadow-sm">
        <h4><strong>Instrucciones: </strong></h4>
        <p class="mb-3">Trata de contestar las preguntas con franqueza. Esto no es un examen, no hay respuestas correctas e incorrectas, pero por favor trabaja con cuidado.
          Todas las respuestas son confidenciales. Contesta todas las preguntas.
          Si alguna de ellas no aplica exactamente para ti, escoge la respuesta que más se acerque a la verdad.
        </p>
        <button id="continuarBtn" class="btn btn-success px-4">Continuar</button>
      </div>
    </div>

    <!-- Paso 2: Test POSIT -->
    <div id="testContainer" style="display:none;">
      <div class="question">
        <div id="textoPregunta"></div>
      </div>

      <div id="opcionesRespuesta" class="options"></div>

      <div class="text-center mt-4">
    <button class="btn btn-success px-5" onclick="procesarRespuesta()">
      Siguiente
    </button>
      </div>
    </div>

  </main>
  <script>
    const grupoInput = document.getElementById("grupo");
              
    grupoInput.addEventListener("input", function () {
      // Elimina todo lo que no sea letra
      this.value = this.value
        .replace(/[^A-Za-z]/g, "")
        .toUpperCase();
    });
  </script>



  <script>
  /* =========================
     VARIABLES GLOBALES
  ========================= */
  let testSeleccionado = null;
  let datosSociodemograficos = null;
  let preguntas = [];
  let preguntaActual = 0;
  let respuestas = [];

  /* =========================
     ELEMENTOS
  ========================= */
  const seleccionTest = document.getElementById("seleccionTest");
  const confirmacionTest = document.getElementById("confirmacionTest");
  const formularioDatos = document.getElementById("formularioDatos");
  const mensajeAdvertencia = document.getElementById("mensajeAdvertencia");
  const testContainer = document.getElementById("testContainer");

  const nombreTestSpan = document.getElementById("nombreTest");
  const confirmarBtn = document.getElementById("confirmarTest");
  const cancelarBtn = document.getElementById("cancelarTest");
  const continuarBtn = document.getElementById("continuarBtn");
  const datosForm = document.getElementById("datosForm");

  /* =========================
     PASO 0: SELECCIÓN
  ========================= */
  document.querySelectorAll(".seleccionar-test").forEach(btn => {
    btn.addEventListener("click", () => {
      testSeleccionado = {
        id: btn.dataset.id,
        nombre: btn.dataset.nombre
      };

      nombreTestSpan.textContent = testSeleccionado.nombre;
      seleccionTest.style.display = "none";
      confirmacionTest.style.display = "flex";
    });
  });

  /* =========================
     CONFIRMAR / CANCELAR
  ========================= */
  confirmarBtn.addEventListener("click", () => {
    confirmacionTest.style.display = "none";
    formularioDatos.style.display = "block";
  });

  cancelarBtn.addEventListener("click", () => {
    confirmacionTest.style.display = "none";
    seleccionTest.style.display = "block";
    testSeleccionado = null;
  });

  /* =========================
     PASO 1: DATOS SOCIO
  ========================= */
  datosForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const edadValor = parseInt(edad.value, 10);

    if (edadValor < 12 || edadValor > 18) {
      alert("La edad debe estar entre 12 y 18 años");
      return;
    }
    const escuelaSeleccionada = document.getElementById("escuela_id").value;

    if (!escuelaSeleccionada) {
      alert("Debes seleccionar una escuela");
      return;
    }


    datosSociodemograficos = {
    escuela_id: parseInt(document.getElementById("escuela_id").value),
    nombre: nombre.value.trim().toUpperCase(),
    edad: edadValor,
    sexo: sexo.value,
    turno: turno.value,
    grado: grado.value,
    grupo: grupo.value.trim().toUpperCase(),
    especialidad: document.getElementById("especialidad")
      ? especialidad.value
      : null
  };



    formularioDatos.style.display = "none";
    mensajeAdvertencia.style.display = "block";
  });

  /* =========================
     PASO 1.5: ADVERTENCIA
  ========================= */
  continuarBtn.addEventListener("click", () => {
    mensajeAdvertencia.style.display = "none";
    testContainer.style.display = "block";
    cargarPreguntas();
  });

  /* =========================
     CARGAR PREGUNTAS (CON VALIDACIÓN)
  ========================= */
  function cargarPreguntas() {
    fetch(`config/obtener_preguntas.php?instrumento_id=${testSeleccionado.id}`)
      .then(res => {
        if (!res.ok) throw new Error("Error al cargar preguntas");
        return res.json();
      })
      .then(data => {
        if (!Array.isArray(data) || data.length === 0) {
          testContainer.innerHTML = `
            <div class="alert alert-danger text-center">
              Este test no tiene preguntas registradas.
            </div>
          `;
          return;
        }

        preguntas = data;
        preguntaActual = 0;
        respuestas = [];
        mostrarPregunta();
      })
      .catch(() => {
        testContainer.innerHTML = `
          <div class="alert alert-danger text-center">
            Error al cargar el cuestionario.
          </div>
        `;
      });
  }


  /* =========================
     MOSTRAR PREGUNTA (CON BOTÓN FINAL)
  ========================= */
  function mostrarPregunta() {
    const p = preguntas[preguntaActual];

    document.getElementById("textoPregunta").innerText = p.texto;

    const esUltima = preguntaActual === preguntas.length - 1;
    document.querySelector("#testContainer button").innerText =
      esUltima ? "Finalizar" : "Siguiente";

    let opcionesHTML = "";

    // 🛡️ NORMALIZACIÓN (CLAVE)
    const tipo = p.tipo_respuesta ?? "escala";
    const min = parseInt(p.escala_min ?? 1);
    const max = parseInt(p.escala_max ?? 10);

    if (tipo === "si_no") {
      opcionesHTML = `
        <div class="form-check">
          <input class="form-check-input" type="radio" name="respuesta" value="1" required>
          <label class="form-check-label">Sí</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="respuesta" value="0" required>
          <label class="form-check-label">No</label>
        </div>
      `;
    } else {
      // ESCALA POR DEFECTO (1–10)
      for (let i = min; i <= max; i++) {
        opcionesHTML += `
          <div class="form-check">
            <input class="form-check-input" type="radio" name="respuesta" value="${i}" required>
            <label class="form-check-label">${i}</label>
          </div>
        `;
      }
    }

    document.getElementById("opcionesRespuesta").innerHTML = opcionesHTML;
  }



  /* =========================
     RESPONDER
  ========================= */
  function responder(valor) {

    // 🔐 PROTECCIÓN EXTRA
    if (!preguntas[preguntaActual]) return;

    respuestas.push({
      pregunta_id: preguntas[preguntaActual].id,
      area_id: preguntas[preguntaActual].area_id,
      valor: valor
    });

    preguntaActual++;

    // ✅ SI YA NO HAY MÁS PREGUNTAS → FINALIZAR
    if (preguntaActual >= preguntas.length) {
      mostrarConfirmacionEnvio();
      return;
    }
    mostrarPregunta();
  }

  function mostrarConfirmacionEnvio() {
    testContainer.innerHTML = `
      <div class="card p-4 shadow-sm text-center">
        <h4 class="mb-3">¿Deseas enviar tus respuestas?</h4>
        <p>
          Una vez enviadas, no podrás modificar tus respuestas.
        </p>
        <div class="d-flex justify-content-center gap-3 mt-3">
          <button class="btn btn-success" onclick="enviarResultados()">
            Enviar
          </button>
          <button class="btn btn-secondary" onclick="volverSeleccionTest()">
            Cancelar
          </button>
        </div>
      </div>
    `;
  }

  /* =========================
     ENVÍO FINAL
  ========================= */
  function enviarResultados() {
    fetch("config/guardar_test.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        instrumento_id: testSeleccionado.id,
        datos: datosSociodemograficos,
        respuestas: respuestas
      })
    })
    .then(res => res.json())
    .then(data => {
      if (!data.ok) {
        throw new Error(data.error || "Error desconocido");
      }
    
      testContainer.innerHTML = `
        <div class="card p-4 shadow-sm text-center">
          <h4 class="mb-3">Test finalizado correctamente</h4>
          <p>Tus respuestas han sido guardadas correctamente.</p>
          <button class="btn btn-success" onclick="volverSeleccionTest()">
            Aceptar
          </button>
        </div>
      `;
    })

    .catch(() => {
      testContainer.innerHTML = `
        <div class="alert alert-danger text-center">
          Error al guardar los resultados.
        </div>
      `;
    });

  }

  function volverSeleccionTest() {
    testContainer.style.display = "none";
    seleccionTest.style.display = "block";

    // Reset lógico
    preguntas = [];
    respuestas = [];
    preguntaActual = 0;
    testSeleccionado = null;
  }

  function procesarRespuesta() {
    const seleccion = document.querySelector('input[name="respuesta"]:checked');

    if (!seleccion) {
      alert("Selecciona una respuesta");
      return;
    }

    respuestas.push({
      pregunta_id: preguntas[preguntaActual].id,
      area_id: preguntas[preguntaActual].area_id,
      valor: parseInt(seleccion.value)
    });

    preguntaActual++;

    if (preguntaActual >= preguntas.length) {
      mostrarConfirmacionEnvio();
    } else {
      mostrarPregunta();
    }
  }

  </script>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</div>
<script>
const escuelaSelect = document.getElementById("escuela_id");
const especialidadSelect = document.getElementById("especialidad");

if (escuelaSelect && especialidadSelect) {
  escuelaSelect.addEventListener("change", () => {
    const escuelaId = escuelaSelect.value;

    especialidadSelect.innerHTML =
      `<option value="">Seleccione su especialidad...</option>`;
    especialidadSelect.disabled = true;

    if (!escuelaId) return;

    fetch(`config/obtener_especialidades.php?escuela_id=${escuelaId}`)
      .then(res => res.json())
      .then(data => {
        if (!Array.isArray(data) || data.length === 0) {
          especialidadSelect.innerHTML =
            `<option value="">No hay especialidades disponibles</option>`;
          return;
        }

        data.forEach(esp => {
          const opt = document.createElement("option");
          opt.value = esp.nombre;
          opt.textContent = esp.nombre;
          especialidadSelect.appendChild(opt);
        });

        especialidadSelect.disabled = false;
      })
      .catch(() => {
        especialidadSelect.innerHTML =
          `<option value="">Error al cargar especialidades</option>`;
      });
  });
}
</script>
<footer class="footer-sistema mt-auto">
  <div class="container py-4">
    <div class="row align-items-center text-center text-md-start">

      <div class="col-md-6 mb-2 mb-md-0">
        <span class="footer-text">
          © <?= date("Y") ?> Sistema de Tamizaje · CETis 96
        </span>
      </div>

      <div class="col-md-6 text-md-end">
        <span class="footer-text muted">
          Desarrollado con fines académicos
        </span>
      </div>

    </div>
  </div>
</footer>


</body>
</html>
