<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test de Tamizaje POSIT</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style2.css">
</head>

<body>
<header>
  <div class="content">
    <div class="menu container">
      <a href="index.php" class="logo">
        <img src="img/Head-CETis-96_57H (1).png" alt="Logo" style="height:55px;">
      </a>

      <!-- Menú responsive -->
      <input type="checkbox" id="menu" />
      <div class="menu-btn">
        <label for="menu" aria-label="Abrir menú">
          <svg class="menu-icono" viewBox="0 0 24 24" width="32" height="32" role="img" aria-hidden="true">
            <g class="lines" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
              <path class="line top" d="M3 7h18"></path>
              <path class="line mid" d="M3 12h18"></path>
              <path class="line bot" d="M3 17h18"></path>
            </g>
          </svg>
        </label>
      </div>

      <!-- Navegación -->
      <nav class="navbar">
        <div class="main-menu">
          <ul>
            <li><a href="index.php" class="logout">Test</a></li>
            <li><a href="acercade.php">Acerca de</a></li>
            <li><a href="resultados.php">Resultados</a></li>
          </ul>
        </div>
        <ul class="logout-menu">
          <li><a href="admin_cuenta.php" class="admin-btn">Administrar Cuenta</a></li>
          <li><a href="iniciarsesion.php" class="logout">Iniciar Sesión</a></li>
        </ul>
      </nav>
    </div>
  </div>
</header>

<main class="container my-4">

  <!-- Paso 1: Formulario sociodemográfico -->
  <div id="formularioDatos">
    <h2 class="mb-3 text-center">Ingresa tus datos</h2>
    <form id="datosForm" class="p-4 border rounded bg-light shadow-sm">

      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre completo:</label>
        <input type="text" class="form-control" id="nombre" name="nombre" required>
      </div>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label for="edad" class="form-label">Edad:</label>
          <input type="number" class="form-control" id="edad" name="edad" required>
        </div>

        <div class="col-md-6 mb-3">
          <label for="sexo" class="form-label">Sexo:</label>
          <select id="sexo" name="sexo" class="form-select" required>
            <option value="">Seleccione...</option>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 mb-3">
          <label for="turno" class="form-label">Turno:</label>
          <select id="turno" name="turno" class="form-select" required>
            <option value="">Seleccione...</option>
            <option value="Matutino">Matutino</option>
            <option value="Vespertino">Vespertino</option>
          </select>
        </div>

        <div class="col-md-4 mb-3">
          <label for="grado" class="form-label">Semestre:</label>
          <select id="grado" name="grado" class="form-select" required>
            <option value="">Seleccione...</option>
            <option value="1">1ro</option>
            <option value="2">2do</option>
            <option value="3">3ro</option>
            <option value="4">4to</option>
            <option value="5">5to</option>
            <option value="6">6to</option>
          </select>
        </div>

        <div class="col-md-4 mb-3">
          <label for="grupo" class="form-label">Grupo:</label>
          <input type="text" class="form-control" id="grupo" name="grupo" required>
        </div>
      </div>

      <div class="mb-3">
        <label for="especialidad" class="form-label">Especialidad:</label>
        <select id="especialidad" name="especialidad" class="form-select" required>
          <option value="">Seleccione su especialidad...</option>
          <option value="Programación">Programación</option>
          <option value="Contabilidad">Contabilidad</option>
          <option value="Mecatrónica">Mecatrónica</option>
          <option value="Soporte y Mantenimiento">Soporte y Mantenimiento</option>
          <option value="Electricidad">Electricidad</option>
          <option value="Construcción">Construcción</option>
          <option value="Otra">Otra</option>
        </select>
      </div>

      <div class="text-center">
        <button type="submit" class="btn btn-primary px-4">Comenzar Test</button>
      </div>
    </form>
  </div>

  <!-- Paso 1.5: Mensaje de advertencia -->
  <div id="mensajeAdvertencia" class="text-center" style="display: none;">
    <div class="alert alert-warning p-4 mt-4 shadow-sm">
      <h4>📋 Antes de comenzar...</h4>
      <p class="mb-3">Lee con cuidado las preguntas antes de contestar.</p>
      <button id="continuarBtn" class="btn btn-success px-4">Continuar</button>
    </div>
  </div>

  <!-- Paso 2: Test POSIT -->
  <div id="testContainer" class="mt-4" style="display: none;">
    <h2 class="text-center mb-3">Cuestionario POSIT</h2>
    <div class="chat-container border rounded p-3 bg-white" id="chat"></div>
  </div>

</main>

<script>
  const preguntas = [
    "¿Te resulta difícil concentrarte en la escuela?",
    "¿Has tenido discusiones fuertes con tus padres?",
    "¿Has probado alguna bebida alcohólica?",
    "¿Te sientes triste o desanimado la mayor parte del tiempo?",
    "¿Faltas a clases sin permiso?"
  ];

  let indice = 0;
  const chat = document.getElementById("chat");
  const formularioDatos = document.getElementById("formularioDatos");
  const testContainer = document.getElementById("testContainer");
  const datosForm = document.getElementById("datosForm");
  const mensajeAdvertencia = document.getElementById("mensajeAdvertencia");
  const continuarBtn = document.getElementById("continuarBtn");

  // Envío del formulario
  datosForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (datosForm.checkValidity()) {
      formularioDatos.style.display = "none";
      mensajeAdvertencia.style.display = "block";
    }
  });

  // Al presionar "Continuar" después del mensaje
  continuarBtn.addEventListener("click", () => {
    mensajeAdvertencia.style.display = "none";
    testContainer.style.display = "block";
    mostrarPregunta();
  });

  // Mostrar preguntas tipo chat
  function mostrarPregunta() {
    if (indice >= preguntas.length) {
      const fin = document.createElement("div");
      fin.classList.add("question", "alert", "alert-success");
      fin.innerHTML = "<strong>¡Has terminado el test!</strong><br>Gracias por participar.";
      chat.appendChild(fin);
      return;
    }

    const questionBox = document.createElement("div");
    questionBox.classList.add("question", "mb-3");
    questionBox.innerHTML = `<p><strong>${indice + 1}.</strong> ${preguntas[indice]}</p>`;

    const options = document.createElement("div");
    options.classList.add("options");

    for (let i = 1; i <= 5; i++) {
      const label = document.createElement("label");
      label.classList.add("me-3");
      label.innerHTML = `${i} <input type="radio" name="q${indice}" value="${i}" required>`;
      options.appendChild(label);
    }

    questionBox.appendChild(options);
    chat.appendChild(questionBox);

    options.querySelectorAll("input").forEach(input => {
      input.addEventListener("change", () => {
        questionBox.classList.add("disabled");
        indice++;
        mostrarPregunta();
        chat.scrollTop = chat.scrollHeight;
      });
    });
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
